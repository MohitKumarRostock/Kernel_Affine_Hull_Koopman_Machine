"""Known-answer tests for population oracles; no coverage experiment is run."""

from copy import deepcopy
from fractions import Fraction as F
import unittest

from certified_models import predict_exact
from population_oracle import (
    population_oracle, stationary_history_law, cache_info,
    _edges, _propose_dual, _dual, _repair_primal, _risk_values,
)


def model(kind="raw", d=6, kappa=F(2), scale=F(1)):
    p = d if kind == "raw" else (2 if kind == "memberships" else 4)
    return {
        "model_version": 1, "candidate_id": kind, "encoder_kind": kind,
        "history": d, "kappa": kappa, "feature_scale": scale,
        "centers": [[F(0)] * d, [F(1)] * d], "axes": [d - 1, d - 1],
        "score_scale": F(1), "eta": F(1, 16), "omega": 2,
        "coordinate_cost": p, "affine_weights": [F(0)] * p,
        "intercept": F(1, 2),
    }


class PopulationOracleTests(unittest.TestCase):
    def test_stationary_history_probabilities(self):
        for p in [F(1, 20), F(1, 5), F(1, 2), F(19, 20)]:
            rows = stationary_history_law(6, p)
            self.assertEqual(len(rows), 64)
            self.assertEqual(sum(mass for _, mass, _ in rows), 1)
            self.assertEqual(sum(mass * mean for _, mass, mean in rows), F(1, 2))
            by_history = {h: mass for h, mass, _ in rows}
            self.assertEqual(by_history[(0, 0, 0, 0, 0, 0)], F(1, 2) * (1 - p) ** 5)
            self.assertEqual(by_history[(0, 1, 0, 1, 0, 1)], F(1, 2) * p ** 5)

    def test_raw_and_local_exact_bayes_optima(self):
        for p in [F(1, 20), F(1, 5), F(1, 2), F(19, 20)]:
            for kind in ["raw", "local_position"]:
                result = population_oracle(model(kind), p)
                self.assertTrue(result["exact"])
                self.assertEqual(result["risk_opt_lower"], p * (1 - p))
                self.assertEqual(result["risk_opt_upper"], p * (1 - p))
                self.assertEqual(result["risk_fitted"], F(1, 4))
                self.assertEqual(result["oracle_gap"], 0)

    def test_fitted_bayes_predictor_risk(self):
        for p in [F(1, 20), F(1, 5), F(1, 2), F(19, 20)]:
            m = model()
            m["affine_weights"][-1] = 1 - 2 * p
            m["intercept"] = p
            result = population_oracle(m, p)
            self.assertEqual(result["risk_fitted"], p * (1 - p))

    def test_fitted_risk_matches_direct_predict_exact_enumeration(self):
        m, p = model("local_position"), F(1, 5)
        m["affine_weights"] = [F(1, 4), F(-1, 8), F(3, 8), F(1, 2)]
        m["intercept"] = F(1, 3)
        total = F(0)
        for history, mass, mean in stationary_history_law(6, p):
            prediction = predict_exact(m, history)
            total += mass * (mean * (1 - prediction) ** 2 + (1 - mean) * prediction ** 2)
        self.assertEqual(population_oracle(m, p)["risk_fitted"], total)

    def test_membership_collisions_are_aggregated(self):
        # At d=1 the retained local axis leaves zero reconstruction residual.
        # Both affinities are identical for both histories, so no signal remains.
        for p in [F(1, 20), F(19, 20)]:
            result = population_oracle(model("memberships", d=1), p)
            self.assertEqual(result["atom_count"], 1)
            self.assertEqual(result["information_risk"], F(1, 4))
            self.assertEqual(result["risk_opt_lower"], F(1, 4))
            self.assertTrue(result["exact"])

    def test_two_step_membership_information_risk(self):
        p = F(1, 20)
        result = population_oracle(model("memberships", d=2), p)
        two_step_flip = 2 * p * (1 - p)
        self.assertEqual(result["atom_count"], 2)
        self.assertEqual(result["information_risk"], two_step_flip * (1 - two_step_flip))
        self.assertTrue(result["exact"])

    def test_iid_target_information_floor(self):
        for kind in ["raw", "memberships", "local_position"]:
            result = population_oracle(model(kind, kappa=F(1, 100)), F(1, 2))
            self.assertEqual(result["risk_opt_lower"], F(1, 4))
            self.assertTrue(result["exact"])

    def test_zero_sensitivity_class_exact(self):
        for kind in ["raw", "memberships", "local_position"]:
            result = population_oracle(model(kind, kappa=F(0)), F(1, 20))
            self.assertEqual(result["risk_opt_lower"], F(1, 4))
            self.assertEqual(result["risk_opt_upper"], F(1, 4))
            self.assertTrue(result["exact"])

    def test_weighted_dual_matches_exact_two_atom_dyadic_optimum(self):
        result = population_oracle(model(d=1, kappa=F(1, 4)), F(1, 4), include_proof=True)
        # I = 3/16 and the optimal excess is (1/2 - 1/4)^2/4.
        self.assertEqual(result["risk_opt_lower"], F(13, 64))
        self.assertEqual(result["risk_opt_upper"], F(13, 64))
        self.assertTrue(result["exact"])
        self.assertEqual(result["method"], "verified_weighted_primal_dual")

    def test_nondyadic_optimum_is_enclosed(self):
        p, kappa = F(1, 20), F(1, 4)
        optimum = p * (1 - p) + (1 - 2 * p - kappa) ** 2 / 4
        result = population_oracle(model(d=1, kappa=kappa), p, include_proof=True)
        self.assertLessEqual(result["risk_opt_lower"], optimum)
        self.assertGreaterEqual(result["risk_opt_upper"], optimum)
        self.assertLess(result["oracle_gap"], F(1, 10**9))
        values = result["proof"]["primal_values"]
        self.assertLessEqual((values[0] - values[1]) ** 2, kappa**2)

    def test_coarse_proposals_preserve_verified_enclosure(self):
        p, kappa = F(1, 20), F(1, 1000)
        optimum = p * (1 - p) + (1 - 2 * p - kappa) ** 2 / 4
        result = population_oracle(model(d=1, kappa=kappa), p, sweeps=0,
                                   distance_bits=4, multiplier_bits=4, primal_bits=8)
        self.assertLessEqual(result["risk_opt_lower"], optimum)
        self.assertGreaterEqual(result["risk_opt_upper"], optimum)
        self.assertFalse(result["exact"])

    def test_unequal_atom_weights_known_optimum(self):
        # A direct weighted-kernel check, independent of the Markov enumeration.
        # The optimum is (.25,.5,.75), with information risk 1/8 and excess 1/32.
        atoms = (((F(0),), F(1, 4), F(0)),
                 ((F(1),), F(1, 2), F(1, 2)),
                 ((F(2),), F(1, 4), F(1)))
        edges = _edges(atoms, F(1, 4), 48)
        multipliers, _, _ = _propose_dual(atoms, edges, 2000, 48)
        excess, values = _dual(atoms, edges, multipliers)
        repaired = _repair_primal(atoms, values, F(1, 4), 40)
        lower, upper, optimum = F(1, 8) + excess, _risk_values(atoms, repaired), F(5, 32)
        self.assertLessEqual(lower, optimum)
        self.assertGreaterEqual(upper, optimum)
        self.assertLess(upper - lower, F(1, 10**9))

    def test_cache_excludes_fitted_coefficients(self):
        original = model()
        first = population_oracle(original, F(1, 20))
        hits = cache_info()["classes"]["hits"]
        changed = deepcopy(original)
        changed["affine_weights"][-1] = F(9, 10)
        changed["intercept"] = F(1, 20)
        second = population_oracle(changed, F(1, 20))
        self.assertGreater(cache_info()["classes"]["hits"], hits)
        self.assertNotEqual(first["risk_fitted"], second["risk_fitted"])
        self.assertEqual(first["risk_opt_lower"], second["risk_opt_lower"])

    def test_degenerate_stationary_laws_have_no_zero_mass_atoms(self):
        for p in [F(0), F(1)]:
            result = population_oracle(model(), p)
            self.assertEqual(result["positive_history_count"], 2)
            self.assertEqual(result["risk_opt_lower"], 0)
            self.assertTrue(result["exact"])

    def test_invalid_model_or_probability_rejected(self):
        for p in [F(-1, 10), F(11, 10), 0.05, True]:
            with self.assertRaises((ValueError, TypeError)):
                population_oracle(model(), p)
        bad = model()
        bad["affine_weights"][0] = F(3)
        with self.assertRaises(ValueError):
            population_oracle(bad, F(1, 20))


if __name__ == "__main__":
    unittest.main()
