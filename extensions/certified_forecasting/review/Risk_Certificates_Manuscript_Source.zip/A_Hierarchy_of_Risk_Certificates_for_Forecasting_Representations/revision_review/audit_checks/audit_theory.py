"""Independent small numerical checks of the manuscript's mathematical claims.

This script imports no supplied project code and reads no experiment results.
It solves tiny convex programs with SciPy SLSQP and enumerates finite laws.
Numerical agreement is a diagnostic, not a proof or verified-arithmetic audit.
Run: python audit_theory.py
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations
import json
from math import factorial
from pathlib import Path
import platform

import numpy as np
import scipy
from scipy.optimize import LinearConstraint, minimize


SEED = 20261103
TOL = 2e-8
RNG = np.random.default_rng(SEED)
SOLVER_STATUS: Counter = Counter()
SOLVER_FEASIBILITY: list[float] = []


def scalar_optimum(y, distances, kappa, weights=None):
    """Minimize a weighted scalar squared error using all Lipschitz constraints."""
    y = np.asarray(y, dtype=float)
    distances = np.asarray(distances, dtype=float)
    w = np.ones(len(y)) if weights is None else np.asarray(weights, dtype=float)
    assert np.all(w > 0)
    if len(y) == 1:
        return 0.0
    rows, rhs = [], []
    for i, j in combinations(range(len(y)), 2):
        row = np.zeros(len(y))
        row[i], row[j] = 1.0, -1.0
        rows.extend([row, -row])
        rhs.extend([kappa * distances[i, j]] * 2)
    a, c = np.asarray(rows), np.asarray(rhs)
    initial = np.full(len(y), np.average(y, weights=w))
    result = minimize(
        lambda v: float(np.sum(w * (v - y) ** 2)),
        initial,
        jac=lambda v: 2 * w * (v - y),
        constraints=[LinearConstraint(a, -np.inf, c)],
        method="SLSQP",
        options={"ftol": 1e-12, "maxiter": 1000},
    )
    SOLVER_STATUS[str(result.status)] += 1
    SOLVER_FEASIBILITY.append(float(max(0.0, np.max(a @ result.x - c))))
    if not result.success:
        raise RuntimeError(f"SLSQP failure: {result.message}")
    return float(result.fun)


def distances_of(x):
    x = np.asarray(x, dtype=float)
    if x.ndim == 1:
        x = x[:, None]
    return np.linalg.norm(x[:, None, :] - x[None, :, :], axis=-1)


def compositions(total, length):
    if length == 1:
        yield (total,)
        return
    for first in range(total + 1):
        for rest in compositions(total - first, length - 1):
            yield (first,) + rest


def multinomial_probability(counts, probabilities):
    coefficient = factorial(sum(counts))
    probability = 1.0
    for count, p in zip(counts, probabilities):
        coefficient /= factorial(count)
        probability *= p**count
    return coefficient * probability


def rare_conflict_checks():
    u = np.array([3.0, 0.0, 1.0])
    y = np.array([0.0, -1.0, 1.0])
    epsilons = [0.01, 0.1, 0.3, 0.49]
    block_sizes = [2, 3, 4, 6, 8]
    results = []
    for b in block_sizes:
        scores = []
        for counts in compositions(b, 3):
            present = np.flatnonzero(counts)
            objective = scalar_optimum(
                y[present], distances_of(u[present]), 1.0,
                np.asarray(counts)[present],
            )
            scores.append((counts, objective / (b - 1)))
        for epsilon in epsilons:
            probabilities = [1 - 2 * epsilon, epsilon, epsilon]
            enumerated = sum(
                multinomial_probability(counts, probabilities) * score
                for counts, score in scores
            )
            stated = (2 * b * epsilon - 1 + (1 - 2 * epsilon) ** b) / (4 * (b - 1))
            results.append({"b": b, "epsilon": epsilon, "enumerated": enumerated,
                            "stated": stated, "absolute_error": abs(enumerated - stated)})
    population_errors = []
    for epsilon in epsilons:
        numeric = scalar_optimum(y, distances_of(u), 1.0,
                                 [1 - 2 * epsilon, epsilon, epsilon])
        population_errors.append(abs(numeric - epsilon / 2))
    maximum = max(row["absolute_error"] for row in results)
    return {"cases": len(results), "max_absolute_error": maximum,
            "population_optimum_max_absolute_error": max(population_errors),
            "passed": bool(maximum < TOL and max(population_errors) < TOL),
            "details": results}


def occupancy_checks():
    d = 2.0
    results = []
    for m in [1, 2, 3]:
        u = np.repeat(d * np.arange(m), 2)
        y = np.tile([0.0, d], m)
        probabilities = np.full(2 * m, 1 / (2 * m))
        for b in [2, 3, 4, 6]:
            enumerated = 0.0
            states = 0
            for counts in compositions(b, 2 * m):
                present = np.flatnonzero(counts)
                objective = scalar_optimum(
                    y[present], distances_of(u[present]), 1.0,
                    np.asarray(counts)[present],
                )
                enumerated += multinomial_probability(counts, probabilities) * objective / (b - 1)
                states += 1
            stated = d**2 * (b - m * (1 - (1 - 1 / m) ** b)) / (4 * (b - 1))
            results.append({"b": b, "M": m, "enumerated_count_vectors": states,
                            "enumerated": enumerated, "stated": stated,
                            "absolute_error": abs(enumerated - stated)})
    maximum = max(row["absolute_error"] for row in results)
    return {"cases": len(results), "max_absolute_error": maximum,
            "passed": bool(maximum < TOL), "details": results}


def subset_and_pair_checks():
    pair_errors, subset_excesses, range_excesses = [], [], []
    scores_evaluated = 0
    for repetition in range(24):
        b = 4 + repetition % 4
        x = RNG.normal(size=(b, 2))
        if repetition % 3 == 0:
            x[1] = x[0]  # Includes distinct observations at zero pseudodistance.
        y = RNG.uniform(-1, 1, size=b)
        kappa = [0.0, 0.2, 1.0, 3.0][repetition % 4]
        distances = distances_of(x)
        full = scalar_optimum(y, distances, kappa) / (b - 1)
        scores_evaluated += 1
        stated_range = 4 * (b * b // 4) / (b * (b - 1))
        range_excesses.append(full - stated_range)
        for size in sorted({2, 3, b - 1}):
            values = []
            for indices in combinations(range(b), size):
                ix = np.asarray(indices)
                value = scalar_optimum(y[ix], distances[np.ix_(ix, ix)], kappa) / (size - 1)
                values.append(value)
                scores_evaluated += 1
                if size == 2:
                    i, j = indices
                    pair = 0.5 * max(abs(y[i] - y[j]) - kappa * distances[i, j], 0.0) ** 2
                    pair_errors.append(abs(value - pair))
            subset_excesses.append(float(np.mean(values)) - full)
    maximum_pair_error = max(pair_errors)
    maximum_subset_violation = max(0.0, max(subset_excesses))
    maximum_range_violation = max(0.0, max(range_excesses))
    return {"random_full_blocks": 24, "scores_evaluated": scores_evaluated,
            "pair_scores_compared": len(pair_errors),
            "subset_average_inequalities": len(subset_excesses),
            "max_pair_formula_absolute_error": maximum_pair_error,
            "max_subset_average_violation": maximum_subset_violation,
            "max_stated_range_violation": maximum_range_violation,
            "passed": bool(max(maximum_pair_error, maximum_subset_violation,
                               maximum_range_violation) < TOL)}


def population_pair_checks():
    global_excess, conditional_excess, centered_excess = [], [], []
    for repetition in range(30):
        n = 4 + repetition % 5
        x = RNG.normal(size=(n, 2))
        if repetition % 3 == 0:
            x[1] = x[0]
        y = RNG.uniform(-1, 1, n)
        p = RNG.dirichlet(np.ones(n))
        kappa = [0.0, 0.2, 0.5, 1.0, 3.0][repetition % 5]
        distance = distances_of(x)
        oracle = scalar_optimum(y, distance, kappa, p)
        pair_kernel = 0.5 * np.maximum(abs(y[:, None] - y[None, :]) - kappa * distance, 0) ** 2
        witness = float(p @ pair_kernel @ p)
        global_excess.append(witness - oracle)
        variance_y = np.sum(p * (y - p @ y) ** 2)
        variance_x = np.sum(p * np.sum((x - p @ x) ** 2, axis=1))
        centered = max(np.sqrt(variance_y) - kappa * np.sqrt(variance_x), 0) ** 2
        centered_excess.append(centered - witness)
        labels = np.arange(n) % 3
        stratified = 0.0
        for label in np.unique(labels):
            selected = np.flatnonzero(labels == label)
            mass = p[selected].sum()
            q = p[selected] / mass
            stratified += mass * float(q @ pair_kernel[np.ix_(selected, selected)] @ q)
        conditional_excess.append(stratified - oracle)
    maxima = {"max_pair_bound_violation": max(0.0, max(global_excess)),
              "max_conditional_pair_bound_violation": max(0.0, max(conditional_excess)),
              "max_centered_dominance_violation": max(0.0, max(centered_excess))}
    return {"finite_laws": 30, **maxima, "passed": bool(max(maxima.values()) < TOL)}


def vector_two_atom_checks():
    errors, feasibility = [], []
    for repetition in range(30):
        q = 1 + repetition % 3
        y = RNG.normal(size=(2, q))
        u = RNG.normal(size=(2, 2))
        p = float(RNG.uniform(0.05, 0.95))
        kappa = float(RNG.uniform(0.05, 2.5))
        limit = kappa * np.linalg.norm(u[1] - u[0])
        weights = np.array([p, 1 - p])
        initial = np.tile(p * y[0] + (1 - p) * y[1], (2, 1)).ravel()

        def objective(flat):
            values = flat.reshape(2, q)
            return float(np.sum(weights[:, None] * (values - y) ** 2))

        def gradient(flat):
            return (2 * weights[:, None] * (flat.reshape(2, q) - y)).ravel()

        def constraint(flat):
            values = flat.reshape(2, q)
            return float(limit**2 - np.sum((values[1] - values[0]) ** 2))

        def constraint_gradient(flat):
            values = flat.reshape(2, q)
            difference = values[1] - values[0]
            return np.concatenate([2 * difference, -2 * difference])

        solved = minimize(objective, initial, jac=gradient, method="SLSQP",
                          constraints=[{"type": "ineq", "fun": constraint,
                                        "jac": constraint_gradient}],
                          options={"ftol": 1e-12, "maxiter": 1000})
        SOLVER_STATUS[str(solved.status)] += 1
        if not solved.success:
            raise RuntimeError(f"Vector SLSQP failure: {solved.message}")
        stated = p * (1 - p) * max(np.linalg.norm(y[1] - y[0]) - limit, 0) ** 2
        errors.append(abs(float(solved.fun) - stated))
        feasibility.append(max(0.0, -constraint(solved.x)))
    return {"two_atom_cases": 30, "target_dimensions": [1, 2, 3],
            "max_objective_absolute_error": max(errors),
            "max_squared_constraint_violation": max(feasibility),
            "passed": bool(max(max(errors), max(feasibility)) < TOL)}


def known_risk_fit_checks():
    errors = []
    for p in [0.01, 0.1, 0.5, 0.9, 0.99]:
        for estimated_p in [0.0, 0.1, 0.5, 0.9, 1.0]:
            for a in [0.0, 0.2, 1.0]:
                for kappa in [0.0, 0.5, 1.0, 3.0]:
                    unexplained = max(2 - kappa * np.sqrt(2) * a, 0)
                    fit0 = -1 + estimated_p * unexplained
                    fit1 = 1 - (1 - estimated_p) * unexplained
                    direct = (1 - p) * (-1 - fit0) ** 2 + p * (1 - fit1) ** 2
                    stated = unexplained**2 * (p * (1 - p) + (estimated_p - p) ** 2)
                    errors.append(abs(direct - stated))
    return {"parameter_combinations": len(errors), "max_absolute_error": max(errors),
            "passed": bool(max(errors) < TOL)}


def main():
    result = {
        "purpose": "Independent diagnostics of finite-dimensional identities and inequalities",
        "limitations": [
            "No project code, archived solvers, or stored experiment outputs are imported.",
            "SLSQP uses floating point; these are not verified optimization certificates.",
            "Finite checks do not prove universal inequalities, compactness consistency, or coverage.",
            "No forecasting experiment is rerun, and no novelty claim is assessed by this script.",
        ],
        "seed": SEED,
        "absolute_comparison_tolerance": TOL,
        "environment": {"python": platform.python_version(), "numpy": np.__version__,
                        "scipy": scipy.__version__},
        "checks": {
            "rare_conflict_exact_law": rare_conflict_checks(),
            "noisy_support_exact_law": occupancy_checks(),
            "subset_monotonicity_pair_formula_and_range": subset_and_pair_checks(),
            "pair_and_conditional_population_bounds": population_pair_checks(),
            "vector_two_atom_optimum": vector_two_atom_checks(),
            "known_risk_fitted_identity": known_risk_fit_checks(),
        },
    }
    result["optimization_diagnostics"] = {
        "status_counts": dict(SOLVER_STATUS),
        "scalar_programs": len(SOLVER_FEASIBILITY),
        "max_scalar_primal_constraint_violation": max(SOLVER_FEASIBILITY, default=0.0),
    }
    result["all_checks_passed"] = all(check["passed"] for check in result["checks"].values())
    output = Path(__file__).with_name("theory_checks.json")
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"all_checks_passed": result["all_checks_passed"],
                      "output": str(output),
                      "checks": {key: {k: v for k, v in value.items() if k != "details"}
                                 for key, value in result["checks"].items()},
                      "optimization_diagnostics": result["optimization_diagnostics"]}, indent=2))


if __name__ == "__main__":
    main()
