#!/usr/bin/env python3
"""Post-hoc descriptive diagnostics from the already frozen Step 5 records.

This script draws no random samples, fits no models, changes no certificate,
and runs no alternative numerical algorithm. It summarizes existing records.
The output is explanatory post-hoc description, not a registered primary
endpoint, a causal decomposition, or another coverage experiment.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction
import hashlib
import json
from pathlib import Path


ZERO = Fraction(0)
TAU = Fraction(1, 10)
CANDIDATES = ("raw", "memberships", "local_position")


def q(value):
    return Fraction(value)


def pack(value):
    if isinstance(value, Fraction):
        return f"{value.numerator}/{value.denominator}"
    if isinstance(value, dict):
        return {key: pack(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [pack(item) for item in value]
    return value


def exact_mean(values):
    values = list(values)
    return sum(values, ZERO) / len(values) if values else None


def candidate_record(run, name):
    rows = [row for row in run["candidates"] if row["candidate_id"] == name]
    if len(rows) != 1:
        raise ValueError("candidate identity is missing or duplicated")
    return rows[0]


def summarize_candidate(rows, N):
    n = len(rows)
    if not n:
        return {"completed_candidate_records": 0}
    mean = lambda name: exact_mean(q(row[name]) for row in rows)
    oracle_mean = lambda name: exact_mean(q(row["oracle"][name]) for row in rows)
    class_lo, class_hi = oracle_mean("risk_opt_lower"), oracle_mean("risk_opt_upper")
    fitted = oracle_mean("risk_fitted")
    means = {
        "empirical_lower": mean("empirical_lower"),
        "population_lower_L": mean("L"),
        "empirical_upper": mean("empirical_upper"),
        "population_upper_U": mean("U"),
        "fitted_population_risk": fitted,
        "class_population_risk_lower": class_lo,
        "class_population_risk_upper": class_hi,
        "pair_empirical_lower": mean("pair_sse") / N,
        "graph_dual_empirical_lower": mean("graph_dual_sse") / N,
        "empirical_lower_minus_L": mean("empirical_lower") - mean("L"),
        "U_minus_empirical_upper": mean("U") - mean("empirical_upper"),
        "fitted_minus_class_gap_lower": fitted - class_hi,
        "fitted_minus_class_gap_upper": fitted - class_lo,
    }
    feasible = [row for row in rows if row["true_feasibility"] == "feasible"]
    return {
        "completed_candidate_records": n,
        "means_exact": means,
        "means_decimal_for_display": {key: float(value) for key, value in means.items()},
        "accepted_count": sum(row["decision"] == "accepted" for row in rows),
        "excluded_count": sum(row["decision"] == "excluded" for row in rows),
        "unresolved_count": sum(row["decision"] == "unresolved" for row in rows),
        "true_class_feasible_count": len(feasible),
        "true_class_infeasible_count": sum(row["true_feasibility"] == "infeasible" for row in rows),
        "true_class_feasibility_unresolved_count": sum(row["true_feasibility"] == "oracle_unresolved" for row in rows),
        "true_fitted_feasible_count": sum(q(row["oracle"]["risk_fitted"]) <= TAU for row in rows),
        "class_feasible_but_fitted_infeasible_count": sum(q(row["oracle"]["risk_fitted"]) > TAU for row in feasible),
        "mean_graph_edge_count_exact": exact_mean(Fraction(row["graph_edge_count"]) for row in rows),
        "mean_disjoint_pair_count_exact": exact_mean(Fraction(row["paired_count"]) for row in rows),
    }


def describe(runs, input_sha256):
    by_cell = defaultdict(list)
    protocol_hashes = {row["protocol_sha256"] for row in runs}
    if len(protocol_hashes) != 1:
        raise ValueError("records do not share one frozen protocol hash")
    for run in runs:
        by_cell[run["cell_id"]].append(run)
    focused = {}
    for cell_id in ("p005_K320", "p095_K320", "p050_K320"):
        all_rows = by_cell[cell_id]
        completed = [row for row in all_rows if row["status"] == "completed"]
        if not completed:
            raise ValueError("required cell has no completed records")
        N = completed[0]["K"] * completed[0]["q"]
        focused[cell_id] = {
            "registered_rows": len(all_rows), "completed_rows": len(completed),
            "K": completed[0]["K"], "q": completed[0]["q"], "N": N,
            "any_accepted_count": sum(row["any_accepted"] for row in completed),
            "minimum_feasible_cost_claim_count": sum(row["selection"]["minimum_feasible_cost_certified"] for row in completed),
            "candidates": {name: summarize_candidate([candidate_record(row, name) for row in completed], N)
                           for name in CANDIDATES},
        }
    baseline = [row for row in by_cell["p005_K320"] if row["status"] == "completed"]
    memberships = [candidate_record(row, "memberships") for row in baseline]
    feasible_memberships = [row for row in memberships if row["true_feasibility"] == "feasible"]
    infeasible_memberships = [row for row in memberships if row["true_feasibility"] == "infeasible"]
    subset = {
        "cell_id": "p005_K320", "tau": TAU,
        "all_membership_candidates": summarize_candidate(memberships, 1280),
        "truly_class_feasible_subset": summarize_candidate(feasible_memberships, 1280),
        "truly_class_infeasible_subset": summarize_candidate(infeasible_memberships, 1280),
        "interpretation": "Class feasibility concerns the full Lipschitz decoder class. A fitted-witness failure does not prove that the affine family itself is incapable, or identify training, regularization, norm repair or expressiveness as the cause.",
    }
    sweep_rows = {}
    for cell_id in ("p005_K320_s0", "p005_K320", "p005_K320_s32"):
        completed = [row for row in by_cell[cell_id] if row["status"] == "completed"]
        sweep_rows[cell_id] = {
            "sweeps": completed[0]["sweeps"], "completed_rows": len(completed),
            "minimum_feasible_cost_claim_count": sum(row["selection"]["minimum_feasible_cost_certified"] for row in completed),
            "candidates": {name: summarize_candidate([candidate_record(row, name) for row in completed], 1280)
                           for name in CANDIDATES},
        }
    baseline_by_rep = {row["replicate"]: row for row in baseline}
    paired = {}
    for alternative in ("p005_K320_s0", "p005_K320_s32"):
        alternative_by_rep = {row["replicate"]: row for row in by_cell[alternative] if row["status"] == "completed"}
        reps = sorted(set(baseline_by_rep) & set(alternative_by_rep))
        for rep in reps:
            left, right = baseline_by_rep[rep], alternative_by_rep[rep]
            if (left["series_sha256"] != right["series_sha256"] or
                    left["frozen_models_sha256"] != right["frozen_models_sha256"]):
                raise ValueError("sweep comparison does not hold the trajectory and model fixed")
        comparisons = {}
        for name in CANDIDATES:
            left = [candidate_record(baseline_by_rep[rep], name) for rep in reps]
            right = [candidate_record(alternative_by_rep[rep], name) for rep in reps]
            differences = [q(b["L"]) - q(a["L"]) for a, b in zip(left, right)]
            comparisons[name] = {
                "mean_L_difference_alternative_minus_baseline": exact_mean(differences),
                "L_increased": sum(v > 0 for v in differences),
                "L_decreased": sum(v < 0 for v in differences),
                "L_equal": sum(v == 0 for v in differences),
                "U_changed": sum(q(a["U"]) != q(b["U"]) for a, b in zip(left, right)),
                "mean_empirical_lower_difference_alternative_minus_baseline":
                    exact_mean(q(b["empirical_lower"]) - q(a["empirical_lower"]) for a, b in zip(left, right)),
            }
        paired[alternative] = {"completed_matched_pairs": len(reps), "candidates": comparisons}
    raw_exclusions = {
        cell_id: sum(candidate_record(row, "raw")["decision"] == "excluded"
                     for row in rows if row["status"] == "completed")
        for cell_id, rows in sorted(by_cell.items())
    }
    return {
        "analysis_type": "explanatory_posthoc_description_of_frozen_results",
        "protocol_sha256": next(iter(protocol_hashes)),
        "input_runs_sha256": input_sha256,
        "existing_run_rows": len(runs), "new_simulations": 0,
        "engine_or_protocol_changes": False,
        "tau": TAU,
        "mean_scope": "Means average the existing completed runs, including their development-dependent learned classes. Exact rational values are authoritative; decimal copies are display-only.",
        "inference_scope": "No new confidence intervals or hypothesis tests are introduced. Do not pool matched cells as independent observations.",
        "focused_cells": focused,
        "membership_witness_gap": subset,
        "registered_sweep_ablation_descriptions": sweep_rows,
        "paired_sweep_differences": paired,
        "raw_exclusions_by_cell": raw_exclusions,
        "interpretation_limits": [
            "The population-risk-to-empirical-lower gap combines finite-sample empirical optimism, sparse-graph relaxation and finite dual optimization; these summaries alone do not separate them.",
            "The empirical-lower-to-L decrement includes KL calibration and conservative rounding. It is not an estimate of optimization error.",
            "The registered sweep ablation isolates additional multiplier-proposal sweeps on the same frozen data, models and graph at p=0.05; it does not identify the optimization effect at p=0.5.",
            "The separate saved-replicate graph diagnostic concerns p050_K320 replicate0 only and must not be represented as a registered all-replicate ablation.",
            "Class-feasible but fitted-infeasible cases establish a limitation of the chosen witness, not impossibility for every affine learner.",
        ],
    }


def main():
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, default=base / "results" / "runs.jsonl")
    parser.add_argument("--out", type=Path, default=base / "results" / "bottleneck_diagnostics.json")
    args = parser.parse_args()
    raw = args.runs.read_bytes()
    runs = [json.loads(line) for line in raw.splitlines() if line.strip()]
    result = describe(runs, hashlib.sha256(raw).hexdigest())
    args.out.write_text(json.dumps(pack(result), indent=2, sort_keys=True) + "\n")
    print(json.dumps({"written": str(args.out), "analysis_type": result["analysis_type"],
                      "existing_rows": len(runs), "new_simulations": 0,
                      "membership_class_feasible_but_fitted_infeasible":
                      result["membership_witness_gap"]["truly_class_feasible_subset"]["class_feasible_but_fitted_infeasible_count"]}, indent=2))


if __name__ == "__main__":
    main()
