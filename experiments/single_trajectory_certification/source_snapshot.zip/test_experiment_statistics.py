"""Tests of exact binomial confidence bounds; no scientific experiment runs."""

from fractions import Fraction as F
from math import comb
import unittest

from experiment_statistics import (
    binomial_cdf_exact, mc_failure_upper, mc_failure_lower,
    verify_failure_upper, familywise_alpha, summarize_joint_failures,
    mc_family_failure_upper, rate_interval,
)


class ExperimentStatisticsTests(unittest.TestCase):
    def test_exact_CDF_against_direct_binomial_sum(self):
        for n in [1, 2, 7, 12]:
            for p in [F(0), F(1), F(1, 3), F(7, 8)]:
                for k in range(n + 1):
                    expected = sum((comb(n, i) * p**i * (1-p)**(n-i)
                                    for i in range(k+1)), F(0))
                    self.assertEqual(binomial_cdf_exact(k, n, p), expected)

    def test_CDF_boundaries_and_complement(self):
        self.assertEqual(binomial_cdf_exact(-1, 10, F(1, 3)), 0)
        self.assertEqual(binomial_cdf_exact(10, 10, F(1, 3)), 1)
        for k in range(11):
            self.assertEqual(binomial_cdf_exact(k, 10, F(1, 3)),
                             1-binomial_cdf_exact(10-k-1, 10, F(2, 3)))

    def test_zero_failures_exact_rational_root(self):
        # For n=2, alpha=1/4, (1-u)^2=1/4 has root u=1/2.
        self.assertEqual(mc_failure_upper(0, 2, F(1, 4)), F(1, 2))
        self.assertEqual(mc_failure_lower(2, 2, F(1, 4)), F(1, 2))
        self.assertEqual(mc_failure_upper(1, 1, F(1, 20)), 1)
        self.assertEqual(mc_failure_lower(0, 1, F(1, 20)), 0)

    def test_upper_bounds_have_exact_outer_grid_checks(self):
        grid = F(1, 2**24)
        for k, n, alpha in [(0,200,F(1,220)), (1,200,F(1,220)), (10,200,F(1,220)),
                            (100,200,F(1,20)), (199,200,F(1,20)), (200,200,F(1,20))]:
            upper = mc_failure_upper(k, n, alpha)
            self.assertTrue(verify_failure_upper(k, n, alpha, upper))
            self.assertFalse(verify_failure_upper(k, n, alpha, upper-grid))

    def test_exact_finite_sample_one_sided_coverage_on_rational_probabilities(self):
        # Exhaustive outcome probabilities, not a Monte Carlo test.
        n, alpha = 12, F(1, 10)
        limits = [mc_failure_upper(k, n, alpha, bits=18) for k in range(n+1)]
        for p in [F(1,100), F(1,10), F(1,3), F(1,2), F(9,10), F(99,100)]:
            noncoverage = sum((comb(n,k)*p**k*(1-p)**(n-k)
                              for k in range(n+1) if limits[k] < p), F(0))
            self.assertLessEqual(noncoverage, alpha)

    def test_family_allocation_and_oracle_ambiguity_not_discarded(self):
        alpha = familywise_alpha(F(1,20), 12)
        self.assertEqual(alpha, F(1,240))
        summary = summarize_joint_failures(1, 2, 200, alpha)
        self.assertEqual(summary["conservative_failure_count"], 3)
        self.assertEqual(summary["observed_failure_fraction_lower"], F(1,200))
        self.assertEqual(summary["observed_failure_fraction_upper"], F(3,200))
        self.assertEqual(summary["mc_failure_probability_upper"], mc_failure_upper(3,200,alpha))
        self.assertTrue(summary["mc_upper_direct_check"])
        self.assertEqual(mc_family_failure_upper(3,200,family_cells=12), summary["mc_failure_probability_upper"])
        composite = summarize_joint_failures(1,2,200,alpha,operational_unavailable=1)
        self.assertEqual(composite["conservative_failure_count"], 4)
        self.assertEqual(composite["mc_failure_probability_upper"], mc_failure_upper(4,200,alpha))

    def test_pointwise_two_sided_rate_interval_splits_tail_budget(self):
        low, high = rate_interval(17,200,F(1,20))
        self.assertEqual(low, mc_failure_lower(17,200,F(1,40)))
        self.assertEqual(high, mc_failure_upper(17,200,F(1,40)))
        self.assertLessEqual(low,F(17,200))
        self.assertGreaterEqual(high,F(17,200))

    def test_invalid_counts_and_float_inputs_rejected(self):
        for k,n in [(-1,10), (11,10), (0,0), (True,10), (1,False)]:
            with self.assertRaises(ValueError):
                mc_failure_upper(k,n,F(1,20))
        for alpha in [F(0),F(1),F(-1)]:
            with self.assertRaises(ValueError):
                mc_failure_upper(0,10,alpha)
        with self.assertRaises(TypeError):
            mc_failure_upper(0,10,0.05)
        with self.assertRaises(ValueError):
            summarize_joint_failures(9,2,10,F(1,20))


if __name__ == "__main__":
    unittest.main()
