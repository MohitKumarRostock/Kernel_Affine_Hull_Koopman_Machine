#!/usr/bin/env python3
"""Post-hoc explanation of one registered sparse-graph lower certificate.

This analysis was designed after the fixed experiment was complete. It examines
only p050_K320, replicate 0. It reconstructs that already registered record from
its archived seed; it generates no additional scientific sample, changes no
engine, and does not replace any registered outcome.

For binary raw histories, feature_scale=1 and kappa=2, every constraint between
different histories is redundant for predictions in [0,1]. Equal histories must
have equal predictions. Thus the exact full empirical optimum is obtained by
grouping identical histories. In the saved sparse relaxation only its zero-bound
edges impose equality. Its exact optimum groups connected components instead.
Both optima are rational sums of within-group residual squares.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from fractions import Fraction
import hashlib
import json
from pathlib import Path

from certify_series import calibration_windows, digest, pack, prepare, unpack, verify_report
from run_experiment import generate_series, load_protocol, seed_for


ROOT = Path(__file__).resolve().parent
CELL_ID = "p050_K320"
REPLICATE = 0
ZERO = Fraction(0)
ONE = Fraction(1)


def group_mse(groups, targets):
    """Exact minimum residual mean for predictions constant within each group."""
    indices = [i for group in groups for i in group]
    if sorted(indices) != list(range(len(targets))):
        raise ValueError("groups must partition every calibration index exactly once")
    total = ZERO
    for group in groups:
        n = len(group)
        target_sum = sum((targets[i] for i in group), ZERO)
        target_square_sum = sum((targets[i] ** 2 for i in group), ZERO)
        mean = target_sum / n
        if not ZERO <= mean <= ONE:
            raise ValueError("group mean leaves the allowed prediction range")
        total += target_square_sum - target_sum * target_sum / n
    return total / len(targets)


def analyze(results: Path, protocol_path: Path) -> dict:
    protocol, protocol_hash = load_protocol(protocol_path)
    cell = next(c for c in protocol["cells"] if c["cell_id"] == CELL_ID)
    path = results / "certificates" / f"{CELL_ID}_r{REPLICATE:03d}.json"
    payload = unpack(json.loads(path.read_text()))
    if payload["replicate"] != REPLICATE or payload["protocol_sha256"] != protocol_hash:
        raise ValueError("saved certificate does not match the registered record")
    if digest(payload["cell"]) != digest(cell):
        raise ValueError("saved cell differs from the frozen protocol")
    seed = seed_for(protocol["seed_namespace"], cell["p"], REPLICATE)
    if payload["seed_hex"] != format(seed, "064x"):
        raise ValueError("saved seed differs from the registered seed rule")

    # Reconstruct the existing record, not a new repetition or a new design.
    series = generate_series(Fraction(cell["p"]), cell["T"], seed)
    report = payload["report"]
    verification = verify_report(series, cell["config"], report)
    prepared = prepare(series, cell["config"])
    histories, targets = calibration_windows(prepared)
    raw = next(c for c in report["candidates"] if c["candidate_id"] == "raw")
    model = raw["model"]
    if model["encoder_kind"] != "raw" or model["feature_scale"] != 1 or model["kappa"] != 2:
        raise ValueError("this diagnostic applies only to the registered binary raw instance")
    if any(v not in (ZERO, ONE) for history in histories for v in history) or any(y not in (ZERO, ONE) for y in targets):
        raise ValueError("the registered binary support was not reproduced")

    n = len(targets)
    full_groups = defaultdict(list)
    for i, history in enumerate(histories):
        full_groups[tuple(history)].append(i)

    parent = list(range(n))
    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    record = raw["lower_certificate"]
    edges = [tuple(edge) for edge in record["edges"]]
    edge_set = set(edges)
    if any(tuple(pair) not in edge_set for pair in record["pairs"]):
        raise ValueError("paired lower certificate uses constraints outside this graph")
    zero_edges = 0
    unit_edges = 0
    for i, j, bound in edges:
        squared_distance = sum(((x-y)**2 for x, y in zip(histories[i], histories[j])), ZERO)
        if squared_distance == 0:
            if bound != 0:
                raise ValueError("an exact equality edge has a nonzero saved bound")
            parent[find(i)] = find(j)
            zero_edges += 1
        else:
            # Binary distinct raw histories have distance >=1; kappa=2, and
            # the [0,1] output range already bounds every difference by1.
            if squared_distance < 1 or bound != 1:
                raise ValueError("a distinct-history edge is not redundant as expected")
            unit_edges += 1
    components = defaultdict(list)
    for i in range(n):
        components[find(i)].append(i)
    sizes = Counter(map(len, components.values()))
    for component in components.values():
        if len({tuple(histories[i]) for i in component}) != 1:
            raise ValueError("a zero-edge component joins different histories")

    sparse_optimum = group_mse(list(components.values()), targets)
    full_optimum = group_mse(list(full_groups.values()), targets)
    # For a component of size m, maximization over binary target assignments is
    # max_k k(m-k)/m = floor(m^2/4)/m. This also bounds [0,1] targets, since the
    # residual minimum is convex in their vector and reaches a maximum at a
    # cube vertex. Sum over components and divide by all N windows.
    ceiling = sum((Fraction((m*m)//4, m) * count for m, count in sizes.items()), ZERO) / n
    returned = record["lower_empirical"]
    if not ZERO <= returned <= sparse_optimum <= full_optimum <= Fraction(1, 4):
        raise ArithmeticError("exact sparse/full empirical ordering failed")
    if sparse_optimum > ceiling:
        raise ArithmeticError("component-size ceiling failed")
    if raw["L"] > returned:
        raise ArithmeticError("lower KL endpoint exceeds its empirical input")
    tau = report["risk_tolerance"]
    return {
        "schema": "step5_posthoc_saved_graph_diagnostic_v1",
        "analysis_status": "post_hoc_explanatory_analysis_not_preregistered",
        "scope": "Only the already registered p050_K320 replicate0 raw candidate; no claim that all repetitions have this graph.",
        "new_scientific_records": 0,
        "pinned_engine_hashes_verified": True,
        "source_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "record": {"cell_id": CELL_ID, "replicate": REPLICATE,
                   "protocol_sha256": protocol_hash, "seed_hex": payload["seed_hex"],
                   "series_sha256": report["series_sha256"], "report_sha256": digest(report)},
        "saved_report_verification": verification,
        "N": n, "K": prepared["layout"]["blocks_count"], "risk_tolerance": tau,
        "edge_counts": {"total": len(edges), "zero_equality": zero_edges,
                        "unit_redundant": unit_edges},
        "sparse_equality_components": len(components),
        "component_size_counts": {str(k): sizes[k] for k in sorted(sizes)},
        "isolated_vertices": sizes.get(1, 0),
        "nonisolated_vertices": n - sizes.get(1, 0),
        "distinct_full_history_groups": len(full_groups),
        "returned_empirical_lower": returned,
        "exact_sparse_graph_empirical_optimum": sparse_optimum,
        "exact_full_empirical_optimum": full_optimum,
        "gap_due_to_sparse_relaxation": full_optimum - sparse_optimum,
        "gap_between_returned_lower_and_sparse_optimum": sparse_optimum - returned,
        "target_independent_component_ceiling": ceiling,
        "reported_population_L": raw["L"],
        "true_population_class_risk": Fraction(1, 4),
        "fixed_graph_ceiling_below_tolerance": ceiling < tau,
        "interpretation": "For this fixed sparse graph, more multiplier optimization cannot raise a valid empirical lower bound above the exact sparse optimum. Even its target-independent component ceiling is below tau; therefore this graph cannot exclude the raw class at tau by the registered lower KL construction. Grouping or linking repeated full features would be a different numerical procedure requiring separate validation. Registered outcomes remain unchanged.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=ROOT / "results")
    parser.add_argument("--protocol", type=Path, default=ROOT / "protocol.json")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    result = analyze(args.results, args.protocol)
    output = args.out or args.results / "posthoc_graph_diagnostic.json"
    output.write_text(json.dumps(pack(result), indent=2, allow_nan=False) + "\n")
    print(json.dumps(pack(result), indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
