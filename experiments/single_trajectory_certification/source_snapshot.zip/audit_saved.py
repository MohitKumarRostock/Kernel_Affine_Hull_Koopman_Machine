#!/usr/bin/env python3
"""Recheck complete outcome retention and saved full certificates from raw seeds."""
from fractions import Fraction
import argparse
import json
from pathlib import Path

from certify_series import unpack, pack, verify_report, digest
from population_oracle import population_oracle
from run_experiment import load_protocol, seed_for, generate_series
from summarize_experiment import summarize


def main():
    root=Path(__file__).resolve().parent
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol",default=str(root/"protocol.json"))
    parser.add_argument("--results",default=str(root/"results"))
    args=parser.parse_args()
    protocol,ph=load_protocol(args.protocol)
    summary=summarize(args.protocol,args.results)
    cells={c["cell_id"]:c for c in protocol["cells"]}
    settings={k:protocol["oracle"][k] for k in ("sweeps","distance_bits","multiplier_bits","primal_bits")}
    checked=0; unavailable=0
    for path in sorted((Path(args.results)/"certificates").glob("*.json")):
        payload=unpack(json.loads(path.read_text()))
        if "row" in payload and payload["row"].get("status")=="operational_unavailable":
            unavailable+=1
            continue
        cell=payload["cell"]
        if payload["protocol_sha256"]!=ph or digest(cell)!=digest(cells[cell["cell_id"]]):
            raise ValueError("saved certificate has wrong protocol or cell")
        seed=seed_for(protocol["seed_namespace"],cell["p"],payload["replicate"])
        if format(seed,"064x")!=payload["seed_hex"]:
            raise ValueError("saved seed does not match registered stream")
        series=generate_series(Fraction(cell["p"]),cell["T"],seed)
        verify_report(series,cell["config"],payload["report"])
        for row,truth in zip(payload["report"]["candidates"],payload["oracle_proofs"]):
            if truth["candidate_id"]!=row["candidate_id"]:
                raise ValueError("saved oracle candidate mismatch")
            fresh=population_oracle(row["model"],cell["p"],**settings,include_proof=True)
            if digest(fresh)!=digest(truth["oracle"]):
                raise ValueError("population oracle proof failed exact reconstruction")
        checked+=1
    result={"retained_runs_checked":summary["total_runs"],"full_certificates_reconstructed":checked,
            "saved_unavailable_records":unavailable,"numerical_and_oracle_reconstruction":"passed",
            "scope":"All outcomes checked for retention; full certificates are saved for registered representative/exceptional runs. Every scientific run was already checked during generation."}
    (Path(args.results)/"saved_audit.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))


if __name__=="__main__":main()
