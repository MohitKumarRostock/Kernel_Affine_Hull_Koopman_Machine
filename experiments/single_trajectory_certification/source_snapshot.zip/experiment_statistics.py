"""Exact binomial confidence bounds for repeated-trajectory experiment counts.

The statistical units here are independently generated *whole trajectories*,
not forecasting windows, candidate models, or calibration blocks within a run.
If the experiment has S prespecified cells, passing alpha_total/S to each
one-sided bound gives simultaneous coverage at least 1-alpha_total by a union
bound. Matched random streams between cells do not invalidate that union bound;
replicates within each cell still need the stipulated independent-run law.

For k observed failures in n runs, the exact one-sided upper confidence limit
u is the root of P_u{Bin(n,u) <= k}=alpha, or 1 if k=n.  This module returns an
outward dyadic approximation. Every tail comparison is performed with exact
integer arithmetic; no floating-point beta quantile is trusted or required.

This is the usual inversion of binomial tails (Clopper--Pearson construction).
Numerical validity of these bounds does not establish that simulated runs were
independent, prespecified, retained without selection, or correctly classified.
For an oracle with unresolved cases, k=definite_failures+unresolved is a safe
conservative upper count; never silently remove unresolved runs.
"""

from __future__ import annotations

from fractions import Fraction

ZERO = Fraction(0)
ONE = Fraction(1)


def _integer(value: int, name: str, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def _rational(value: Fraction | int, name: str) -> Fraction:
    if isinstance(value, bool) or not isinstance(value, (Fraction, int)):
        raise TypeError(f"{name} must be an exact Fraction or integer")
    return Fraction(value)


def _count_inputs(count: int, n: int) -> tuple[int, int]:
    n = _integer(n, "n", 1)
    count = _integer(count, "count")
    if count > n:
        raise ValueError("count must not exceed n")
    return count, n


def _tail_integer(count: int, n: int, numerator: int, denominator: int) -> tuple[int, int]:
    """Exact numerator/denominator of the binomial CDF, without reduction.

    The input probability is numerator/denominator.  A complement calculation
    limits the recurrence to min(count+1, n-count) terms.
    """
    if count >= n:
        return 1, 1
    if count < 0:
        return 0, 1
    if numerator == 0:
        return 1, 1
    if numerator == denominator:
        return 0, 1
    if 2 * count + 1 > n:
        small, total = _tail_integer(n - count - 1, n, denominator - numerator, denominator)
        return total - small, total
    a, b = numerator, denominator - numerator
    total = denominator ** n
    term = b ** n
    cumulative = term
    for i in range(count):
        # Exact binomial recurrence: each quotient is an integer.  The
        # remainder assertion protects future modifications of the formula.
        term, remainder = divmod(term * (n - i) * a, (i + 1) * b)
        if remainder:
            raise ArithmeticError("binomial recurrence lost exact divisibility")
        cumulative += term
    return cumulative, total


def binomial_cdf_exact(count: int, n: int, probability: Fraction | int) -> Fraction:
    """Return P{Bin(n, probability) <= count} as an exact rational.

    The count may be -1 or n (or further outside), with the usual CDF values
    0 and 1. n must be positive; zero-run uncertainty is intentionally rejected.
    """
    n = _integer(n, "n", 1)
    if isinstance(count, bool) or not isinstance(count, int):
        raise ValueError("count must be an integer")
    probability = _rational(probability, "probability")
    if not 0 <= probability <= 1:
        raise ValueError("probability must lie in [0,1]")
    numerator, denominator = _tail_integer(count, n, probability.numerator, probability.denominator)
    return Fraction(numerator, denominator)


def _cdf_at_most(count: int, n: int, probability: Fraction, alpha: Fraction) -> bool:
    a, b = _tail_integer(count, n, probability.numerator, probability.denominator)
    return a * alpha.denominator <= b * alpha.numerator


def mc_failure_upper(
    count: int, n: int, alpha: Fraction | int = Fraction(1, 20), bits: int = 24
) -> Fraction:
    """Outward one-sided binomial upper confidence limit for failure probability.

    At most ``bits`` exact CDF comparisons are needed. The returned value is no
    smaller than the exact upper root and differs from it by at most 2**(-bits).
    ``alpha`` is the one-sided failure allocation, already adjusted for any
    prespecified multiplicity. The case count=n returns 1 exactly.
    """
    count, n = _count_inputs(count, n)
    alpha = _rational(alpha, "alpha")
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie strictly between 0 and 1")
    bits = _integer(bits, "bits")
    if bits > 128:
        raise ValueError("bits must be <= 128")
    if count == n:
        return ONE
    denominator = 1 << bits
    lo, hi = 0, denominator
    while hi - lo > 1:
        mid = (lo + hi) // 2
        p = Fraction(mid, denominator)
        if _cdf_at_most(count, n, p, alpha):
            hi = mid
        else:
            lo = mid
    return Fraction(hi, denominator)


def verify_failure_upper(
    count: int, n: int, alpha: Fraction | int, upper: Fraction | int
) -> bool:
    """Direct exact check of an emitted upper limit, without root inversion."""
    count, n = _count_inputs(count, n)
    alpha = _rational(alpha, "alpha")
    upper = _rational(upper, "upper")
    if not 0 < alpha < 1 or not 0 <= upper <= 1:
        raise ValueError("alpha must lie in (0,1) and upper in [0,1]")
    if count == n:
        return upper == 1
    return _cdf_at_most(count, n, upper, alpha)


def mc_failure_lower(
    count: int, n: int, alpha: Fraction | int = Fraction(1, 20), bits: int = 24
) -> Fraction:
    """Outward one-sided binomial lower confidence limit by complementation."""
    count, n = _count_inputs(count, n)
    return 1 - mc_failure_upper(n - count, n, alpha, bits)


def familywise_alpha(total_alpha: Fraction | int, number_of_bounds: int) -> Fraction:
    """Equal Bonferroni allocation for a fixed declared collection of bounds."""
    total_alpha = _rational(total_alpha, "total_alpha")
    number_of_bounds = _integer(number_of_bounds, "number_of_bounds", 1)
    if not 0 < total_alpha < 1:
        raise ValueError("total_alpha must lie strictly between 0 and 1")
    return total_alpha / number_of_bounds


def mc_family_failure_upper(
    count: int, n: int, *, family_cells: int = 12,
    total_alpha: Fraction | int = Fraction(1, 20), bits: int = 24,
) -> Fraction:
    """Simultaneous upper limit under an equal fixed family allocation."""
    return mc_failure_upper(count, n, familywise_alpha(total_alpha, family_cells), bits)


def rate_interval(
    count: int, n: int, alpha: Fraction | int = Fraction(1, 20), bits: int = 24,
) -> tuple[Fraction, Fraction]:
    """Pointwise two-sided Clopper--Pearson interval for a declared event rate.

    Default coverage is at least 95% for this one rate. Multiple pointwise
    intervals do not provide simultaneous coverage unless alpha is allocated
    externally for that collection. They can accompany descriptive event rates.
    """
    alpha = _rational(alpha, "alpha")
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie strictly between 0 and 1")
    return (mc_failure_lower(count, n, alpha / 2, bits),
            mc_failure_upper(count, n, alpha / 2, bits))


def summarize_joint_failures(
    definite_failures: int,
    oracle_unresolved: int,
    repetitions: int,
    alpha: Fraction | int,
    bits: int = 24,
    *,
    operational_unavailable: int = 0,
) -> dict:
    """Summarize a declared joint-failure event without deleting oracle ambiguity.

    This helper never silently conditions on issued certificates and requires
    the complete prespecified repetition count. Oracle-unresolved runs and any
    operational-unavailable runs are charged as failures for the conservative
    MC upper bound. These three categories must be disjoint; the caller is
    responsible for classification. Counting operational unavailability gives
    a stronger procedure-level failure event than erroneous certificate issuance
    alone. The risk theorem does not promise a 95% certificate issuance rate.
    """
    definite_failures, repetitions = _count_inputs(definite_failures, repetitions)
    oracle_unresolved = _integer(oracle_unresolved, "oracle_unresolved")
    operational_unavailable = _integer(operational_unavailable, "operational_unavailable")
    conservative = definite_failures + oracle_unresolved + operational_unavailable
    if conservative > repetitions:
        raise ValueError("failure and unresolved counts exceed repetitions")
    alpha = _rational(alpha, "alpha")
    upper = mc_failure_upper(conservative, repetitions, alpha, bits)
    return {
        "repetitions": repetitions,
        "definite_failures": definite_failures,
        "oracle_unresolved": oracle_unresolved,
        "operational_unavailable": operational_unavailable,
        "conservative_failure_count": conservative,
        "observed_failure_fraction_lower": Fraction(definite_failures, repetitions),
        "observed_failure_fraction_upper": Fraction(conservative, repetitions),
        "mc_alpha": alpha,
        "mc_failure_probability_upper": upper,
        "mc_upper_direct_check": verify_failure_upper(conservative, repetitions, alpha, upper),
    }


__all__ = [
    "binomial_cdf_exact", "mc_failure_upper", "mc_failure_lower",
    "verify_failure_upper", "familywise_alpha", "mc_family_failure_upper",
    "rate_interval", "summarize_joint_failures",
]
