"""Independently aggregate archived endpoints and check the manuscript table.

This script uses only the Python standard library and imports no archived
experiment/verifier code. It checks arithmetic, table transcription, and
completeness. It does not solve the optimization problems, generate new
calibration observations, or prove statistical coverage.
"""

from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import statistics
import time


LABELS = {
    "Collapsed binary": "collapsed_binary",
    "Two-atom partial": "two_atom_partial",
    "Three-point V": "three_point_v",
    "Five-point zigzag": "five_point_zigzag",
    "Partial collapse": "partial_collapse",
    "Noisy affine": "noisy_affine",
    "Rare conflict": "rare_conflict",
    "Affine mismatch": "affine_mismatch",
}
METHODS = ["block_2", "block_4", "block_8", "block_16", "block_32", "full_erm"]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def check(results: Path, table: Path, output: Path) -> dict:
    started = time.perf_counter()
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite {output}")
    rows = read_csv(results / "endpoints.csv")
    groups = defaultdict(list)
    identities = set()
    for row in rows:
        group = (row["law"], int(row["n"]), row["method"])
        identity = (*group, int(row["repetition"]))
        if identity in identities:
            raise AssertionError(f"Duplicate endpoint: {identity}")
        identities.add(identity)
        groups[group].append(row)
    expected_groups = {(law, n, method) for law in LABELS.values()
                       for n in (256, 1024, 4096) for method in METHODS}
    if set(groups) != expected_groups or len(rows) != 14400:
        raise AssertionError("Incomplete or unexpected endpoint grid")
    for group, values in groups.items():
        if {int(row["repetition"]) for row in values} != set(range(100)):
            raise AssertionError(f"Repetitions incomplete for {group}")

    summaries = read_csv(results / "summary.csv")
    summary_index = {(r["law"], int(r["n"]), r["method"]): r for r in summaries}
    if len(summaries) != len(summary_index) or set(summary_index) != expected_groups:
        raise AssertionError("Incomplete or duplicated summary grid")
    recalculated = {}
    max_summary_difference = 0.0
    for group, values in groups.items():
        lowers = [float(r["lower"]) for r in values]
        scores = [float(r["mean"]) for r in values]
        calculated = {
            "mean_lower": statistics.fmean(lowers),
            "sd_lower": statistics.stdev(lowers),
            "mean_score": statistics.fmean(scores),
            "sd_score": statistics.stdev(scores),
        }
        reported = summary_index[group]
        for column, value in calculated.items():
            difference = abs(float(reported[column]) - value)
            max_summary_difference = max(max_summary_difference, difference)
            if difference > 1e-12:
                raise AssertionError(f"Summary mismatch: {group}, {column}")
        failures = sum(int(row["coverage_failure"]) for row in values)
        if int(reported["coverage_failures"]) != failures or int(reported["repetitions"]) != 100:
            raise AssertionError(f"Summary counts mismatch: {group}")
        recalculated[group] = calculated

    population = {r["law"]: r for r in json.loads((results / "population.json").read_text())}
    cells = []
    seen_laws = set()
    for line in table.read_text().splitlines():
        parts = [part.strip() for part in line.strip().removesuffix("\\\\").split("&")]
        if not parts or parts[0] not in LABELS:
            continue
        if len(parts) != 8:
            raise AssertionError(f"Unexpected table layout: {line}")
        law = LABELS[parts[0]]
        if law in seen_laws:
            raise AssertionError(f"Duplicate manuscript law: {law}")
        seen_laws.add(law)
        recorded_population = population[law]
        population_midpoint = (recorded_population["optimum_lower"]
                               + recorded_population["optimum_upper"]) / 2
        values = [("risk", population_midpoint)] + [
            (method, recalculated[(law, 4096, method)]["mean_lower"])
            for method in METHODS
        ]
        for displayed, (column, recomputed) in zip(parts[1:], values):
            rounded = f"{recomputed:.4f}"
            if displayed != rounded:
                raise AssertionError(f"Table mismatch: {law}, {column}: {displayed} vs {rounded}")
            cells.append({
                "law": law,
                "column": column,
                "displayed": displayed,
                "recomputed": recomputed,
                "four_decimal_match": True,
                "absolute_rounding_difference": abs(float(displayed) - recomputed),
            })
    if seen_laws != set(LABELS.values()) or len(cells) != 56:
        raise AssertionError("Incomplete manuscript table")
    report = {
        "verified": True,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "check_kind": "Newly authored independent arithmetic and manuscript-table check",
        "python_version": platform.python_version(),
        "script_sha256": sha256(Path(__file__)),
        "input_sha256": {str(path): sha256(path) for path in [
            results / "endpoints.csv", results / "summary.csv", results / "population.json", table
        ]},
        "endpoint_rows_checked": len(rows),
        "groups_checked": len(groups),
        "repetitions_per_group": 100,
        "summary_numeric_values_recalculated": 4 * len(groups),
        "maximum_summary_difference": max_summary_difference,
        "manuscript_rows_checked": len(seen_laws),
        "manuscript_numeric_cells_checked": len(cells),
        "all_manuscript_cells_match_four_decimal_rounding": True,
        "maximum_display_rounding_difference": max(c["absolute_rounding_difference"] for c in cells),
        "archived_coverage_failure_flags_sum": sum(int(r["coverage_failure"]) for r in rows),
        "risk_column_scope": "Compared to the midpoint of each archived primal/dual population risk bracket; no optimization rerun in this script.",
        "scope": "Arithmetic/completeness/transcription check on fixed archived results; does not establish independent statistical coverage or new empirical evidence.",
        "elapsed_seconds": time.perf_counter() - started,
        "manuscript_cells": cells,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x") as handle:
        json.dump(report, handle, indent=2)
        handle.write("\n")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--table", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = check(args.results, args.table, args.output)
    print(json.dumps({k: v for k, v in result.items() if k not in ("input_sha256", "manuscript_cells")}, indent=2))
