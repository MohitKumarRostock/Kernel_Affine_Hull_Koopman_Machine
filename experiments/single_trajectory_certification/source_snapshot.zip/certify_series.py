#!/usr/bin/env python3
"""Single-trajectory risk certification, with exact numerical checking.

Run:    python certify_series.py run --series series.json --config config.json --out report.json
Check:  python certify_series.py check --series series.json --config config.json --report report.json

The scientific stationarity/support/mixing premises are supplied assumptions.
The code verifies numerical inequalities, the declared layout, and decisions.
It cannot establish scientific premises or historical preregistration from a
finite file. All risk statements are explicitly conditional on those premises.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import sys

from certified_kl import dyadic_floor, dyadic_ceil, kl_enclosure, verify_endpoint
from certified_lower import lower_certificate, verify_lower_certificate
from certified_models import fit_candidates, encode, predict_exact, verify_model

VERSION = "single_trajectory_reference_v1"
PREMISES = "Scientific support, strict stationarity and the dependence envelope are supplied assumptions. The layout, failure allocations, tolerance and candidate-setting rules are fixed without calibration-driven tuning; development-only learning is allowed. The numerical claims below are checked."
RISK_TARGET = "stationary-law average normalized squared prediction error; unconditional coverage over the whole experiment"
ZERO, ONE = Fraction(0), Fraction(1)
RATIONAL = re.compile(r"-?\d+/[1-9]\d*\Z")


def pack(value):
    """JSON rationals are exact n/d strings, never decimal float approximations."""
    if isinstance(value, Fraction):
        return f"{value.numerator}/{value.denominator}"
    if isinstance(value, dict):
        return {k: pack(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [pack(v) for v in value]
    return value


def unpack(value):
    if isinstance(value, str) and RATIONAL.fullmatch(value):
        return Fraction(value)
    if isinstance(value, dict):
        return {k: unpack(v) for k, v in value.items()}
    if isinstance(value, list):
        return [unpack(v) for v in value]
    return value


def digest(value):
    content = json.dumps(pack(value), sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def rational(value, name):
    if isinstance(value, bool) or not isinstance(value, (str, int, Fraction)):
        raise ValueError(f"{name}: use an integer or an exact decimal/fraction string")
    try:
        return Fraction(value)
    except (ValueError, ZeroDivisionError) as exc:
        raise ValueError(f"{name}: invalid finite rational value") from exc


def integer(value, name, low=1, high=None):
    if isinstance(value, bool) or not isinstance(value, int) or value < low or (high is not None and value > high):
        raise ValueError(f"{name}: invalid integer")
    return value


def mapping(value, name):
    if not isinstance(value, dict):
        raise ValueError(f"{name} must be a JSON object")
    return value


def required_text(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a nonempty explanation string")
    return value


def decimal_bound(value, direction, places=8):
    """A display bound, also outward; the n/d record remains authoritative."""
    scale = 10 ** places
    n = value.numerator * scale
    v = n // value.denominator if direction == "down" else -((-n) // value.denominator)
    sign = "-" if v < 0 else ""
    v = abs(v)
    return f"{sign}{v // scale}.{v % scale:0{places}d}"


def read_series(path):
    raw = json.loads(Path(path).read_text())
    if not isinstance(raw, list) or not raw:
        raise ValueError("series.json must be a nonempty JSON array of integer or string observations")
    return [rational(v, f"observation {i+1}") for i, v in enumerate(raw)]


def dependence_upper(spec, gap):
    """Exact conservative evaluation of an externally justified beta envelope."""
    spec = mapping(spec, "dependence")
    required_text(spec.get("justification"), "dependence justification")
    kind = spec.get("kind")
    if kind == "geometric":
        C, rho = rational(spec.get("C"), "C"), rational(spec.get("rho"), "rho")
        if C < 0 or not 0 <= rho < 1:
            raise ValueError("geometric envelope requires C>=0 and 0<=rho<1")
        return min(ONE, C * rho ** gap)
    if kind == "exponential":
        C, r = rational(spec.get("C"), "C"), rational(spec.get("r"), "r")
        terms = integer(spec.get("series_terms", 64), "series_terms", 1, 512)
        if C < 0 or r <= 0:
            raise ValueError("exponential envelope requires C>=0 and r>0")
        x, term, total = Fraction(gap) / r, ONE, ONE
        for j in range(1, terms + 1):
            term *= x / j
            total += term
        # total <= exp(x), so C/total >= C*exp(-x).
        return min(ONE, C / total)
    if kind == "at_lag":
        if integer(spec.get("lag"), "envelope lag") != gap:
            raise ValueError("supplied dependence bound is for a different lag")
        bound = rational(spec.get("bound"), "dependence bound")
        if not 0 <= bound <= 1:
            raise ValueError("dependence bound must be in [0,1]")
        return bound
    raise ValueError("dependence kind must be geometric, exponential, or at_lag")


def prepare(series, config):
    config = mapping(config, "configuration")
    if integer(config.get("schema_version"), "schema_version") != 1:
        raise ValueError("unsupported configuration schema")
    if not series:
        raise ValueError("empty series")
    series = [rational(v, "series observation") for v in series]
    support = mapping(config.get("support", {}), "support")
    a, b = rational(support.get("lower"), "support lower"), rational(support.get("upper"), "support upper")
    required_text(support.get("justification"), "support justification")
    if a >= b:
        raise ValueError("a justified support interval with lower<upper is required")
    if any(v < a or v > b for v in series):
        raise ValueError("an observation violates the declared support; no clipping or deletion is allowed")
    stationarity = mapping(config.get("stationarity", {}), "stationarity")
    required_text(stationarity.get("justification"), "stationarity justification")
    if stationarity.get("asserted") is not True:
        raise ValueError("strict stationarity, including initialization, must be explicitly justified")
    design = mapping(config.get("design", {}), "design")
    required_text(design.get("provenance"), "design provenance")
    if design.get("prespecified") is not True:
        raise ValueError("the fixed design needs a stated data-independent provenance")
    d = integer(design.get("history"), "history")
    n0 = integer(design.get("development_count"), "development_count", d + 1)
    q = integer(design.get("block_windows"), "block_windows")
    g = integer(design.get("gap_lag"), "gap_lag")
    K = integer(design.get("blocks"), "blocks")
    ell = d + q
    last = n0 + K * (ell + g - 1)
    if last > len(series):
        raise ValueError(f"insufficient observations: design needs {last}, file contains {len(series)}")
    tau = rational(config.get("risk_tolerance"), "risk_tolerance")
    delta = rational(config.get("failure_probability", "1/20"), "failure_probability")
    ds = rational(config.get("statistical_budget", "1/25"), "statistical_budget")
    dd = rational(config.get("dependence_budget", "1/100"), "dependence_budget")
    if not 0 <= tau <= 1 or not 0 < delta < 1 or not 0 < ds < 1 or dd < 0 or ds + dd > delta:
        raise ValueError("invalid tolerance or failure-budget allocation")
    beta = dependence_upper(config.get("dependence", {}), g)
    eta = K * beta
    if eta > dd:
        raise ValueError("the verified K*beta(g) exceeds the registered dependence budget")
    settings = mapping(config.get("candidates", {}), "candidates")
    kwargs = {
        "groups": integer(settings.get("groups", 2), "groups"),
        "score_scale": rational(settings.get("score_scale", "1"), "score_scale"),
        "eta": rational(settings.get("eta", "1/16"), "affinity eta"),
        "omega": integer(settings.get("omega", 2), "omega"),
        "axis_rule": settings.get("axis_rule", "latest"),
        "ridge": rational(settings.get("ridge", "1/1000"), "ridge"),
        "coefficient_bits": integer(settings.get("coefficient_bits", 24), "coefficient_bits", 1, 64),
        "feature_scale": rational(settings.get("feature_scale", "1"), "feature_scale"),
    }
    kappa = rational(settings.get("kappa", "2"), "kappa")
    if kappa < 0:
        raise ValueError("kappa must be nonnegative")
    num = mapping(config.get("numerics", {}), "numerics")
    numerical = {
        "loss_bits": integer(num.get("loss_bits", 32), "loss_bits", 1, 64),
        "mean_bits": integer(num.get("mean_bits", 20), "mean_bits", 1, 64),
        "endpoint_bits": integer(num.get("endpoint_bits", 24), "endpoint_bits", 1, 64),
        "log_terms": integer(num.get("log_terms", 128), "log_terms", 1, 512),
        "lower": {
            "neighbors": integer(num.get("neighbors", 2), "neighbors"),
            "max_orders": integer(num.get("max_orders", 4), "max_orders"),
            "sweeps": integer(num.get("sweeps", 8), "sweeps", 0),
            "distance_bits": integer(num.get("distance_bits", 32), "distance_bits", 1, 64),
            "multiplier_bits": integer(num.get("multiplier_bits", 24), "multiplier_bits", 1, 64),
            "output_bits": integer(num.get("lower_bits", 40), "lower_bits", 1, 64),
        },
    }
    z = [(v - a) / (b - a) for v in series]
    # One-based audit indices, translated to Python slices only here.
    blocks = []
    for k in range(K):
        start = n0 + g + k * (ell + g - 1)
        blocks.append({"first_raw": start, "last_raw": start + ell - 1,
                       "first_origin": start + d - 1, "last_origin": start + d + q - 2})
    layout = {"T": len(series), "development_count": n0, "history": d,
              "block_windows": q, "blocks_count": K, "gap_lag": g,
              "omitted_per_gap": g - 1, "raw_block_length": ell,
              "last_used_raw": last, "trailing_unused": len(series) - last,
              "N": K * q, "blocks": blocks}
    return {"series": series, "z": z, "layout": layout, "tau": tau,
            "delta": delta, "delta_stat": ds, "delta_dep": dd,
            "beta_upper": beta, "dependence_allowance": eta,
            "kappa": kappa, "fit_kwargs": kwargs, "numerics": numerical}


def calibration_windows(prepared):
    z, layout = prepared["z"], prepared["layout"]
    d, q = layout["history"], layout["block_windows"]
    histories, targets = [], []
    for block in layout["blocks"]:
        start = block["first_raw"] - 1
        for j in range(q):
            histories.append(z[start + j:start + j + d])
            targets.append(z[start + j + d])
    return histories, targets


def fit_registered(prepared):
    L = prepared["layout"]
    return fit_candidates(prepared["z"][:L["development_count"]], L["history"],
                          prepared["kappa"], **prepared["fit_kwargs"])


def upper_mean(model, histories, targets, loss_bits):
    total = ZERO
    for x, y in zip(histories, targets):
        prediction = predict_exact(model, x)
        if not 0 <= prediction <= 1:
            raise ValueError("declared clipped predictor produced an invalid value")
        total += dyadic_ceil((y - prediction) ** 2, loss_bits)
    return total / len(targets)


def decisions(candidates, tau):
    rows = []
    for row in candidates:
        L, U = row["L"], row["U"]
        status = "accepted" if U <= tau else ("excluded" if L > tau else "unresolved")
        rows.append({"candidate_id": row["candidate_id"], "cost": row["cost"],
                     "status": status, "L": L, "U": U,
                     "L_display": decimal_bound(L, "down"),
                     "U_display": decimal_bound(U, "up")})
    unexcluded = [r for r in rows if r["L"] <= tau]
    accepted = sorted((r for r in rows if r["U"] <= tau), key=lambda r:(r["cost"], r["candidate_id"]))
    cminus = min((r["cost"] for r in unexcluded), default=None)
    cplus = accepted[0]["cost"] if accepted else None
    return {"candidates": rows,
            "selected_candidate_id": accepted[0]["candidate_id"] if accepted else None,
            "cost_lower": cminus, "cost_upper": cplus,
            "null_cost_means": "positive infinity (empty minimum)",
            "minimum_feasible_cost_certified": cplus is not None and cminus == cplus,
            "entire_family_excluded": all(r["status"] == "excluded" for r in rows)}


def certify(series, config):
    p = prepare(series, config)
    models = fit_registered(p)  # Only development is passed to the learner.
    if len(models) != 3:
        raise ValueError("reference family must contain exactly three candidates")
    # Freeze this hash before inspecting calibration histories or targets.
    frozen_hash = digest(models)
    histories, targets = calibration_windows(p)
    K, num = p["layout"]["blocks_count"], p["numerics"]
    alpha = p["delta_stat"] / (2 * len(models))
    candidates = []
    for model in models:
        verify_model(model)
        features = [encode(model, x) for x in histories]
        low = lower_certificate(features, targets, model["kappa"], **num["lower"])
        rbar = upper_mean(model, histories, targets, num["loss_bits"])
        low_input = dyadic_floor(low["lower_empirical"], num["mean_bits"])
        up_input = dyadic_ceil(rbar, num["mean_bits"])
        lower = kl_enclosure(low_input, K, alpha, side="lower", bits=num["endpoint_bits"], max_terms=num["log_terms"])
        upper = kl_enclosure(up_input, K, alpha, side="upper", bits=num["endpoint_bits"], max_terms=num["log_terms"])
        candidates.append({"candidate_id": model["candidate_id"], "cost": model["coordinate_cost"],
                           "model": model, "features_sha256": digest(features),
                           "lower_certificate": low, "upper_empirical": rbar,
                           "lower_kl_input": low_input, "upper_kl_input": up_input,
                           "L": lower.value, "U": upper.value})
    if digest(models) != frozen_hash:
        raise ValueError("candidate mutation after freezing")
    report = {"schema": VERSION, "status": "conditional_certificate",
              "premises": PREMISES, "risk_target": RISK_TARGET,
              "config_sha256": digest(config), "series_sha256": digest(p["series"]),
              "development_sha256": digest(p["z"][:p["layout"]["development_count"]]),
              "frozen_models_sha256": frozen_hash, "layout": p["layout"],
              "beta_upper": p["beta_upper"], "dependence_allowance": p["dependence_allowance"],
              "statistical_allowance": p["delta_stat"], "alpha_per_endpoint": alpha,
              "coverage_at_least": 1 - p["delta_stat"] - p["dependence_allowance"],
              "risk_tolerance": p["tau"], "candidates": candidates,
              "selection": decisions(candidates, p["tau"])}
    return report


def verify_report(series, config, report):
    """Check from raw observations; never rerun graph optimization or KL search.

    Development fitting is reproduced to check the declared data flow. This is
    an independent checking path, not an independently implemented arithmetic
    library, proof assistant, or authentication of preregistration/provenance.
    """
    p = prepare(series, config)
    report = mapping(report, "report")
    if report.get("schema") != VERSION or report.get("status") != "conditional_certificate":
        raise ValueError("report does not contain a certificate of this version")
    models = fit_registered(p)
    if len(models) != 3:
        raise ValueError("wrong candidate family")
    alpha = p["delta_stat"] / (2 * len(models))
    expected = {"premises": PREMISES, "risk_target": RISK_TARGET,
                "config_sha256": digest(config), "series_sha256": digest(p["series"]),
                "development_sha256": digest(p["z"][:p["layout"]["development_count"]]),
                "frozen_models_sha256": digest(models), "layout": p["layout"],
                "beta_upper": p["beta_upper"], "dependence_allowance": p["dependence_allowance"],
                "statistical_allowance": p["delta_stat"], "alpha_per_endpoint": alpha,
                "coverage_at_least": 1 - p["delta_stat"] - p["dependence_allowance"],
                "risk_tolerance": p["tau"]}
    for key, value in expected.items():
        if report.get(key) != value:
            raise ValueError(f"report metadata mismatch: {key}")
    rows = report.get("candidates", [])
    if not isinstance(rows, list) or len(rows) != len(models):
        raise ValueError("candidate count mismatch")
    histories, targets = calibration_windows(p)
    K, num = p["layout"]["blocks_count"], p["numerics"]
    for model, row in zip(models, rows):
        row = mapping(row, "candidate report")
        if row.get("model") != model or row.get("candidate_id") != model["candidate_id"] or row.get("cost") != model["coordinate_cost"]:
            raise ValueError("frozen model or candidate identity mismatch")
        verify_model(model)
        features = [encode(model, x) for x in histories]
        if row.get("features_sha256") != digest(features):
            raise ValueError("raw-history feature reconstruction mismatch")
        verify_lower_certificate(features, targets, model["kappa"], row["lower_certificate"])
        rbar = upper_mean(model, histories, targets, num["loss_bits"])
        low_input = dyadic_floor(row["lower_certificate"]["lower_empirical"], num["mean_bits"])
        up_input = dyadic_ceil(rbar, num["mean_bits"])
        if row.get("upper_empirical") != rbar or row.get("lower_kl_input") != low_input or row.get("upper_kl_input") != up_input:
            raise ValueError("empirical bound or outward input rounding mismatch")
        if not verify_endpoint(low_input, K, alpha, row["L"], side="lower", max_terms=num["log_terms"]):
            raise ValueError("lower population endpoint was not verified")
        if not verify_endpoint(up_input, K, alpha, row["U"], side="upper", max_terms=num["log_terms"]):
            raise ValueError("upper population endpoint was not verified")
        if not ZERO <= row["L"] <= row["U"] <= ONE:
            raise ValueError("inconsistent population interval")
    if report.get("selection") != decisions(rows, p["tau"]):
        raise ValueError("selection or minimum-cost claim mismatch")
    return {"numerical_verification": "passed", "candidates_checked": len(models),
            "windows_checked_per_candidate": len(targets), "statistical_units": K,
            "scientific_assumptions": "supplied, not inferred or verified from the data"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("run", "check"))
    parser.add_argument("--series", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--out")
    parser.add_argument("--report")
    args = parser.parse_args()
    if args.command == "run" and not args.out:
        parser.error("run requires --out")
    if args.command == "check" and not args.report:
        parser.error("check requires --report")
    try:
        config = json.loads(Path(args.config).read_text())
        series = read_series(args.series)
        if args.command == "run":
            report = certify(series, config)
            checked = verify_report(series, config, report)
            Path(args.out).write_text(json.dumps(pack(report), indent=2, allow_nan=False) + "\n")
            print(json.dumps(pack({"status": report["status"], "coverage_at_least": report["coverage_at_least"],
                                   "selection": report["selection"], "check": checked}), indent=2))
        else:
            report = unpack(json.loads(Path(args.report).read_text()))
            print(json.dumps(verify_report(series, config, report), indent=2))
    except (ValueError, KeyError, TypeError, ArithmeticError, OSError) as exc:
        failure = {"schema": VERSION, "status": "unavailable", "reason": str(exc), "population_certificate_issued": False}
        if args.command == "run":
            Path(args.out).write_text(json.dumps(failure, indent=2) + "\n")
        print(json.dumps(failure, indent=2), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
