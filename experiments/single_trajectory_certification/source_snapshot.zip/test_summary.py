"""Analysis-only fixtures; no scientific simulation outcomes are read or changed."""

from copy import deepcopy
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from certify_series import pack
from experiment_statistics import mc_failure_upper
from summarize_experiment import cell_summary, paired_summary, summarize


def completed(replicate, *, accepted=False, event="covered", infinite_cost=False):
    candidates = []
    for kind, cost in [("raw",6),("memberships",2),("local_position",4)]:
        low = F(3,10) if infinite_cost else F(1,100)
        high = F(2,5) if infinite_cost else (F(2,25) if accepted and kind=="local_position" else F(1,5))
        opt = F(7,20) if infinite_cost else F(1,25)
        fitted = F(3,8) if infinite_cost else F(1,20)
        oracle = {"exact":True,"oracle_gap":F(0),"method":"analytic_test_fixture",
                  "risk_fitted":fitted,"risk_opt_lower":opt,"risk_opt_upper":opt}
        if event=="violation" and kind=="local_position":
            oracle["risk_fitted"]=F(9,10)
        if event=="oracle_unresolved" and kind=="local_position":
            oracle.update({"exact":False,"risk_opt_lower":F(1,200),"risk_opt_upper":F(1,20),"oracle_gap":F(9,200)})
        decision = "excluded" if infinite_cost else ("accepted" if accepted and kind=="local_position" else "unresolved")
        candidates.append({"candidate_id":kind,"cost":cost,"L":low,"U":high,
                           "interval_width":high-low,"decision":decision,"oracle":oracle,
                           "true_feasibility":"infeasible" if infinite_cost else "feasible",
                           "false_acceptance":decision=="accepted" and oracle["risk_fitted"]>F(1,10),
                           "false_exclusion":False,"exclusion_truth_unresolved":False,
                           "empirical_lower":low,"empirical_upper":high})
    return {"replicate":replicate,"status":"completed","joint_risk_event":event,
            "verification":{"numerical_verification":"passed"},"seed_hex":str(replicate),
            "frozen_models_sha256":"same-model-fixture","theorem_coverage_at_least":F(19,20),
            "dependence_allowance":F(1,100),"any_accepted":accepted,"compressed_accepted":accepted,
            "selection":{"selected_candidate_id":"local_position" if accepted else None,
                         "cost_lower":None if infinite_cost else 2,"cost_upper":4 if accepted else None,
                         "entire_family_excluded":infinite_cost,"minimum_feasible_cost_certified":False},
            "oracle_cost":{"lower":None if infinite_cost else 2,"upper":None if infinite_cost else 2,"exact":True},
            "optimal_claim_event":"not_claimed","cost_bracket_event":"covered",
            "producer_cpu_seconds":1.0,"checker_cpu_seconds":0.5,"oracle_cpu_seconds":0.25,
            "candidates":candidates}


def unavailable(replicate):
    return {"replicate":replicate,"status":"operational_unavailable",
            "joint_risk_event":"operational_unavailable","seed_hex":str(replicate)}


def registered_protocol():
    # Only the registered design is read. No scientific results are accessed.
    protocol=json.loads(Path(__file__).with_name("protocol.json").read_text())
    protocol["repetitions_per_cell"]=2
    return protocol


def analysis_fixture(protocol):
    rows=[]
    for cell in protocol["cells"]:
        design=cell["config"]["design"]
        for replicate in range(protocol["repetitions_per_cell"]):
            row=unavailable(replicate)
            row.update({"cell_id":cell["cell_id"],"p":F(cell["p"]),"T":cell["T"],
                        "K":design["blocks"],"q":design["block_windows"],"g":design["gap_lag"],
                        "sweeps":cell["config"]["numerics"]["sweeps"]})
            rows.append(row)
    return rows


def analyze_fixture(protocol,rows):
    with tempfile.TemporaryDirectory() as directory:
        root=Path(directory)
        raw=json.dumps(protocol,sort_keys=True).encode()
        ph=hashlib.sha256(raw).hexdigest()
        (root/"protocol.json").write_bytes(raw)
        (root/"run_manifest.json").write_text(json.dumps({"protocol_sha256":ph}))
        records=[]
        for original in rows:
            row=deepcopy(original)
            row["protocol_sha256"]=ph
            records.append(json.dumps(pack(row)))
        (root/"runs.jsonl").write_text("\n".join(records)+"\n")
        return summarize(root/"protocol.json",root)


class SummaryTests(unittest.TestCase):
    def test_primary_counts_use_complete_registered_denominator_and_charge_uncertainty(self):
        cell=registered_protocol()["cells"][0]
        rows=[completed(0,accepted=True),completed(1,accepted=True,event="violation"),
              completed(2,event="oracle_unresolved"),unavailable(3)]
        result=cell_summary(cell,rows,4,F(1,240))
        self.assertEqual(result["joint"]["definite_failures"],1)
        self.assertEqual(result["joint"]["oracle_unresolved"],1)
        self.assertEqual(result["joint"]["operational_unavailable"],1)
        self.assertEqual(result["joint"]["conservative_failure_count"],3)
        self.assertEqual(result["joint"]["mc_failure_probability_upper"],mc_failure_upper(3,4,F(1,240)))
        self.assertEqual(result["any_accepted"]["fraction"],F(1,2))
        self.assertEqual(result["any_accepted"]["denominator"],4)
        local=next(c for c in result["candidates"] if c["candidate_id"]=="local_position")
        self.assertEqual(local["accepted"]["fraction"],F(1,2))
        self.assertEqual(local["unavailable_count"],1)

    def test_infinite_costs_are_explicit_and_not_treated_as_zero(self):
        cell=registered_protocol()["cells"][0]
        result=cell_summary(cell,[completed(0,infinite_cost=True),unavailable(1)],2,F(1,240))
        self.assertEqual(result["oracle_cost_counts"],{"infinity":1})
        self.assertEqual(result["cost_bracket_counts"],{"infinity:infinity":1})
        self.assertEqual(result["selected_counts"],{"none":1})
        self.assertEqual(result["cost_count_scope"]["completed_runs"],1)
        self.assertEqual(result["cost_count_scope"]["unavailable_runs"],1)
        self.assertEqual(result["all_excluded"]["fraction"],F(1,2))

    def test_paired_operational_gains_keep_all_pairs_and_numerical_differences_do_not_impute(self):
        base=[completed(0),unavailable(1),completed(2,accepted=True)]
        alt=[completed(0,accepted=True),completed(1,accepted=True),unavailable(2)]
        result=paired_summary({"base":base,"alt":alt},"base","alt",3)
        self.assertEqual(result["planned_pairs"],3)
        self.assertEqual(result["completed_pairs"],1)
        self.assertEqual(result["unavailable_pairs"],2)
        self.assertEqual(result["any_acceptance_gained"],1)
        self.assertEqual(result["operational_acceptance_gained_all_runs"],2)
        self.assertEqual(result["operational_acceptance_lost_all_runs"],1)

    def test_full_analysis_retains_unavailable_runs_and_rejects_missing_or_duplicate_ids(self):
        protocol=registered_protocol()
        rows=analysis_fixture(protocol)
        result=analyze_fixture(protocol,rows)
        self.assertEqual(result["total_runs"],24)
        self.assertEqual(result["global_counts_descriptive_only"]["operational_unavailable"],24)
        self.assertTrue(all(c["joint"]["mc_failure_probability_upper"]==1 for c in result["cells"]))
        with self.assertRaisesRegex(ValueError,"all registered replicates"):
            analyze_fixture(protocol,rows[:-1])
        with self.assertRaisesRegex(ValueError,"duplicate"):
            analyze_fixture(protocol,rows+[rows[0]])

    def test_status_mismatch_candidate_duplicates_and_missing_checker_are_rejected(self):
        protocol=registered_protocol()
        rows=analysis_fixture(protocol)
        invalid=deepcopy(rows)
        invalid[0]["joint_risk_event"]="covered"
        with self.assertRaisesRegex(ValueError,"status and primary event"):
            analyze_fixture(protocol,invalid)
        for mutation in ["duplicate_candidate","checker"]:
            invalid=deepcopy(rows)
            metadata=invalid[0]
            metadata.update(completed(metadata["replicate"]))
            if mutation=="duplicate_candidate":
                metadata["candidates"][1]=deepcopy(metadata["candidates"][0])
            else:
                metadata["verification"]["numerical_verification"]="failed"
            with self.subTest(mutation=mutation):
                with self.assertRaises(ValueError):
                    analyze_fixture(protocol,invalid)

    def test_family_budget_is_checked_before_reporting_bounds(self):
        protocol=registered_protocol()
        protocol["mc_failure_cell_alpha"]="1/20"
        with self.assertRaisesRegex(ValueError,"family budget"):
            analyze_fixture(protocol,analysis_fixture(protocol))


if __name__=="__main__":
    unittest.main()
