"""Exact rational forecasting witnesses for single-trajectory certification.

This is a deliberately explicit rational affine-score instance.  It is not an
implementation or verification of the Gaussian KAHM and radial/angular encoder
used in the supplied manuscripts' central experiments.  It retains the same
membership-weighted local-position construction.

All inputs to ``encode`` and ``predict_exact`` represent exact numbers.  Integers,
Fractions and exact rational/decimal strings are accepted; binary floats are
rejected.  Normalized histories must belong to [0, 1]^d.  Encoder centers and
directions are chosen from development only.  A floating-point ridge fit merely
proposes coefficients: the declared witness has stored rational coefficients,
is evaluated exactly, and its full-domain Lipschitz membership is checked by
the exact squared coefficient norm.  The encoder itself need not be Lipschitz
in raw-history distance for the Step 3 theorem.

The default family has dimensions d, 2, and 4.  No input-recovery or Markov-state
claim is attached to this compact family.  Local-position recovery requires the
separate positivity and stacked-rank conditions from the Enrichment manuscript.
"""

from __future__ import annotations

from copy import deepcopy
from fractions import Fraction
import hashlib
import json
import math
from typing import Any, Iterable


ZERO = Fraction(0)
ONE = Fraction(1)
KINDS = ("raw", "memberships", "local_position")


def _fraction(value: Any, name: str) -> Fraction:
    if isinstance(value, bool) or isinstance(value, float):
        raise TypeError(f"{name} must be exact (Fraction, integer or string), not float/bool")
    if not isinstance(value, (Fraction, int, str)):
        raise TypeError(f"{name} must be a Fraction, integer or exact numeric string")
    try:
        return Fraction(value)
    except (ValueError, ZeroDivisionError) as exc:
        raise ValueError(f"{name} is not a finite exact rational") from exc


def _integer(value: Any, name: str, minimum: int = 1) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def _history(values: Iterable[Any], d: int, name: str = "history") -> list[Fraction]:
    result = [_fraction(v, f"{name}[{i}]") for i, v in enumerate(values)]
    if len(result) != d:
        raise ValueError(f"{name} must contain exactly {d} entries")
    if any(v < ZERO or v > ONE for v in result):
        raise ValueError(f"{name} lies outside the declared normalized support [0,1]")
    return result


def _encoder_parameters(model: dict[str, Any]) -> tuple:
    if not isinstance(model, dict):
        raise TypeError("model must be a dictionary")
    if model.get("model_version") != 1:
        raise ValueError("unsupported model_version")
    kind = model.get("encoder_kind")
    if kind not in KINDS:
        raise ValueError("unknown encoder_kind")
    d = _integer(model.get("history"), "history")
    feature_scale = _fraction(model.get("feature_scale", ONE), "feature_scale")
    if feature_scale <= ZERO:
        raise ValueError("feature_scale must be strictly positive")
    if kind == "raw":
        return kind, d, feature_scale, [], [], ONE, ONE, 1, d
    centers = [_history(c, d, "center") for c in model.get("centers", [])]
    if not centers:
        raise ValueError("a geometric encoder must have at least one center")
    axes = list(model.get("axes", []))
    if len(axes) != len(centers):
        raise ValueError("each center must have one coordinate axis")
    for axis in axes:
        if isinstance(axis, bool) or not isinstance(axis, int) or not (0 <= axis < d):
            raise ValueError("each axis must be an integer coordinate index")
    s = _fraction(model.get("score_scale"), "score_scale")
    eta = _fraction(model.get("eta"), "eta")
    omega = _integer(model.get("omega"), "omega")
    if s <= ZERO or eta <= ZERO:
        raise ValueError("score_scale and eta must be strictly positive")
    p = len(centers) * (2 if kind == "local_position" else 1)
    return kind, d, feature_scale, centers, axes, s, eta, omega, p


def encode(model: dict[str, Any], history: Iterable[Any]) -> list[Fraction]:
    """Evaluate the declared encoder exactly, from normalized raw history.

    With coordinate-axis affine reconstruction, squared reconstruction residual
    is the sum of squared deviations in all coordinates except the chosen axis.
    T=r^2/(s+r^2), affinity=(1-T+eta)^omega, and normalized affinities are positive.
    The local map appends one weighted signed coordinate per center.
    """
    kind, d, scale, centers, axes, s, eta, omega, _ = _encoder_parameters(model)
    x = _history(history, d)
    if kind == "raw":
        return [scale * v for v in x]
    affinities = []
    for center, axis in zip(centers, axes):
        residual_squared = sum(
            ((x[k] - center[k]) ** 2 for k in range(d) if k != axis), ZERO
        )
        # 1 - r^2/(s+r^2) = s/(s+r^2), evaluated without cancellation.
        affinities.append((s / (s + residual_squared) + eta) ** omega)
    total = sum(affinities, ZERO)
    memberships = [a / total for a in affinities]
    result = memberships
    if kind == "local_position":
        result = result + [
            phi * (x[axis] - center[axis])
            for phi, center, axis in zip(memberships, centers, axes)
        ]
    return [scale * value for value in result]


def predict_exact(model: dict[str, Any], history: Iterable[Any]) -> Fraction:
    """Evaluate the stored clipped affine witness exactly.

    Call ``verify_model`` once before a batch if class membership is required.
    This function also checks coefficient dimension; it never substitutes a
    floating-point evaluation for the declared mathematical predictor.
    """
    features = encode(model, history)
    weights = [_fraction(w, "affine_weight") for w in model.get("affine_weights", [])]
    if len(weights) != len(features):
        raise ValueError("affine coefficient dimension does not match encoder")
    intercept = _fraction(model.get("intercept"), "intercept")
    value = intercept + sum((w * x for w, x in zip(weights, features)), ZERO)
    return max(ZERO, min(ONE, value))


def verify_model(model: dict[str, Any]) -> bool:
    """Check encoder shape and global clipped-affine decoder membership.

    Returns True, or raises.  Exact norm verification proves Lipschitz constant
    <= kappa on the whole Euclidean feature space, not just observed features.
    It does not establish scientific support/dependence assumptions or prove
    that an externally supplied model was fitted using development data only.
    """
    _, _, _, _, _, _, _, _, p = _encoder_parameters(model)
    kappa = _fraction(model.get("kappa"), "kappa")
    if kappa < ZERO:
        raise ValueError("kappa must be nonnegative")
    if _integer(model.get("coordinate_cost"), "coordinate_cost") != p:
        raise ValueError("coordinate_cost does not equal the declared encoder width")
    weights = [_fraction(w, "affine_weight") for w in model.get("affine_weights", [])]
    if len(weights) != p:
        raise ValueError("affine coefficient dimension does not match encoder")
    _fraction(model.get("intercept"), "intercept")
    if sum((w * w for w in weights), ZERO) > kappa * kappa:
        raise ValueError("exact squared coefficient norm exceeds kappa^2")
    if not isinstance(model.get("candidate_id"), str) or not model["candidate_id"]:
        raise ValueError("candidate_id must be a nonempty string")
    return True


def _quantize_float(value: float, bits: int) -> Fraction:
    if not math.isfinite(value):
        raise ValueError("nonfinite fitting proposal")
    denominator = 1 << bits
    return Fraction(round(Fraction.from_float(value) * denominator), denominator)


def _truncate_ratio(numerator: int, denominator: int) -> int:
    return numerator // denominator if numerator >= 0 else -((-numerator) // denominator)


def _repair_norm(weights: list[Fraction], kappa: Fraction, bits: int) -> list[Fraction]:
    """Conservatively project dyadic weights using integer arithmetic only."""
    if sum((w * w for w in weights), ZERO) <= kappa * kappa:
        return weights
    if kappa == ZERO:
        return [ZERO for _ in weights]
    denominator = 1 << bits
    integers = [int(w * denominator) for w in weights]
    if any(Fraction(n, denominator) != w for n, w in zip(integers, weights)):
        raise ValueError("norm repair expects coefficients on the declared dyadic grid")
    sum_squares = sum(n * n for n in integers)
    norm_upper = math.isqrt(sum_squares)
    if norm_upper * norm_upper != sum_squares:
        norm_upper += 1
    budget_lower = (kappa.numerator * denominator) // kappa.denominator
    repaired = [
        Fraction(_truncate_ratio(n * budget_lower, norm_upper), denominator)
        for n in integers
    ]
    if sum((w * w for w in repaired), ZERO) > kappa * kappa:
        raise ArithmeticError("internal exact norm-repair invariant failed")
    return repaired


def _solve_linear(matrix: list[list[float]], rhs: list[float]) -> list[float]:
    """Partial-pivot Gaussian solve used only to propose fitting coefficients."""
    n = len(rhs)
    rows = [list(a) + [b] for a, b in zip(matrix, rhs)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(rows[row][col]))
        if not math.isfinite(rows[pivot][col]) or rows[pivot][col] == 0.0:
            raise ArithmeticError("singular or nonfinite ridge proposal")
        rows[col], rows[pivot] = rows[pivot], rows[col]
        for row in range(col + 1, n):
            multiplier = rows[row][col] / rows[col][col]
            rows[row][col] = 0.0
            for j in range(col + 1, n + 1):
                rows[row][j] -= multiplier * rows[col][j]
    result = [0.0] * n
    for i in range(n - 1, -1, -1):
        result[i] = (rows[i][n] - math.fsum(rows[i][j] * result[j] for j in range(i + 1, n))) / rows[i][i]
    if not all(math.isfinite(x) for x in result):
        raise ArithmeticError("nonfinite ridge coefficients")
    return result


def _fit_witness(
    model: dict[str, Any],
    histories: list[list[Fraction]],
    targets: list[Fraction],
    ridge: Fraction,
    bits: int,
) -> None:
    p = model["coordinate_cost"]
    n = len(targets)
    mean_y = math.fsum(float(y) for y in targets) / n
    fallback = False
    fallback_reason = ""
    try:
        features = [[float(v) for v in encode(model, x)] for x in histories]
        if not all(math.isfinite(v) for row in features for v in row):
            raise ArithmeticError("nonfinite float feature proposal")
        regularizer = float(ridge)
        if not math.isfinite(regularizer) or regularizer <= 0.0:
            raise ArithmeticError("ridge is not representable as positive finite float")
        means = [math.fsum(row[j] for row in features) / n for j in range(p)]
        centered = [[row[j] - means[j] for j in range(p)] for row in features]
        gram = [
            [math.fsum(row[i] * row[j] for row in centered) / n + (regularizer if i == j else 0.0)
             for j in range(p)]
            for i in range(p)
        ]
        rhs = [
            math.fsum(row[j] * (float(y) - mean_y) for row, y in zip(centered, targets)) / n
            for j in range(p)
        ]
        proposal = _solve_linear(gram, rhs)
        weights = _repair_norm([_quantize_float(w, bits) for w in proposal], model["kappa"], bits)
        intercept = _quantize_float(mean_y - math.fsum(float(w) * mean for w, mean in zip(weights, means)), bits)
    except (ArithmeticError, OverflowError, ValueError) as exc:
        # A development-only constant predictor remains a valid frozen member.
        # Numerical fitting failure affects usefulness, not certificate validity.
        weights = [ZERO] * p
        intercept = _quantize_float(mean_y, bits)
        fallback = True
        fallback_reason = type(exc).__name__
    model["affine_weights"] = weights
    model["intercept"] = intercept
    model["training_count"] = n
    model["fitting"] = {
        "method": "centered_ridge_float_proposal_exact_dyadic_witness",
        "ridge": ridge,
        "coefficient_bits": bits,
        "constant_fallback": fallback,
        "fallback_reason": fallback_reason,
    }
    verify_model(model)


def _choose_axes(
    histories: list[list[Fraction]], centers: list[list[Fraction]], rule: str
) -> list[int]:
    d = len(histories[0])
    if rule == "latest":
        return [d - 1] * len(centers)
    if rule != "development_variance":
        raise ValueError("axis_rule must be 'latest' or 'development_variance'")
    groups: list[list[list[Fraction]]] = [[] for _ in centers]
    for x in histories:
        nearest = min(
            range(len(centers)),
            key=lambda j: (sum(((v - c) ** 2 for v, c in zip(x, centers[j])), ZERO), j),
        )
        groups[nearest].append(x)
    axes = []
    for group in groups:
        actual = group if group else histories
        n = len(actual)
        # n*sum(x^2)-sum(x)^2 is n^2 times the empirical variance.
        spread = [
            n * sum((x[k] ** 2 for x in actual), ZERO)
            - sum((x[k] for x in actual), ZERO) ** 2
            for k in range(d)
        ]
        axes.append(max(range(d), key=lambda k: (spread[k], k)))
    return axes


def fit_candidates(
    development: Iterable[Any],
    history: int,
    kappa: Any,
    *,
    groups: int = 2,
    score_scale: Any = ONE,
    eta: Any = Fraction(1, 16),
    omega: int = 2,
    axis_rule: str = "latest",
    ridge: Any = Fraction(1, 1000),
    coefficient_bits: int = 24,
    feature_scale: Any = ONE,
) -> list[dict[str, Any]]:
    """Fit and freeze the raw/membership/local-position candidate family.

    The caller supplies only the development prefix.  Every target used below is
    contained in that prefix.  Centers are development-history exemplars at
    deterministic midpoint quantiles after sorting by last coordinate, with the
    full history as tie breaker.  Repeated centers are valid.  Each local affine
    reconstruction retains one coordinate axis.  Geometry and all settings are
    identical for the membership and local-position candidates.

    ``ridge`` is the regularizer in a mean-loss ridge proposal with intercept.
    No training optimality claim is made.  ``feature_scale`` multiplies every
    coordinate and is part of the declared encoder and metric geometry.
    """
    d = _integer(history, "history")
    J = _integer(groups, "groups")
    bits = _integer(coefficient_bits, "coefficient_bits")
    if bits > 256:
        raise ValueError("coefficient_bits must be <= 256")
    kappa = _fraction(kappa, "kappa")
    s = _fraction(score_scale, "score_scale")
    eta = _fraction(eta, "eta")
    ridge = _fraction(ridge, "ridge")
    feature_scale = _fraction(feature_scale, "feature_scale")
    omega = _integer(omega, "omega")
    if kappa < ZERO or min(s, eta, ridge, feature_scale) <= ZERO:
        raise ValueError("kappa must be nonnegative; score/affinity/ridge/scaling values positive")
    values = [_fraction(v, "development observation") for v in development]
    if len(values) < d + 1:
        raise ValueError("development needs at least history+1 observations")
    if any(v < ZERO or v > ONE for v in values):
        raise ValueError("development observations must lie in [0,1]")
    histories = [values[t - d:t] for t in range(d, len(values))]
    targets = values[d:]
    ordered = sorted(histories, key=lambda x: (x[-1], tuple(x)))
    n = len(ordered)
    centers = [list(ordered[min(n - 1, ((2 * j + 1) * n) // (2 * J))]) for j in range(J)]
    axes = _choose_axes(histories, centers, axis_rule)
    common = {
        "model_version": 1,
        "history": d,
        "kappa": kappa,
        "centers": centers,
        "axes": axes,
        "score_scale": s,
        "eta": eta,
        "omega": omega,
        "feature_scale": feature_scale,
        "geometry": {
            "instance": "rational_affine_squared_residual_score",
            "center_rule": "development_midpoint_quantile_exemplars",
            "axis_rule": axis_rule,
            "rank_per_center": 1,
        },
    }
    result = []
    for kind, p in zip(KINDS, (d, J, 2 * J)):
        model = deepcopy(common)
        model["candidate_id"] = kind
        model["encoder_kind"] = kind
        model["coordinate_cost"] = p
        _fit_witness(model, histories, targets, ridge, bits)
        result.append(model)
    return result


def model_to_jsonable(model: dict[str, Any]) -> dict[str, Any]:
    """Return an exact JSON-compatible copy; Fractions become 'numerator/denominator'."""
    def convert(value: Any) -> Any:
        if isinstance(value, Fraction):
            return f"{value.numerator}/{value.denominator}"
        if isinstance(value, float):
            raise TypeError("floating-point values are not permitted in a frozen exact model")
        if isinstance(value, dict):
            return {str(k): convert(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [convert(v) for v in value]
        if isinstance(value, (str, int, bool)) or value is None:
            return value
        raise TypeError(f"unsupported model value type {type(value).__name__}")
    return convert(model)


def model_sha256(model: dict[str, Any]) -> str:
    """Hash the exact serialized model, including its declared fitting metadata.

    This identifies stored content; it does not authenticate training provenance.
    """
    payload = json.dumps(model_to_jsonable(model), sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(payload.encode("ascii")).hexdigest()


__all__ = [
    "fit_candidates", "encode", "predict_exact", "verify_model",
    "model_to_jsonable", "model_sha256",
]
