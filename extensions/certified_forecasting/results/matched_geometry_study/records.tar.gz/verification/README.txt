These records verify implementation with development seeds 915701--915703. They are not manuscript accuracy evidence. The full reference study uses seeds 5701--5705.
