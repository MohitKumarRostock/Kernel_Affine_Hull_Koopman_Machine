#!/usr/bin/env python3
"""Execute the frozen Step 5 repeated-trajectory protocol, retaining every run.

python run_experiment.py --workers 6 --output results
python run_experiment.py --workers 6 --output results --resume

The engine is the unchanged Step 4 implementation. Simulation oracles are
separate from certification and are never supplied to the learner or calibrator.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import platform
import random
import sys
import time
import traceback

from certify_series import certify, verify_report, pack, unpack, digest
from population_oracle import population_oracle

ROOT = Path(__file__).resolve().parent
SOURCE_FILES = ["run_experiment.py", "population_oracle.py", "experiment_statistics.py",
                "certify_series.py", "certified_models.py", "certified_lower.py", "certified_kl.py"]


def seed_for(namespace, p, replicate):
    text = f"{namespace}|p={Fraction(p)}|rep={replicate}"
    return int.from_bytes(hashlib.sha256(text.encode("utf-8")).digest(), "big")


def generate_series(p, length, seed):
    p = Fraction(p)
    if not 0 < p < 1 or length < 1:
        raise ValueError("experiment uses positive length and 0<p<1")
    rng = random.Random(seed)
    state = rng.randrange(2)
    values = [state]
    for _ in range(1, length):
        if rng.randrange(p.denominator) < p.numerator:
            state = 1 - state
        values.append(state)
    return values


def risk_event(L, U, oracle):
    """Three-way classification; interval ambiguity is never called coverage."""
    if oracle["risk_fitted"] > U or L > oracle["risk_opt_upper"]:
        return "violation"
    if L <= oracle["risk_opt_lower"]:
        return "covered"
    return "oracle_unresolved"


def class_feasibility(oracle, tau):
    if oracle["risk_opt_upper"] <= tau:
        return "feasible"
    if oracle["risk_opt_lower"] > tau:
        return "infeasible"
    return "oracle_unresolved"


def _min_cost(rows, keep):
    return min((r["cost"] for r in rows if keep(r)), default=None)


def oracle_costs(rows):
    lo = _min_cost(rows, lambda r: r["true_feasibility"] != "infeasible")
    hi = _min_cost(rows, lambda r: r["true_feasibility"] == "feasible")
    return {"lower": lo, "upper": hi, "exact": lo == hi,
            "null_means": "positive infinity"}


def _cost_number(value):
    return float("inf") if value is None else value


def check_cost_claim(selection, truth):
    """Check the emitted bracket against the independently verified oracle bracket."""
    cl, cu = map(_cost_number, (selection["cost_lower"], selection["cost_upper"]))
    tl, tu = map(_cost_number, (truth["lower"], truth["upper"]))
    if cl > tu or cu < tl:
        return "violation"
    if cl <= tl and cu >= tu:
        return "covered"
    return "oracle_unresolved"


def run_one(cell, replicate, namespace, protocol_hash, oracle_settings, save_dir):
    """One certification receives one trajectory. No cross-run learning occurs."""
    started = time.perf_counter()
    p = Fraction(cell["p"])
    seed = seed_for(namespace, p, replicate)
    row = {"cell_id": cell["cell_id"], "replicate": replicate, "p": p,
           "seed_hex": format(seed, "064x"), "protocol_sha256": protocol_hash,
           "T": cell["T"], "K": cell["config"]["design"]["blocks"],
           "q": cell["config"]["design"]["block_windows"],
           "g": cell["config"]["design"]["gap_lag"],
           "sweeps": cell["config"]["numerics"]["sweeps"]}
    report = None
    oracle_proofs = []
    try:
        t0 = time.process_time()
        series = generate_series(p, cell["T"], seed)
        row["generation_cpu_seconds"] = time.process_time() - t0
        t0 = time.process_time()
        report = certify(series, cell["config"])
        row["producer_cpu_seconds"] = time.process_time() - t0
        t0 = time.process_time()
        verification = verify_report(series, cell["config"], report)
        row["checker_cpu_seconds"] = time.process_time() - t0
        t0 = time.process_time()
        tau = report["risk_tolerance"]
        candidate_rows = []
        status_map = {r["candidate_id"]:r["status"] for r in report["selection"]["candidates"]}
        for candidate in report["candidates"]:
            oracle = population_oracle(candidate["model"], p, **oracle_settings, include_proof=False)
            event = risk_event(candidate["L"], candidate["U"], oracle)
            feasibility = class_feasibility(oracle, tau)
            status = status_map[candidate["candidate_id"]]
            candidate_rows.append({
                "candidate_id": candidate["candidate_id"], "cost": candidate["cost"],
                "L": candidate["L"], "U": candidate["U"], "decision": status,
                "interval_width": candidate["U"] - candidate["L"],
                "empirical_lower": candidate["lower_certificate"]["lower_empirical"],
                "empirical_upper": candidate["upper_empirical"],
                "graph_edge_count": len(candidate["lower_certificate"]["edges"]),
                "paired_count": len(candidate["lower_certificate"]["pairs"]),
                "graph_dual_sse": candidate["lower_certificate"]["graph_dual_sse"],
                "pair_sse": candidate["lower_certificate"]["pair_sse"],
                "oracle": oracle, "risk_event": event, "true_feasibility": feasibility,
                "false_acceptance": status == "accepted" and oracle["risk_fitted"] > tau,
                "false_exclusion": status == "excluded" and feasibility == "feasible",
                "exclusion_truth_unresolved": status == "excluded" and feasibility == "oracle_unresolved",
            })
        row["oracle_cpu_seconds"] = time.process_time() - t0
        events = [r["risk_event"] for r in candidate_rows]
        joint = ("violation" if "violation" in events else
                 "oracle_unresolved" if "oracle_unresolved" in events else "covered")
        truth = oracle_costs(candidate_rows)
        selection = report["selection"]
        cost_event = check_cost_claim(selection, truth)
        optimal_flag = selection["minimum_feasible_cost_certified"]
        selected = next((r for r in candidate_rows if r["candidate_id"] == selection["selected_candidate_id"]), None)
        selected_false_acceptance = selected is not None and selected["false_acceptance"]
        optimal_claim = ("not_claimed" if not optimal_flag else
                         "violation" if selected_false_acceptance else
                         "covered" if truth["exact"] and selection["cost_upper"] == truth["upper"] else
                         "violation" if truth["exact"] else "oracle_unresolved")
        row.update({"status": "completed", "joint_risk_event": joint,
                    "verification": verification, "series_sha256": report["series_sha256"],
                    "report_sha256": digest(report), "frozen_models_sha256": report["frozen_models_sha256"],
                    "theorem_coverage_at_least": report["coverage_at_least"],
                    "dependence_allowance": report["dependence_allowance"],
                    "candidates": candidate_rows, "selection": selection,
                    "oracle_cost": truth, "cost_bracket_event": cost_event,
                    "optimal_claim_event": optimal_claim,
                    "any_accepted": selection["selected_candidate_id"] is not None,
                    "compressed_accepted": selection["cost_upper"] is not None and selection["cost_upper"] < cell["config"]["design"]["history"]})
        exceptional = joint != "covered" or cost_event != "covered" or optimal_claim in ("violation", "oracle_unresolved")
        if replicate == 0 or exceptional:
            for candidate in report["candidates"]:
                oracle_proofs.append({"candidate_id":candidate["candidate_id"],
                                      "oracle":population_oracle(candidate["model"], p, **oracle_settings, include_proof=True)})
            payload = {"cell":cell, "replicate":replicate, "seed_hex":row["seed_hex"],
                       "protocol_sha256":protocol_hash,"report":report,"oracle_proofs":oracle_proofs}
            filename = f"{cell['cell_id']}_r{replicate:03d}.json"
            Path(save_dir, filename).write_text(json.dumps(pack(payload), separators=(",", ":"), allow_nan=False) + "\n")
            row["full_certificate_file"] = "certificates/" + filename
    except Exception as exc:
        # A scientific run is never dropped or silently replaced after failure.
        row.update({"status":"operational_unavailable", "joint_risk_event":"operational_unavailable",
                    "error_type":type(exc).__name__, "error":str(exc),
                    "traceback":traceback.format_exc()})
        filename = f"{cell['cell_id']}_r{replicate:03d}_unavailable.json"
        Path(save_dir, filename).write_text(json.dumps(pack({"cell":cell,"row":row,"report":report}),
                                                        separators=(",", ":"), allow_nan=False) + "\n")
        row["full_certificate_file"] = "certificates/" + filename
    row["run_wall_seconds"] = time.perf_counter() - started
    return row


def load_protocol(path):
    raw = Path(path).read_bytes()
    protocol = json.loads(raw)
    if protocol["protocol_version"] != "step5_fixed_v1" or len(protocol["cells"]) != 12:
        raise ValueError("unsupported experimental protocol")
    for name, expected in protocol["engine_sha256"].items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f"pinned Step 4 engine changed: {name}")
    return protocol, hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", default=str(ROOT/"protocol.json"))
    parser.add_argument("--output", default=str(ROOT/"results"))
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("workers must be positive")
    protocol, protocol_hash = load_protocol(args.protocol)
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    certificates = output/"certificates"
    certificates.mkdir(exist_ok=True)
    records = output/"runs.jsonl"
    source_hashes = {name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in SOURCE_FILES}
    manifest = {"protocol_sha256":protocol_hash,"source_sha256":source_hashes,
                "python_version":sys.version,"platform":platform.platform(),"workers":args.workers,
                "started_utc":datetime.now(timezone.utc).isoformat(),
                "timing_scope":"Per-process CPU seconds reported separately for producer, checker and oracle; not deployment latency.",
                "simulation_scope":"Pseudorandom independent-replicate simulation under stipulated mathematical laws; no empirical assumption estimation."}
    seen = set()
    if records.exists():
        if not args.resume:
            raise ValueError("existing outcomes require --resume; never overwrite scientific runs")
        previous = json.loads((output/"run_manifest.json").read_text())
        if previous["protocol_sha256"] != protocol_hash or previous["source_sha256"] != source_hashes:
            raise ValueError("resume source/protocol mismatch")
        for line in records.read_text().splitlines():
            row = json.loads(line)
            key = (row["cell_id"],row["replicate"])
            if key in seen or row["protocol_sha256"] != protocol_hash:
                raise ValueError("duplicate or mismatched stored outcome")
            seen.add(key)
    else:
        (output/"run_manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
    oracle_settings = {k:protocol["oracle"][k] for k in ("sweeps","distance_bits","multiplier_bits","primal_bits")}
    jobs = [(cell, rep) for rep in range(protocol["repetitions_per_cell"])
            for cell in protocol["cells"] if (cell["cell_id"],rep) not in seen]
    total = len(protocol["cells"]) * protocol["repetitions_per_cell"]
    start = time.perf_counter()
    completed = len(seen)
    print(json.dumps({"event":"start","total":total,"already_stored":completed,"pending":len(jobs),"workers":args.workers}),flush=True)
    with records.open("a", buffering=1) as handle, ProcessPoolExecutor(max_workers=args.workers) as executor:
        pending = {executor.submit(run_one, cell, rep, protocol["seed_namespace"], protocol_hash,
                                   oracle_settings, str(certificates)):(cell,rep) for cell,rep in jobs}
        for future in as_completed(pending):
            try:
                row = future.result()
            except Exception as exc:
                cell,rep = pending[future]
                row = {"cell_id":cell["cell_id"],"replicate":rep,"p":Fraction(cell["p"]),
                       "seed_hex":format(seed_for(protocol["seed_namespace"],cell["p"],rep),"064x"),
                       "protocol_sha256":protocol_hash,"status":"operational_unavailable",
                       "joint_risk_event":"operational_unavailable","error_type":type(exc).__name__,
                       "error":str(exc),"traceback":traceback.format_exc(),
                       "T":cell["T"],"K":cell["config"]["design"]["blocks"],
                       "q":cell["config"]["design"]["block_windows"],
                       "g":cell["config"]["design"]["gap_lag"],
                       "sweeps":cell["config"]["numerics"]["sweeps"]}
                filename=f"{cell['cell_id']}_r{rep:03d}_unavailable.json"
                (certificates/filename).write_text(json.dumps(pack({"cell":cell,"row":row}),separators=(",", ":"))+"\n")
                row["full_certificate_file"]="certificates/"+filename
            handle.write(json.dumps(pack(row),separators=(",", ":"),allow_nan=False)+"\n")
            completed += 1
            if completed % 50 == 0 or row["joint_risk_event"] != "covered" or completed == total:
                print(json.dumps({"event":"progress","completed":completed,"total":total,
                                  "elapsed_seconds":round(time.perf_counter()-start,2),
                                  "latest_status":row["joint_risk_event"]}),flush=True)
    (output/"completion.json").write_text(json.dumps({"expected":total,"stored":completed,
                                                     "completed_utc":datetime.now(timezone.utc).isoformat(),
                                                     "run_wall_seconds":time.perf_counter()-start},indent=2)+"\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
