"""Analytic and adversarial checks of the exact empirical lower certificate."""

from copy import deepcopy
from fractions import Fraction as F
import unittest

from certified_lower import (
    ceil_dyadic, evaluate_dual, floor_dyadic, lower_certificate,
    sqrt_upper, verify_lower_certificate,
)


class ExactLowerTests(unittest.TestCase):
    def test_sqrt_enclosures_and_grid_tightness(self):
        for value in [F(0), F(1), F(2), F(2, 9), F(10**80 + 1, 10**82 + 3)]:
            for bits in [0, 8, 32]:
                result = sqrt_upper(value, bits)
                self.assertGreaterEqual(result * result, value)
                if value:
                    previous = result - F(1, 1 << bits)
                    self.assertLess(previous * previous, value)

    def test_outward_rounding_including_negative_values(self):
        for value in [F(1, 3), F(-1, 3), F(0), F(17, 16)]:
            self.assertLessEqual(floor_dyadic(value, 8), value)
            self.assertGreaterEqual(ceil_dyadic(value, 8), value)

    def test_two_point_analytic_optimum(self):
        features, targets, kappa = [[F(0)], [F(1)]], [F(0), F(1)], F(1, 4)
        result = lower_certificate(features, targets, kappa)
        # Prediction difference is at most 1/4, giving SSE=(3/4)^2/2.
        optimum = F(9, 64)
        self.assertEqual(result["pair_sse"], F(9, 32))
        self.assertEqual(result["graph_dual_sse"], F(9, 32))
        self.assertEqual(result["lower_empirical"], optimum)
        self.assertTrue(verify_lower_certificate(features, targets, kappa, result))

    def test_arbitrary_signed_dual_is_below_known_optimum(self):
        targets, edges = [F(0), F(1)], [(0, 1, F(1, 4))]
        for weight in [F(-100), F(-3, 4), F(-1, 10), F(0), F(3), F(100)]:
            unboxed = evaluate_dual(targets, edges, [weight], boxed=False)
            boxed = evaluate_dual(targets, edges, [weight], boxed=True)
            self.assertLessEqual(unboxed, boxed)
            self.assertLessEqual(boxed, F(9, 32))

    def test_graph_improves_over_disjoint_pair_fallback(self):
        features, targets = [[F(0)], [F(0)], [F(0)]], [F(0), F(1), F(1)]
        result = lower_certificate(features, targets, F(1), sweeps=8)
        optimum = F(2, 9)
        self.assertGreater(result["graph_dual_sse"], result["pair_sse"])
        self.assertLessEqual(result["lower_empirical"], optimum)
        self.assertLess(optimum - result["lower_empirical"], F(1, 10000))

    def test_isolated_vertex_remains_in_denominator(self):
        features = [[F(0)], [F(0)], [F(1)]]
        targets = [F(0), F(1), F(1, 2)]
        record = {
            "schema": "single_trajectory_lower_v1", "N": 3,
            "edges": [(0, 1, F(0))], "weights": [F(-1)],
            "pairs": [(0, 1, F(0))], "graph_dual_sse": F(1, 2),
            "pair_sse": F(1, 2), "lower_empirical": F(1, 6),
        }
        self.assertTrue(verify_lower_certificate(features, targets, F(1), record))
        record["lower_empirical"] = F(1, 4)  # Incorrect paired-only denominator.
        with self.assertRaises(ValueError):
            verify_lower_certificate(features, targets, F(1), record)

    def test_overlapping_pair_sums_are_rejected(self):
        features = [[F(0)], [F(0)], [F(0)]]
        targets = [F(0), F(1), F(0)]
        record = lower_certificate(features, targets, F(1))
        record["pairs"] = [(0, 1, F(0)), (1, 2, F(0))]
        with self.assertRaises(ValueError):
            verify_lower_certificate(features, targets, F(1), record)

    def test_underestimated_distance_rejected(self):
        features, targets, kappa = [[F(0)], [F(1)]], [F(0), F(1)], F(1, 4)
        record = lower_certificate(features, targets, kappa)
        altered = deepcopy(record)
        altered["edges"][0] = (0, 1, F(0))
        with self.assertRaises(ValueError):
            verify_lower_certificate(features, targets, kappa, altered)

    def test_mutated_values_and_denominator_rejected(self):
        features, targets, kappa = [[F(0)], [F(1)]], [F(0), F(1)], F(1, 4)
        record = lower_certificate(features, targets, kappa)
        for field, value in [("N", 1), ("N", True), ("N", 2.0), ("graph_dual_sse", F(1)),
                             ("pair_sse", F(1)), ("lower_empirical", F(1))]:
            altered = deepcopy(record)
            altered[field] = value
            with self.assertRaises(ValueError):
                verify_lower_certificate(features, targets, kappa, altered)

    def test_range_constraint_allows_unit_bound_for_large_distance(self):
        features, targets = [[F(0)], [F(1000)]], [F(0), F(1)]
        record = lower_certificate(features, targets, F(100))
        self.assertEqual(record["edges"], [(0, 1, F(1))])
        self.assertEqual(record["lower_empirical"], F(0))
        self.assertTrue(verify_lower_certificate(features, targets, F(100), record))

    def test_large_rational_features_and_non_dyadic_kappa(self):
        denominator = 10**100 + 151
        features = [[F(10**99, denominator), F(2, 7)],
                    [F(10**99 + 7, denominator), F(3, 7)]]
        targets, kappa = [F(0), F(1)], F(1, 3)
        record = lower_certificate(features, targets, kappa)
        self.assertTrue(verify_lower_certificate(features, targets, kappa, record))
        for _, _, bound in record["edges"]:
            self.assertEqual(bound.denominator & (bound.denominator - 1), 0)

    def test_single_vertex_and_zero_dimension(self):
        record = lower_certificate([[]], [F(3, 7)], F(0))
        self.assertEqual(record["lower_empirical"], 0)
        self.assertEqual(record["edges"], [])

    def test_invalid_inputs_fail_closed(self):
        bad = [([], [], F(1)), ([[F(0)]], [F(2)], F(1)),
               ([[0.0]], [F(0)], F(1)), ([[F(0)]], [F(0)], F(-1)),
               ([[F(0)], []], [F(0), F(1)], F(1))]
        for features, targets, kappa in bad:
            with self.assertRaises(ValueError):
                lower_certificate(features, targets, kappa)


if __name__ == "__main__":
    unittest.main()
