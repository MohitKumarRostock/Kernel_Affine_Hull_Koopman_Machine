"""Protocol and tampering checks for the single-trajectory reference pipeline.

These deterministic fixtures test numerical/protocol correctness. They are not
a scientific coverage experiment and do not establish stationarity or mixing
for any supplied real-world time series.
"""

from copy import deepcopy
from fractions import Fraction as F
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import certify_series as pipeline
from certified_kl import kl_enclosure, kl_upper
from certified_models import predict_exact


def fixture_config():
    note = "Numerical test declaration only; this fixture is not a scientific coverage study."
    return {
        "schema_version": 1,
        "support": {"lower": "0", "upper": "1", "justification": note},
        "stationarity": {"asserted": True, "justification": note},
        "design": {
            "prespecified": True, "provenance": note,
            "history": 3, "development_count": 12, "block_windows": 3,
            "gap_lag": 2, "blocks": 4,
        },
        "dependence": {"kind": "at_lag", "lag": 2, "bound": "0", "justification": note},
        "risk_tolerance": "1/4", "failure_probability": "1/20",
        "statistical_budget": "1/25", "dependence_budget": "1/100",
        "candidates": {"groups": 2, "kappa": "2", "coefficient_bits": 20},
        "numerics": {"sweeps": 2, "mean_bits": 20, "endpoint_bits": 24},
    }


def fixture_series():
    # 40 observations are used; the final three are deliberately unused.
    return [F((7 * i + 2 * (i // 3)) % 17, 16) for i in range(43)]


class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.config = fixture_config()
        cls.series = fixture_series()
        cls.report = pipeline.certify(cls.series, cls.config)

    def test_layout_histories_targets_and_gaps_have_expected_indices(self):
        prepared = pipeline.prepare(self.series, self.config)
        layout = prepared["layout"]
        self.assertEqual(layout["last_used_raw"], 40)
        self.assertEqual(layout["trailing_unused"], 3)
        self.assertEqual(layout["omitted_per_gap"], 1)
        expected_blocks = [(14, 19, 16, 18), (21, 26, 23, 25), (28, 33, 30, 32), (35, 40, 37, 39)]
        observed = [(b["first_raw"], b["last_raw"], b["first_origin"], b["last_origin"])
                    for b in layout["blocks"]]
        self.assertEqual(observed, expected_blocks)
        histories, targets = pipeline.calibration_windows(prepared)
        self.assertEqual(histories[0], self.series[13:16])
        self.assertEqual(targets[0], self.series[16])
        self.assertEqual(histories[-1], self.series[36:39])
        self.assertEqual(targets[-1], self.series[39])
        self.assertEqual(len(targets), 12)

    def test_statistical_K_empirical_N_and_failure_allocation_are_distinct(self):
        checked = pipeline.verify_report(self.series, self.config, self.report)
        self.assertEqual(checked["statistical_units"], 4)
        self.assertEqual(checked["windows_checked_per_candidate"], 12)
        self.assertEqual(self.report["alpha_per_endpoint"], F(1, 150))
        self.assertEqual(self.report["coverage_at_least"], F(24, 25))
        for row in self.report["candidates"]:
            self.assertEqual(row["lower_certificate"]["N"], 12)

    def test_upper_mean_encloses_exact_raw_history_predictor_loss(self):
        prepared = pipeline.prepare(self.series, self.config)
        histories, targets = pipeline.calibration_windows(prepared)
        for row in self.report["candidates"]:
            exact_mean = sum(((y - predict_exact(row["model"], x)) ** 2
                              for x, y in zip(histories, targets)), F(0)) / len(targets)
            self.assertLessEqual(exact_mean, row["upper_empirical"])
            self.assertLessEqual(row["upper_empirical"] - exact_mean, F(1, 2**32))

    def test_development_fit_is_invariant_to_all_later_values(self):
        modified = list(self.series)
        for i in range(12, len(modified)):
            modified[i] = 1 - modified[i]
        original_models = pipeline.fit_registered(pipeline.prepare(self.series, self.config))
        modified_models = pipeline.fit_registered(pipeline.prepare(modified, self.config))
        self.assertEqual(original_models, modified_models)

    def test_json_roundtrip_is_verified(self):
        decoded = pipeline.unpack(json.loads(json.dumps(pipeline.pack(self.report))))
        checked = pipeline.verify_report(self.series, self.config, decoded)
        self.assertEqual(checked["numerical_verification"], "passed")

    def test_checker_does_not_rerun_optimization_or_KL_search(self):
        with patch.object(pipeline, "lower_certificate", side_effect=AssertionError("optimizer rerun")), \
             patch.object(pipeline, "kl_enclosure", side_effect=AssertionError("KL search rerun")):
            result = pipeline.verify_report(self.series, self.config, self.report)
        self.assertEqual(result["numerical_verification"], "passed")

    def test_unresolved_log_comparison_keeps_a_verifiable_conservative_certificate(self):
        config = deepcopy(self.config)
        config["numerics"]["log_terms"] = 1
        report = pipeline.certify(self.series, config)
        # Diagnostics are intentionally local API results, not trusted fields
        # of the serialized certificate. Check that this fixture exercises an
        # unresolved comparison while the report's endpoints remain valid.
        diagnostics = [kl_enclosure(row["upper_kl_input"], 4, F(1, 150),
                                     side="upper", max_terms=1)
                       for row in report["candidates"]]
        self.assertTrue(any(not diagnostic.grid_resolved for diagnostic in diagnostics))
        checked = pipeline.verify_report(self.series, config, report)
        self.assertEqual(checked["numerical_verification"], "passed")

    def test_wrong_K_metadata_is_rejected(self):
        report = deepcopy(self.report)
        report["layout"]["blocks_count"] = 12
        with self.assertRaisesRegex(ValueError, "layout"):
            pipeline.verify_report(self.series, self.config, report)

    def test_using_Kq_for_population_endpoint_is_rejected(self):
        series = [F(1, 2)] * len(self.series)
        report = pipeline.certify(series, self.config)
        # A constant record gives exactly zero fitted loss; Kq yields a strictly
        # smaller and invalid upper confidence endpoint than the actual K.
        row = report["candidates"][0]
        self.assertEqual(row["upper_kl_input"], 0)
        row["U"] = kl_upper(row["upper_kl_input"], 12, report["alpha_per_endpoint"])
        with self.assertRaisesRegex(ValueError, "upper population endpoint"):
            pipeline.verify_report(series, self.config, report)

    def test_missing_windows_from_empirical_denominator_are_rejected(self):
        report = deepcopy(self.report)
        report["candidates"][0]["lower_certificate"]["N"] = 4
        with self.assertRaisesRegex(ValueError, "denominator"):
            pipeline.verify_report(self.series, self.config, report)

    def test_underestimated_distance_is_rejected(self):
        report = deepcopy(self.report)
        lower = report["candidates"][0]["lower_certificate"]
        self.assertTrue(lower["edges"])
        i, j, bound = lower["edges"][0]
        self.assertGreater(bound, 0)
        lower["edges"][0] = (i, j, F(0))
        with self.assertRaisesRegex(ValueError, "underestimates"):
            pipeline.verify_report(self.series, self.config, report)

    def test_feature_identity_and_frozen_model_mutations_are_rejected(self):
        report = deepcopy(self.report)
        report["candidates"][0]["features_sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "feature reconstruction"):
            pipeline.verify_report(self.series, self.config, report)
        report = deepcopy(self.report)
        report["candidates"][0]["model"]["intercept"] += F(1, 100)
        with self.assertRaisesRegex(ValueError, "frozen model"):
            pipeline.verify_report(self.series, self.config, report)

    def test_inward_population_endpoint_is_rejected(self):
        report = deepcopy(self.report)
        report["candidates"][0]["U"] = F(0)
        with self.assertRaisesRegex(ValueError, "upper population endpoint"):
            pipeline.verify_report(self.series, self.config, report)

    def test_cost_bracket_requires_excluding_every_strictly_cheaper_class(self):
        rows = [
            {"candidate_id": "a", "cost": 2, "L": F(1, 5), "U": F(3, 10)},
            {"candidate_id": "b", "cost": 3, "L": F(1, 50), "U": F(7, 50)},
            {"candidate_id": "c", "cost": 4, "L": F(1, 25), "U": F(2, 25)},
        ]
        result = pipeline.decisions(rows, F(1, 10))
        self.assertEqual((result["cost_lower"], result["cost_upper"]), (3, 4))
        self.assertFalse(result["minimum_feasible_cost_certified"])
        rows[1]["L"] = F(3, 25)
        result = pipeline.decisions(rows, F(1, 10))
        self.assertEqual((result["cost_lower"], result["cost_upper"]), (4, 4))
        self.assertTrue(result["minimum_feasible_cost_certified"])
        self.assertEqual(result["selected_candidate_id"], "c")

    def test_no_accepted_model_is_distinct_from_entire_family_excluded(self):
        rows = [{"candidate_id": "a", "cost": 2, "L": F(1, 50), "U": F(1, 5)}]
        result = pipeline.decisions(rows, F(1, 10))
        self.assertIsNone(result["cost_upper"])
        self.assertFalse(result["entire_family_excluded"])
        rows[0]["L"] = F(3, 25)
        result = pipeline.decisions(rows, F(1, 10))
        self.assertTrue(result["entire_family_excluded"])
        self.assertIsNone(result["cost_lower"])
        self.assertFalse(result["minimum_feasible_cost_certified"])

    def test_missing_or_null_scientific_and_design_premises_are_rejected(self):
        for section, field in [("support", "justification"), ("stationarity", "justification"),
                               ("design", "provenance"), ("dependence", "justification")]:
            for replacement in [None, ""]:
                config = deepcopy(self.config)
                config[section][field] = replacement
                with self.subTest(section=section, replacement=replacement):
                    with self.assertRaises(ValueError):
                        pipeline.prepare(self.series, config)
        config = deepcopy(self.config)
        config["stationarity"]["asserted"] = False
        with self.assertRaises(ValueError):
            pipeline.prepare(self.series, config)

    def test_incorrect_configuration_shapes_are_rejected(self):
        for section in ["support", "stationarity", "design", "dependence", "candidates", "numerics"]:
            for replacement in [None, [], "invalid"]:
                config = deepcopy(self.config)
                config[section] = replacement
                with self.subTest(section=section, replacement=replacement):
                    with self.assertRaises(ValueError):
                        pipeline.prepare(self.series, config)
        for invalid in [None, [], "invalid"]:
            with self.assertRaises(ValueError):
                pipeline.prepare(self.series, invalid)

    def test_mutated_scientific_scope_and_risk_target_claims_are_rejected(self):
        for field in ["premises", "risk_target"]:
            report = deepcopy(self.report)
            report[field] = "Unconditional prediction guarantee for every observed history."
            with self.subTest(field=field):
                with self.assertRaises(ValueError):
                    pipeline.verify_report(self.series, self.config, report)

    def test_insufficient_data_support_violation_and_dependence_budget_fail(self):
        with self.assertRaisesRegex(ValueError, "insufficient observations"):
            pipeline.prepare(self.series[:39], self.config)
        invalid_series = list(self.series)
        invalid_series[13] = F(2)
        with self.assertRaisesRegex(ValueError, "support"):
            pipeline.prepare(invalid_series, self.config)
        config = deepcopy(self.config)
        config["dependence"]["bound"] = "1/10"
        with self.assertRaisesRegex(ValueError, "dependence budget"):
            pipeline.prepare(self.series, config)

    def test_dependence_envelope_evaluation_is_exact_and_conservative(self):
        base = {"justification": "numerical test declaration"}
        self.assertEqual(pipeline.dependence_upper({**base, "kind": "geometric", "C": "2", "rho": "1/4"}, 3), F(1, 32))
        # At x=1, S_1=2 and S_2=5/2. Each reciprocal upper-bounds exp(-1).
        self.assertEqual(pipeline.dependence_upper({**base, "kind": "exponential", "C": "1", "r": "1", "series_terms": 1}, 1), F(1, 2))
        self.assertEqual(pipeline.dependence_upper({**base, "kind": "exponential", "C": "1", "r": "1", "series_terms": 2}, 1), F(2, 5))

    def test_CLI_writes_unavailable_report_when_premise_is_missing(self):
        config = deepcopy(self.config)
        config["stationarity"]["asserted"] = False
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "series.json").write_text(json.dumps(pipeline.pack(self.series)))
            (root / "config.json").write_text(json.dumps(config))
            result = subprocess.run(
                [sys.executable, str(Path(pipeline.__file__)), "run", "--series", str(root / "series.json"),
                 "--config", str(root / "config.json"), "--out", str(root / "report.json")],
                capture_output=True, text=True, check=False,
            )
            self.assertEqual(result.returncode, 2)
            report = json.loads((root / "report.json").read_text())
            self.assertEqual(report["status"], "unavailable")
            self.assertFalse(report["population_certificate_issued"])


if __name__ == "__main__":
    unittest.main()
