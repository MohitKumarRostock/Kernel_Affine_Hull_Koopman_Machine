# Kernel Affine Hull representations for time-series forecasting

This archive contains the editable manuscript, bibliography, unmodified TMLR
style files and their notices, and all tables and figures required for compilation.
The manuscript uses anonymous TMLR review formatting.

## Compile the manuscript

With TeX Live, latexmk, pdfLaTeX, BibTeX, and Latin Modern installed, run:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The PDF is written to `main.pdf`. Compilation uses the supplied displays and
does not fit forecasting models or access external datasets.

## Evidence and reproducibility

The paper studies reconstruction-derived feature spans, bounded residual
corrections, and predictive accuracy. The principal experiment compares ten
procedures on 192 task suites, with 24 independent repetition aggregates.
The KAHM departure improves the common-coordinate basis but does not satisfy
the complete prespecified forecasting-improvement criterion.

`ARTIFACT_MANIFEST.json` records each included file's byte size and SHA-256 checksum.
`STUDY_EVIDENCE.json` identifies the experimental evidence and its computational
verification. `PRESENTATION_PROVENANCE.json` records text-only display formatting.
These source inventories describe this manuscript package; the experimental
source and input records retain their original identities.

The complete fitting implementation and saved evidence are available in
https://github.com/MohitKumarRostock/Kernel_Affine_Hull_Koopman_Machine. The companion `KAHM_Reconstruction_Mechanism_Reproduction.zip` contains the principal study's
frozen source, prepared inputs, predictions, selected states, and analysis.
The anonymous saved-forecast supplement supports independent reconstruction of
the principal loss comparisons without refitting or loading serialized models.
Earlier studies have their own data, protocols, and reproduction instructions.

Code, data, and bundled third-party materials retain their respective licenses.
