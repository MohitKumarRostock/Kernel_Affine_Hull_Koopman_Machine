#!/usr/bin/env python3
"""Independent, bounded calibration checks for the manuscript revision.

This program imports no project code and executes no downloaded source. It
recomputes learned-hierarchy lower endpoints from saved sufficient summaries,
checks confidence-allocation arithmetic, and supplies small independent
mathematical sanity checks. It does not reconstruct the original observations,
verify all saved optimization certificates, or reproduce fitted upper bounds.

Usage:
  python independent_calibration_checks.py \
    --evidence-dir ../remote_evidence \
    --output independent_calibration_checks.json
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import platform

import numpy as np
import scipy
from scipy.optimize import brentq, linprog, minimize
from scipy.special import xlogy
from scipy.stats import binom


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def lower_kl(mean: float, count: int, bound: float, alpha: float) -> float:
    """Mathematical bounded-mean KL endpoint using independent Brent inversion."""
    require(count > 0 and bound > 0 and 0 < alpha < 1, "Invalid KL inputs")
    q = min(1.0, max(0.0, mean / bound))
    if q == 0:
        return 0.0
    level = math.log(1 / alpha) / count
    if q == 1:
        return bound * math.exp(-level)

    def equation(p: float) -> float:
        return (q * math.log(q / p)
                + (1 - q) * (math.log1p(-q) - math.log1p(-p)) - level)

    left = np.finfo(float).tiny
    if equation(left) <= 0:
        return 0.0
    return bound * brentq(equation, left, q, xtol=np.nextafter(0.0, 1.0),
                         rtol=2e-14, maxiter=1100)


def check_saved_lower_endpoints(evidence_dir: Path) -> dict:
    root = evidence_dir / "results/learned_kahm_hierarchy_v1"
    config = json.loads((root / "protocol.json").read_text())
    eta = config["confidence_delta"] / config["endpoint_counts"]["total"]
    diameter = config["target_bounds"][1] - config["target_bounds"][0]
    loss_bound = diameter**2
    with gzip.open(root / "stratified_details.jsonl.gz", "rt") as handle:
        details = [json.loads(line) for line in handle]
    max_conditional_error = max_lp_error = max_radius_error = 0.0
    conditional_count = sparse_count = 0
    stratified = {}
    for row in details:
        counts = np.asarray(row["counts"])
        strata, n = len(counts), row["n"]
        require(int(counts.sum()) == n, "Stratum counts do not sum to n")
        require(strata in (2, 4), "Unexpected partition width")
        radius = math.sqrt(math.log(4 * strata / eta) / (2 * n))
        max_radius_error = max(max_radius_error, abs(radius - row["mass_radius"]))
        low = np.maximum(0.0, counts / n - radius)
        high = np.minimum(1.0, counts / n + radius)
        conditional = []
        for j, part in enumerate(row["conditional"]):
            require(part["count"] == counts[j], "Conditional count mismatch")
            require(part["pairs"] == part["count"] // 2, "Pair count mismatch")
            require(abs(part["eta"] - eta / (2 * strata)) < 1e-18,
                    "Conditional failure allocation mismatch")
            require(abs(part["bound"] - loss_bound / 2) < 1e-14,
                    "Conditional score range mismatch")
            count = part["pairs"]
            endpoint = (lower_kl(part["mean"], count, loss_bound / 2,
                                 eta / (2 * strata)) if count >= 2 else 0.0)
            sparse_count += count < 2
            conditional_count += 1
            max_conditional_error = max(max_conditional_error,
                                        abs(endpoint - part["lower"]))
            conditional.append(endpoint)
        conditional = np.asarray(conditional)
        scale = max(float(conditional.max()), 1e-100)
        lp = linprog(conditional / scale, A_eq=np.ones((1, strata)), b_eq=[1.0],
                     bounds=list(zip(low, high)), method="highs",
                     options={"dual_feasibility_tolerance": 1e-10,
                              "primal_feasibility_tolerance": 1e-10})
        require(lp.success, "Independent mass LP did not solve")
        # The retained implementation subtracts this numerical guard after the LP.
        endpoint = max(0.0, float(lp.fun) * scale - 1e-12)
        max_lp_error = max(max_lp_error, abs(endpoint - row["lower"]))
        key = (row["regime"], row["repetition"], row["prefix"], n,
               "stratified_" + row["partition"])
        require(key not in stratified, "Duplicate stratified endpoint")
        stratified[key] = endpoint

    with (root / "endpoints.csv").open() as handle:
        rows = list(csv.DictReader(handle))
    require(len(rows) == 1760, "Unexpected endpoint count")
    families = Counter()
    max_endpoint_error = 0.0
    recomputed = 0
    for row in rows:
        require(abs(float(row["eta"]) - eta) < 1e-18,
                "Endpoint failure allocation mismatch")
        method, n = row["method"], int(row["n"])
        family = ("block" if method.startswith("block_") else "stratified"
                  if method.startswith("stratified_") else method)
        families[family] += 1
        if method == "fitted_upper":
            continue
        if method.startswith("stratified_"):
            key = (row["regime"], int(row["repetition"]), int(row["prefix"]), n, method)
            endpoint = stratified[key]
        else:
            if method.startswith("block_"):
                block_size = int(method.split("_")[1])
                bound = loss_bound * (block_size**2 // 4) / (block_size * (block_size - 1))
                count = n // block_size
            else:
                require(method == "full_erm" and n == 256, "Unexpected ERM grid")
                bound, count = loss_bound, n
            require(abs(bound - float(row["score_bound"])) < 1e-14,
                    "Score range mismatch")
            require(count == int(row["n_independent"]), "Independent count mismatch")
            endpoint = lower_kl(float(row["score_mean"]), count, bound, eta)
        max_endpoint_error = max(max_endpoint_error, abs(endpoint - float(row["lower"])))
        recomputed += 1
    expected = {"fitted_upper": 240, "block": 960, "stratified": 480, "full_erm": 80}
    require(dict(families) == expected, "Endpoint family counts mismatch")
    require(recomputed == 1520 and conditional_count == 1440 and len(details) == 480,
            "Recomputed quantity count mismatch")
    require(max(max_conditional_error, max_lp_error, max_endpoint_error) < 5e-11,
            "Lower endpoint arithmetic mismatch")
    return {
        "status": "PASS",
        "endpoint_family_counts": dict(families),
        "recomputed_lower_endpoints": recomputed,
        "recomputed_conditional_kl_means": conditional_count,
        "recomputed_mass_linear_programs": len(details),
        "strata_with_fewer_than_two_pairs": sparse_count,
        "max_conditional_kl_discrepancy": max_conditional_error,
        "max_mass_radius_discrepancy": max_radius_error,
        "max_mass_lp_endpoint_discrepancy": max_lp_error,
        "max_lower_endpoint_discrepancy": max_endpoint_error,
        "total_failure_allocation": eta * len(rows),
        "comparison_tolerance": 5e-11,
        "scope": "Arithmetic replay from saved score means and counts only; tiny source numerical guards are within the reported discrepancies.",
        "not_checked": ["raw score generation", "all 143440 saved optimization programs",
                        "240 fitted upper endpoints: per-endpoint loss variances are absent from the available summary CSVs",
                        "new model fitting", "formal interval arithmetic"],
    }


def check_exact_bernoulli_tails() -> dict:
    maxima = {"kl": 0.0, "standard_deviation": 0.0, "empirical_bernstein": 0.0}
    cases = 0
    for n in [2, 3, 4, 8, 16, 64, 128]:
        sample_mean = np.arange(n + 1) / n
        sample_sd = np.sqrt(n / (n - 1) * sample_mean * (1 - sample_mean))
        for p in [.0001, .001, .01, .05, .1, .2, .5, .9, .99, .9999]:
            pmf = binom.pmf(np.arange(n + 1), n, p)
            divergence = (xlogy(sample_mean, sample_mean / p)
                          + xlogy(1 - sample_mean, (1 - sample_mean) / (1 - p)))
            for alpha in [.05, .01, .001]:
                threshold = math.log(1 / alpha) / n
                failures = [pmf[(sample_mean > p) & (divergence > threshold + 1e-14)].sum(),
                            pmf[(sample_mean < p) & (divergence > threshold + 1e-14)].sum()]
                maxima["kl"] = max(maxima["kl"], *(float(v) / alpha for v in failures))
                radius = math.sqrt(2 * math.log(1 / alpha) / (n - 1))
                population_sd = math.sqrt(p * (1 - p))
                failures = [pmf[sample_sd - radius > population_sd + 1e-14].sum(),
                            pmf[sample_sd + radius < population_sd - 1e-14].sum()]
                maxima["standard_deviation"] = max(maxima["standard_deviation"],
                                                    *(float(v) / alpha for v in failures))
                radius = (np.sqrt(2 * sample_sd**2 * math.log(2 / alpha) / n)
                          + 7 * math.log(2 / alpha) / (3 * (n - 1)))
                failures = [pmf[sample_mean - radius > p + 1e-14].sum(),
                            pmf[sample_mean + radius < p - 1e-14].sum()]
                maxima["empirical_bernstein"] = max(maxima["empirical_bernstein"],
                                                     *(float(v) / alpha for v in failures))
                cases += 1
    require(max(maxima.values()) <= 1 + 1e-12, "A tested confidence tail exceeded alpha")
    return {"status": "PASS", "parameter_cases": cases, "directions_per_case": 2,
            "maximum_failure_probability_divided_by_alpha": maxima,
            "scope": "Exact binomial enumeration on the stated finite grid, evaluated in floating point; a sanity check, not a general proof."}


def check_signed_edge_dual() -> dict:
    rng = np.random.default_rng(78305)
    max_dual_over_primal = -math.inf
    max_primal_violation = max_gap = 0.0
    for case in range(18):
        size = [3, 4, 6][case % 3]
        inputs = rng.normal(size=(size, 2))
        if case % 2 == 0:
            inputs[1] = inputs[0]
        targets = rng.uniform(-1, 1, size)
        distances = np.linalg.norm(inputs[:, None] - inputs[None, :], axis=2)
        budget = .3
        edges = [(i, j) for i in range(size) for j in range(i + 1, size)]
        incidence = np.zeros((size, len(edges)))
        for k, (i, j) in enumerate(edges):
            incidence[i, k], incidence[j, k] = 1, -1
        caps = np.array([budget * distances[i, j] for i, j in edges])
        width = len(edges)

        def objective(coefficients):
            alpha = coefficients[:width] - coefficients[width:]
            divergence = incidence @ alpha
            value = (.25 * (divergence @ divergence) - targets @ divergence
                     + caps @ (coefficients[:width] + coefficients[width:]))
            gradient = incidence.T @ (.5 * divergence - targets)
            return value, np.r_[gradient + caps, -gradient + caps]

        result = minimize(objective, np.zeros(2 * width), method="L-BFGS-B", jac=True,
                          bounds=[(0, None)] * (2 * width),
                          options={"ftol": 1e-14, "gtol": 1e-10, "maxiter": 10000})
        alpha = result.x[:width] - result.x[width:]
        divergence = incidence @ alpha
        dual = (alpha @ (incidence.T @ targets) - caps @ np.abs(alpha)
                - .25 * (divergence @ divergence))
        raw = targets - divergence / 2
        low = (raw[None, :] + budget * distances).min(axis=1)
        high = (raw[None, :] - budget * distances).max(axis=1)
        primal_values = (low + high) / 2
        primal_values += np.mean(targets - primal_values)
        primal_values = np.clip(primal_values, targets.min(), targets.max())
        primal = np.sum((targets - primal_values)**2)
        violation = np.max(np.abs(primal_values[:, None] - primal_values[None, :])
                           - budget * distances)
        max_primal_violation = max(max_primal_violation, float(violation))
        max_dual_over_primal = max(max_dual_over_primal, float(dual - primal))
        max_gap = max(max_gap, float(primal - dual))
        require(dual <= primal + 1e-9, "Dual exceeded primal beyond numerical tolerance")
        require(violation <= 1e-10, "Envelope feasibility check failed")
    return {"status": "PASS", "cases": 18, "random_seed": 78305,
            "duplicate_input_cases": 9,
            "maximum_primal_feasibility_residual": max_primal_violation,
            "maximum_dual_minus_primal": max_dual_over_primal,
            "maximum_primal_dual_gap": max_gap,
            "scope": "Independent small optimization problems; does not validate the archive's saved programs or provide verified arithmetic."}


def check_eb_nonmonotonicity() -> dict:
    original = np.r_[np.full(99, .5), 1.0]
    smaller = np.full(100, .5)
    alpha = .05

    def endpoint(values):
        n = len(values)
        return float(values.mean() - math.sqrt(2 * values.var(ddof=1) * math.log(2 / alpha) / n)
                     - 7 * math.log(2 / alpha) / (3 * (n - 1)))

    original_lower, smaller_lower = endpoint(original), endpoint(smaller)
    require(np.all(smaller <= original) and smaller_lower > original_lower,
            "EB nonmonotonicity example failed")
    return {"status": "PASS", "n": 100, "score_range": [0, 1], "alpha": alpha,
            "original_scores": "99 values of 0.5 and one value of 1.0",
            "pointwise_smaller_scores": "100 values of 0.5",
            "original_lower_endpoint": original_lower,
            "smaller_scores_lower_endpoint": smaller_lower,
            "implication": "Pointwise score domination alone does not order empirical-Bernstein endpoints. A KL monotonicity argument does not automatically justify EB on coupled approximate scores."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads((args.evidence_dir / "download_manifest.json").read_text())
    inputs = ["results/learned_kahm_hierarchy_v1/protocol.json",
              "results/learned_kahm_hierarchy_v1/endpoints.csv",
              "results/learned_kahm_hierarchy_v1/stratified_details.jsonl.gz"]
    result = {
        "status": "PASS",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "public_repository_commit": manifest.get("commit"),
        "runtime": {"python": platform.python_version(), "numpy": np.__version__,
                    "scipy": scipy.__version__},
        "input_sha256": {name: hashlib.sha256((args.evidence_dir / name).read_bytes()).hexdigest()
                         for name in inputs},
        "saved_lower_endpoint_replay": check_saved_lower_endpoints(args.evidence_dir),
        "bounded_mean_and_standard_deviation_checks": check_exact_bernoulli_tails(),
        "signed_edge_dual_and_primal_envelope_checks": check_signed_edge_dual(),
        "empirical_bernstein_nonmonotonicity_example": check_eb_nonmonotonicity(),
        "count_cross_checks": {"learned_hierarchy_endpoints": 40 * 2 * (3 * (4 + 2 + 1) + 1),
                               "learned_hierarchy_unique_programs": 40 * 2 * (4096 // 4 + 4096 // 8 + 4096 // 16 + 1),
                               "finite_support_endpoints": 8 * 100 * 3 * 6},
        "one_pair_kl_observation": "For K=1, mean=B/2, beta in (0,1), the mathematical KL lower endpoint is (B/2)*beta>0. The archived study conservatively used zero for K<2.",
        "overall_scope": "Independent formula and saved-summary arithmetic checks only. No new experiment, model fitting, raw-score replay, or formal interval verification.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
