# Completed KAHM reconstruction-to-prediction research manuscript

This archive is the complete editable source of the current unsubmitted
research manuscript. It includes LaTeX, BibTeX, preserved local styles and
notices, and all generated historical and new-study tables and figures.
It reports completed findings; the protocol is supporting reproducibility.
The frozen mechanism-study decision is `STOP_FORECASTING_PERFORMANCE_BRANCH`.

From this archive's root, with TeX Live, latexmk, pdfLaTeX, BibTeX and Latin Modern:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

Forecasting models are not fitted to compile the manuscript. The source uses
the supplied TMLR preprint style and accurately identifies an unsubmitted
research draft. The template's original files and licenses remain intact.
The companion `KAHM_Reconstruction_Mechanism_Reproduction.zip` preserves the full new-study evidence and its
exact inherited numerical source. Historical evidence remains separately
available in https://github.com/MohitKumarRostock/Kernel_Affine_Hull_Koopman_Machine; its publication displays are included here.

`ARTIFACT_MANIFEST.json` records every included byte size and SHA-256. Its evidence
metadata binds this source package to the exact frozen study, completed
decision, independent audit, and selected-state replay. Root code/data licenses
and local third-party/template notices retain their respective scopes.
