# Complete editable forecast-trained KAHM manuscript

This is a public, unsubmitted research manuscript. All editable LaTeX and
BibTeX, local styles and notices, and existing generated tables and figures
needed for the complete integrated paper are included. Compilation byproducts
and the final PDF are excluded from this source archive.

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The companion KAHM_Direct_Reconstruction_Reproduction.zip contains the new direct-reconstruction experiment,
its exact inherited numerical dependencies, and the separately preserved
exploratory gate pilot. The complete evidence for earlier studies remains at
https://github.com/MohitKumarRostock/Kernel_Affine_Hull_Koopman_Machine; their existing generated publication assets are included
here to compile the paper. Historical results are not silently recomputed or
reclassified by packaging. ARTIFACT_MANIFEST.json inventories every included
file's bytes and SHA-256. The preserved software, data, and template licenses
apply to their respective content. No submission, acceptance, new DOI, external
registration, or author sign-off is implied by creating these files.
