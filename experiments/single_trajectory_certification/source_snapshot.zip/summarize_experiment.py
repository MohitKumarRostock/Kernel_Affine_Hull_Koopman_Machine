#!/usr/bin/env python3
"""Analyze every frozen-protocol outcome; exact counts and binomial bounds."""
from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
from statistics import mean, median

from certify_series import pack, unpack
from experiment_statistics import summarize_joint_failures, rate_interval

ROOT = Path(__file__).resolve().parent
KINDS = ("raw", "memberships", "local_position")
EVENTS = ("covered", "violation", "oracle_unresolved", "operational_unavailable")


def rate(count, n):
    lo, hi = rate_interval(count, n)
    return {"count": count, "denominator": n, "fraction": Fraction(count, n),
            "pointwise_95_interval": [lo, hi]}


def average(values):
    return mean(float(x) for x in values) if values else None


def median_value(values):
    return median(float(x) for x in values) if values else None


def cell_summary(cell, rows, R, alpha):
    events = Counter(r["joint_risk_event"] for r in rows)
    if any(e not in EVENTS for e in events) or sum(events.values()) != R:
        raise ValueError("invalid or incomplete outcome classification")
    complete = [r for r in rows if r["status"] == "completed"]
    joint = summarize_joint_failures(events["violation"], events["oracle_unresolved"], R, alpha,
                                     operational_unavailable=events["operational_unavailable"])
    result = {"cell_id":cell["cell_id"],"kind":cell["kind"],"p":Fraction(cell["p"]),
              "T":cell["T"],"K":cell["config"]["design"]["blocks"],
              "q":cell["config"]["design"]["block_windows"],
              "g":cell["config"]["design"]["gap_lag"],
              "sweeps":cell["config"]["numerics"]["sweeps"],"joint":joint,
              "complete_runs":len(complete),"covered_runs":events["covered"],
              "theorem_coverage_at_least":complete[0]["theorem_coverage_at_least"] if complete else None,
              "dependence_allowance":complete[0]["dependence_allowance"] if complete else None,
              "any_accepted":rate(sum(r["any_accepted"] for r in complete),R),
              "compressed_accepted":rate(sum(r["compressed_accepted"] for r in complete),R),
              "all_excluded":rate(sum(r["selection"]["entire_family_excluded"] for r in complete),R),
              "minimum_cost_certified":rate(sum(r["selection"]["minimum_feasible_cost_certified"] for r in complete),R),
              "optimal_claim_violations":sum(r["optimal_claim_event"]=="violation" for r in complete),
              "optimal_claim_oracle_unresolved":sum(r["optimal_claim_event"]=="oracle_unresolved" for r in complete),
              "cost_bracket_violations":sum(r["cost_bracket_event"]=="violation" for r in complete),
              "cost_bracket_oracle_unresolved":sum(r["cost_bracket_event"]=="oracle_unresolved" for r in complete),
              "oracle_exact_cost_count":sum(r["oracle_cost"]["exact"] for r in complete),
              "cost_count_scope":{"completed_runs":len(complete),"unavailable_runs":R-len(complete),"infinity_label":"infinity"},
              "selected_counts":dict(Counter(r["selection"]["selected_candidate_id"] or "none" for r in complete)),
              "oracle_cost_counts":dict(Counter(("infinity" if r["oracle_cost"]["upper"] is None else str(r["oracle_cost"]["upper"])) if r["oracle_cost"]["exact"] else "unresolved" for r in complete)),
              "cost_bracket_counts":dict(Counter(f"{r['selection']['cost_lower'] if r['selection']['cost_lower'] is not None else 'infinity'}:{r['selection']['cost_upper'] if r['selection']['cost_upper'] is not None else 'infinity'}" for r in complete)),
              "timing":{name:{"median":median_value([r[name] for r in complete]),
                              "mean":average([r[name] for r in complete])}
                        for name in ("producer_cpu_seconds","checker_cpu_seconds","oracle_cpu_seconds")}}
    candidate_summaries = []
    for kind in KINDS:
        rs = [next(c for c in r["candidates"] if c["candidate_id"]==kind) for r in complete]
        candidate_summaries.append({
            "candidate_id":kind,"cost":rs[0]["cost"] if rs else None,
            "accepted":rate(sum(r["decision"]=="accepted" for r in rs),R),
            "excluded":rate(sum(r["decision"]=="excluded" for r in rs),R),
            "unresolved":rate(sum(r["decision"]=="unresolved" for r in rs),R),
            "unavailable_count":R-len(rs),
            "true_feasible":sum(r["true_feasibility"]=="feasible" for r in rs),
            "true_infeasible":sum(r["true_feasibility"]=="infeasible" for r in rs),
            "true_feasibility_unresolved":sum(r["true_feasibility"]=="oracle_unresolved" for r in rs),
            "false_acceptances":sum(r["false_acceptance"] for r in rs),
            "false_exclusions":sum(r["false_exclusion"] for r in rs),
            "exclusion_truth_unresolved":sum(r["exclusion_truth_unresolved"] for r in rs),
            "oracle_exact":sum(r["oracle"]["exact"] for r in rs),
            "oracle_max_gap":max((r["oracle"]["oracle_gap"] for r in rs),default=Fraction(0)),
            "oracle_methods":dict(Counter(r["oracle"]["method"] for r in rs)),
            "mean_L":average([r["L"] for r in rs]),"mean_U":average([r["U"] for r in rs]),
            "mean_width":average([r["interval_width"] for r in rs]),
            "mean_empirical_lower":average([r["empirical_lower"] for r in rs]),
            "mean_empirical_upper":average([r["empirical_upper"] for r in rs]),
            "mean_fitted_risk":average([r["oracle"]["risk_fitted"] for r in rs]),
            "mean_class_opt_lower":average([r["oracle"]["risk_opt_lower"] for r in rs]),
            "mean_class_opt_upper":average([r["oracle"]["risk_opt_upper"] for r in rs]),
            "mean_upper_slack":average([r["U"]-r["oracle"]["risk_fitted"] for r in rs]),
        })
    result["candidates"] = candidate_summaries
    return result


def paired_summary(by_cell, baseline, alternative, R):
    left={r["replicate"]:r for r in by_cell[baseline]}
    right={r["replicate"]:r for r in by_cell[alternative]}
    pairs=[(left[i],right[i]) for i in range(R)
           if left[i]["status"]==right[i]["status"]=="completed"]
    for a,b in pairs:
        if a["seed_hex"] != b["seed_hex"] or a["frozen_models_sha256"] != b["frozen_models_sha256"]:
            raise ValueError("paired ablation did not retain the same development and models")
    result={"baseline":baseline,"alternative":alternative,"planned_pairs":R,
            "completed_pairs":len(pairs),
            "unavailable_pairs":R-len(pairs),
            "difference_scope":"Numerical paired differences use both-completed pairs; no unavailable pair is silently replaced.",
            "operational_acceptance_gained_all_runs":sum(not left[i].get("any_accepted",False) and right[i].get("any_accepted",False) for i in range(R)),
            "operational_acceptance_lost_all_runs":sum(left[i].get("any_accepted",False) and not right[i].get("any_accepted",False) for i in range(R)),
            "any_acceptance_gained":sum(not a["any_accepted"] and b["any_accepted"] for a,b in pairs),
            "any_acceptance_lost":sum(a["any_accepted"] and not b["any_accepted"] for a,b in pairs),
            "minimum_cost_claim_gained":sum(not a["selection"]["minimum_feasible_cost_certified"] and b["selection"]["minimum_feasible_cost_certified"] for a,b in pairs),
            "minimum_cost_claim_lost":sum(a["selection"]["minimum_feasible_cost_certified"] and not b["selection"]["minimum_feasible_cost_certified"] for a,b in pairs),
            "mean_producer_cpu_difference":average([b["producer_cpu_seconds"]-a["producer_cpu_seconds"] for a,b in pairs]),
            "candidates":[]}
    for kind in KINDS:
        cpairs=[(next(c for c in a["candidates"] if c["candidate_id"]==kind),
                 next(c for c in b["candidates"] if c["candidate_id"]==kind)) for a,b in pairs]
        result["candidates"].append({"candidate_id":kind,
            "L_increased":sum(b["L"]>a["L"] for a,b in cpairs),
            "L_decreased":sum(b["L"]<a["L"] for a,b in cpairs),
            "L_equal":sum(b["L"]==a["L"] for a,b in cpairs),
            "mean_L_difference":average([b["L"]-a["L"] for a,b in cpairs]),
            "mean_U_difference":average([b["U"]-a["U"] for a,b in cpairs]),
            "excluded_gained":sum(a["decision"]!="excluded" and b["decision"]=="excluded" for a,b in cpairs),
            "excluded_lost":sum(a["decision"]=="excluded" and b["decision"]!="excluded" for a,b in cpairs)})
    return result


def summarize(protocol_path, results_path):
    protocol_raw=Path(protocol_path).read_bytes()
    protocol=json.loads(protocol_raw)
    ph=hashlib.sha256(protocol_raw).hexdigest()
    resultdir=Path(results_path)
    manifest=json.loads((resultdir/"run_manifest.json").read_text())
    if manifest["protocol_sha256"] != ph:
        raise ValueError("run protocol hash mismatch")
    by_cell={c["cell_id"]:[] for c in protocol["cells"]}
    seen=set()
    for line in (resultdir/"runs.jsonl").read_text().splitlines():
        r=unpack(json.loads(line))
        key=(r["cell_id"],r["replicate"])
        if key in seen or r["cell_id"] not in by_cell or r["protocol_sha256"]!=ph:
            raise ValueError("duplicate or unregistered result")
        seen.add(key)
        by_cell[r["cell_id"]].append(r)
    R=protocol["repetitions_per_cell"]
    for cell in protocol["cells"]:
        rows=by_cell[cell["cell_id"]]
        if len(rows)!=R or {r["replicate"] for r in rows}!=set(range(R)):
            raise ValueError("all registered replicates must be retained before analysis")
        for r in rows:
            if r["status"] not in ("completed","operational_unavailable"):
                raise ValueError("unknown run status")
            if (r["status"]=="operational_unavailable") != (r["joint_risk_event"]=="operational_unavailable"):
                raise ValueError("status and primary event are inconsistent")
            if r["status"]=="completed":
                if len(r["candidates"])!=3 or {c["candidate_id"] for c in r["candidates"]}!=set(KINDS):
                    raise ValueError("exactly one of each candidate must be present")
                if r["verification"].get("numerical_verification")!="passed":
                    raise ValueError("completed run lacks its numerical check")
            if r["p"]!=Fraction(cell["p"]) or r["T"]!=cell["T"]:
                raise ValueError("result cell identity mismatch")
            for field,cfgfield in (("K","blocks"),("q","block_windows"),("g","gap_lag")):
                if r[field]!=cell["config"]["design"][cfgfield]:
                    raise ValueError("recorded temporal design mismatch")
            if r["sweeps"]!=cell["config"]["numerics"]["sweeps"]:
                raise ValueError("recorded optimization setting mismatch")
    alpha=Fraction(protocol["mc_failure_cell_alpha"])
    if alpha*len(protocol["cells"])>Fraction(protocol["mc_failure_total_alpha"]):
        raise ValueError("MC allocation exceeds its family budget")
    cells=[cell_summary(c,by_cell[c["cell_id"]],R,alpha) for c in protocol["cells"]]
    pairs=[paired_summary(by_cell,"p005_K320",x,R)
           for x in ("p005_K320_q1","p005_K320_q16","p005_K320_s0","p005_K320_s32")]
    summary={"protocol_sha256":ph,"source_run_manifest":manifest,
             "registered_cells":len(cells),"repetitions_per_cell":R,"total_runs":len(seen),
             "global_counts_descriptive_only":{
                key:sum(c["joint"][key] for c in cells)
                for key in ("definite_failures","oracle_unresolved","operational_unavailable","conservative_failure_count")},
             "inference_scope":"Each cell has 200 independent-replicate simulation units; cells share matched streams. Do not pool the 2400 rows as independent trials.",
             "secondary_interval_scope":"Pointwise 95% Clopper-Pearson; not simultaneous across rates.",
             "cells":cells,"paired_ablations":pairs}
    (resultdir/"summary.json").write_text(json.dumps(pack(summary),indent=2,allow_nan=False)+"\n")
    return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol",default=str(ROOT/"protocol.json"))
    parser.add_argument("--results",default=str(ROOT/"results"))
    args=parser.parse_args()
    summary=summarize(args.protocol,args.results)
    print(json.dumps(pack({"total_runs":summary["total_runs"],"global":summary["global_counts_descriptive_only"],
                           "cells":[{"cell_id":c["cell_id"],"any_accepted":c["any_accepted"]["count"],
                                     "minimum_cost":c["minimum_cost_certified"]["count"],"all_excluded":c["all_excluded"]["count"],
                                     "conservative_failure_count":c["joint"]["conservative_failure_count"],
                                     "mc_failure_upper":c["joint"]["mc_failure_probability_upper"]}
                                    for c in summary["cells"]]}),indent=2))


if __name__ == "__main__":
    main()
