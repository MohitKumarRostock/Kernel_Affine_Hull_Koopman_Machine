"""Pointwise lower certificates for a frozen Euclidean Lipschitz decoder class.

All returned certificate arithmetic uses Python integers and Fraction. Floating
point is used only to propose signed graph multipliers. The verifier neither
trusts solver convergence nor uses floating point. N is the number of all
calibration windows, including isolated/unpaired vertices; statistical KL
calibration elsewhere must still use the number K of raw blocks.
"""

from __future__ import annotations

from fractions import Fraction
from math import isqrt
from typing import Sequence


Edge = tuple[int, int, Fraction]
ZERO = Fraction(0)
ONE = Fraction(1)


def _fraction(value: Fraction | int, name: str) -> Fraction:
    if isinstance(value, bool) or not isinstance(value, (Fraction, int)):
        raise ValueError(f"{name} must be an exact Fraction or integer")
    return Fraction(value)


def _integer(value: int, name: str, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def ceil_dyadic(value: Fraction, bits: int = 32) -> Fraction:
    """Exact upward rounding to the grid 2**(-bits), including negative values."""
    value = _fraction(value, "value")
    bits = _integer(bits, "bits")
    scale = 1 << bits
    n = value.numerator * scale
    return Fraction(-((-n) // value.denominator), scale)


def floor_dyadic(value: Fraction, bits: int = 40) -> Fraction:
    value = _fraction(value, "value")
    bits = _integer(bits, "bits")
    scale = 1 << bits
    return Fraction((value.numerator * scale) // value.denominator, scale)


def sqrt_upper(value: Fraction, bits: int = 32) -> Fraction:
    """Return a dyadic r with r >= sqrt(value), proved by integer comparison."""
    value = _fraction(value, "value")
    bits = _integer(bits, "bits")
    if value < 0:
        raise ValueError("a squared distance cannot be negative")
    scale = 1 << bits
    numerator = value.numerator * scale * scale
    denominator = value.denominator
    root = isqrt(numerator // denominator)
    if root * root * denominator < numerator:
        root += 1
    result = Fraction(root, scale)
    assert result * result >= value
    return result


def _inputs(
    features: Sequence[Sequence[Fraction]],
    targets: Sequence[Fraction],
    kappa: Fraction,
) -> tuple[list[list[Fraction]], list[Fraction], Fraction]:
    if not targets or len(features) != len(targets):
        raise ValueError("features and targets must have the same positive length")
    ys = [_fraction(y, "target") for y in targets]
    if any(y < 0 or y > 1 for y in ys):
        raise ValueError("every target must lie in [0,1]")
    xs = [[_fraction(v, "feature") for v in row] for row in features]
    dimension = len(xs[0])
    if any(len(row) != dimension for row in xs):
        raise ValueError("feature rows have inconsistent dimensions")
    kappa = _fraction(kappa, "kappa")
    if kappa < 0:
        raise ValueError("kappa must be nonnegative")
    return xs, ys, kappa


def _edge(edge: Sequence[object], n: int) -> Edge:
    if len(edge) != 3:
        raise ValueError("an edge must contain i, j, and its certified bound")
    i, j = edge[0], edge[1]
    _integer(i, "edge endpoint")
    _integer(j, "edge endpoint")
    if i >= n or j >= n or i == j:
        raise ValueError("edge endpoints are invalid")
    c = _fraction(edge[2], "edge bound")
    if c < 0:
        raise ValueError("an edge bound must be nonnegative")
    return i, j, c


def _squared_distance(a: Sequence[Fraction], b: Sequence[Fraction]) -> Fraction:
    return sum(((x - y) ** 2 for x, y in zip(a, b)), ZERO)


def _edge_bound(
    features: Sequence[Sequence[Fraction]], i: int, j: int,
    kappa: Fraction, bits: int,
) -> Fraction:
    if kappa == 0:
        return ZERO
    distance_up = sqrt_upper(_squared_distance(features[i], features[j]), bits)
    # The second outward rounding prevents the supplied kappa denominator from
    # accumulating in graph-dual arithmetic. A bound of 1 is valid because the
    # declared decoder range is [0,1], even if kappa * distance exceeds 1.
    return min(ONE, ceil_dyadic(kappa * distance_up, bits))


def _verify_edge_geometry(
    features: Sequence[Sequence[Fraction]], edge: Edge, kappa: Fraction,
) -> None:
    i, j, c = edge
    if c >= 1:
        return
    if c * c < kappa * kappa * _squared_distance(features[i], features[j]):
        raise ValueError("edge bound underestimates the required feature distance")


def evaluate_dual(
    targets: Sequence[Fraction], edges: Sequence[Sequence[object]],
    weights: Sequence[Fraction], *, boxed: bool = True,
) -> Fraction:
    """Evaluate a signed graph dual exactly, with incidence + at i and - at j.

    Edge bounds are assumed valid here; verify_lower_certificate checks them
    against actual features. For boxed=True, the minimization over each scalar
    prediction retains [0,1]. For boxed=False it relaxes to the whole real line.
    Both values lower-bound the full residual SUM when edge bounds are valid.
    """
    if not targets or len(edges) != len(weights):
        raise ValueError("invalid target or multiplier dimensions")
    ys = [_fraction(y, "target") for y in targets]
    if any(y < 0 or y > 1 for y in ys):
        raise ValueError("every target must lie in [0,1]")
    n = len(ys)
    s = [ZERO for _ in ys]
    penalty = ZERO
    for raw_edge, raw_weight in zip(edges, weights):
        i, j, c = _edge(raw_edge, n)
        weight = _fraction(raw_weight, "multiplier")
        s[i] += weight
        s[j] -= weight
        penalty += c * abs(weight)
    if boxed:
        value = ZERO
        for y, si in zip(ys, s):
            v = min(ONE, max(ZERO, y - si / 2))
            value += (y - v) ** 2 + si * v
        return value - penalty
    return sum((si * y - si * si / 4 for y, si in zip(ys, s)), ZERO) - penalty


def _pair_sse(targets: Sequence[Fraction], pairs: Sequence[Sequence[object]]) -> Fraction:
    used: set[int] = set()
    total = ZERO
    for raw_edge in pairs:
        i, j, c = _edge(raw_edge, len(targets))
        if i in used or j in used:
            raise ValueError("pair residual sums may only be added for disjoint indices")
        used.update((i, j))
        gap = max(ZERO, abs(targets[i] - targets[j]) - c)
        total += gap * gap / 2
    return total


def _choose_edges(
    features: Sequence[Sequence[Fraction]], kappa: Fraction,
    neighbors: int, max_orders: int, distance_bits: int,
) -> list[Edge]:
    """Sparse deterministic proposal; its statistical validity needs no locality."""
    n, dimension = len(features), len(features[0])
    orders: list[list[int]] = [list(range(n))]
    for coordinate in range(min(dimension, max_orders - 1)):
        orders.append(sorted(range(n), key=lambda i: (features[i][coordinate], i)))
    index_edges: set[tuple[int, int]] = set()
    for order in orders:
        for pos, i in enumerate(order):
            for offset in range(1, min(neighbors, n - pos - 1) + 1):
                j = order[pos + offset]
                index_edges.add((min(i, j), max(i, j)))
    return [
        (i, j, _edge_bound(features, i, j, kappa, distance_bits))
        for i, j in sorted(index_edges)
    ]


def _choose_pairs(targets: Sequence[Fraction], edges: Sequence[Edge]) -> list[Edge]:
    ranked = sorted(
        edges,
        key=lambda e: (-max(ZERO, abs(targets[e[0]] - targets[e[1]]) - e[2]), e[0], e[1]),
    )
    used: set[int] = set()
    pairs: list[Edge] = []
    for edge in ranked:
        i, j, c = edge
        if i not in used and j not in used and abs(targets[i] - targets[j]) > c:
            used.update((i, j))
            pairs.append(edge)
    return pairs


def _propose_multipliers(
    targets: Sequence[Fraction], edges: Sequence[Edge], pairs: Sequence[Edge],
    sweeps: int, multiplier_bits: int,
) -> list[Fraction]:
    """Finite coordinate ascent is a proposal only; exact evaluation is decisive."""
    initial = {(i, j): (1 if targets[i] >= targets[j] else -1) *
               max(ZERO, abs(targets[i] - targets[j]) - c) for i, j, c in pairs}
    weights = [float(initial.get((i, j), ZERO)) for i, j, _ in edges]
    residual = [float(y) for y in targets]
    for (i, j, _), weight in zip(edges, weights):
        residual[i] -= weight / 2
        residual[j] += weight / 2
    float_bounds = [float(c) for _, _, c in edges]
    for _ in range(sweeps):
        for e, (i, j, _) in enumerate(edges):
            previous = weights[e]
            proposal = previous + residual[i] - residual[j]
            c = float_bounds[e]
            updated = max(0.0, proposal - c) if proposal >= 0 else min(0.0, proposal + c)
            difference = updated - previous
            weights[e] = updated
            residual[i] -= difference / 2
            residual[j] += difference / 2
    scale = 1 << multiplier_bits
    return [Fraction(round(weight * scale), scale) for weight in weights]


def lower_certificate(
    features: Sequence[Sequence[Fraction]], targets: Sequence[Fraction],
    kappa: Fraction, *, neighbors: int = 2, max_orders: int = 4,
    sweeps: int = 8, distance_bits: int = 32, multiplier_bits: int = 24,
    output_bits: int = 40,
) -> dict:
    """Produce a checkable empirical lower bound for all N calibration windows.

    The graph and its multipliers may depend on all calibration values. Only the
    representation, kappa and decoder class need to have been frozen earlier.
    A finite optimizer iteration count changes informativeness, never validity.
    """
    xs, ys, kappa = _inputs(features, targets, kappa)
    neighbors = _integer(neighbors, "neighbors", 1)
    max_orders = _integer(max_orders, "max_orders", 1)
    sweeps = _integer(sweeps, "sweeps")
    distance_bits = _integer(distance_bits, "distance_bits")
    multiplier_bits = _integer(multiplier_bits, "multiplier_bits")
    output_bits = _integer(output_bits, "output_bits")
    edges = _choose_edges(xs, kappa, neighbors, max_orders, distance_bits)
    pairs = _choose_pairs(ys, edges)
    weights = _propose_multipliers(ys, edges, pairs, sweeps, multiplier_bits)
    graph_sse = evaluate_dual(ys, edges, weights, boxed=True)
    pair_sse = _pair_sse(ys, pairs)
    lower = floor_dyadic(max(ZERO, graph_sse, pair_sse) / len(ys), output_bits)
    record = {
        "schema": "single_trajectory_lower_v1",
        "N": len(ys),
        "lower_empirical": lower,
        "graph_dual_sse": graph_sse,
        "pair_sse": pair_sse,
        "edges": edges,
        "weights": weights,
        "pairs": pairs,
        "settings": {
            "neighbors": neighbors, "max_orders": max_orders, "sweeps": sweeps,
            "distance_bits": distance_bits, "multiplier_bits": multiplier_bits,
            "output_bits": output_bits,
        },
    }
    verify_lower_certificate(xs, ys, kappa, record)
    return record


def verify_lower_certificate(
    features: Sequence[Sequence[Fraction]], targets: Sequence[Fraction],
    kappa: Fraction, record: dict,
) -> bool:
    """Recompute every mathematical check; reject malformed or altered bounds.

    This checks numerical inequalities for the supplied frozen features. Data
    provenance, feature generation, development freezing and scientific mixing
    assumptions are responsibilities of the surrounding trajectory procedure.
    """
    xs, ys, kappa = _inputs(features, targets, kappa)
    n = len(ys)
    if not isinstance(record, dict) or record.get("schema") != "single_trajectory_lower_v1":
        raise ValueError("unrecognized lower certificate")
    if (isinstance(record.get("N"), bool) or
            not isinstance(record.get("N"), int) or record.get("N") != n):
        raise ValueError("the empirical denominator must include all calibration windows")
    try:
        edges = [_edge(edge, n) for edge in record["edges"]]
        pairs = [_edge(edge, n) for edge in record["pairs"]]
        weights = [_fraction(w, "multiplier") for w in record["weights"]]
        reported_graph = _fraction(record["graph_dual_sse"], "graph dual")
        reported_pairs = _fraction(record["pair_sse"], "pair sum")
        lower = _fraction(record["lower_empirical"], "empirical lower bound")
    except (KeyError, TypeError) as exc:
        raise ValueError("incomplete lower certificate") from exc
    for edge in edges + pairs:
        _verify_edge_geometry(xs, edge, kappa)
    graph_sse = evaluate_dual(ys, edges, weights, boxed=True)
    pair_sse = _pair_sse(ys, pairs)
    if reported_graph != graph_sse or reported_pairs != pair_sse:
        raise ValueError("reported residual lower sums do not match exact recomputation")
    if lower < 0 or lower > max(ZERO, graph_sse, pair_sse) / n:
        raise ValueError("the reported empirical lower value is not certified")
    # A constant is feasible for every declared class. This independent exact
    # sanity check catches transcription/normalization errors, not solver error.
    mean = sum(ys, ZERO) / n
    constant_mse = sum(((y - mean) ** 2 for y in ys), ZERO) / n
    if lower > constant_mse:
        raise ValueError("lower bound exceeds a feasible constant decoder's loss")
    return True


__all__ = [
    "ceil_dyadic", "floor_dyadic", "sqrt_upper", "evaluate_dual",
    "lower_certificate", "verify_lower_certificate",
]
