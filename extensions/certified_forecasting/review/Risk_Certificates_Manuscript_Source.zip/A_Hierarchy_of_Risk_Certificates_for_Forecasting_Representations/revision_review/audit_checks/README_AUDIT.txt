SCOPED AUDIT AND REPRODUCTION NOTES
Manuscript revision: 2026-10-31

PURPOSE AND PACKAGE LAYOUT

This directory contains the recorded checks performed for the local manuscript
revision. It distinguishes newly authored diagnostic scripts from a rerun of
an existing author-supplied verifier. No new KAHM fitting or forecasting
experiment was performed.

In the source archive, run the commands below from the directory containing
main.tex and supplement.tex. Paths are relative to that archive root:

    revision_review/audit_checks/     New scripts and their recorded outputs
    revision_review/remote_evidence/  Selected immutable public source/results
    revision_review/changes.patch    Source changes relative to supplied draft

The revision_review directory also contains the review report in PDF and LaTeX.
The selected evidence is sufficient for the scoped commands below, but is not
the complete research repository or a complete archive of every original study.

Pinned public code/results commit:
    d6d74d1953a4310b73065a556df816e5ab5e3ebc

Pinned research extension:
https://github.com/MohitKumarRostock/Kernel_Affine_Hull_Koopman_Machine/tree/d6d74d1953a4310b73065a556df816e5ab5e3ebc/extensions/certified_forecasting

The revised manuscript text and PDFs have a separate local identity. The
repository commit identifies archived code and evidence, not this revised PDF.

ENVIRONMENT AND OUTPUT PRESERVATION

The recorded numerical runs used Python 3.12.14, NumPy 2.3.5, and SciPy 1.17.0.
The new theory and calibration scripts require NumPy and SciPy. The authors'
finite-support verifier requires NumPy. The new table aggregation script uses
only the Python standard library. All are floating-point checks.

Use a new output directory for each rerun to preserve the included reports.
The mkdir/cp commands below use POSIX shell syntax; on another platform, create
the same directories and copy the named script before running the Python
commands. All paths are relative, and the checks need no network access once
this archive has been extracted.

1. NEWLY AUTHORED THEORY DIAGNOSTICS

Script: audit_theory.py
Recorded output: theory_checks.json

This script imports no supplied research code and reads no archived experiment
outputs. It checks finite-dimensional identities, exact finite-law calculations,
pair formulas, subset inequalities, and related small optimization examples.
The recorded run completed 1,796 optimization programs (1,766 scalar and
30 vector programs). Finite tests do not prove the universal inequalities,
compactness consistency, or statistical coverage.

The script accepts no output argument and writes theory_checks.json beside
the script itself. To preserve the recorded result, copy the script first:

    mkdir -p revision_review/reruns/theory
    cp revision_review/audit_checks/audit_theory.py revision_review/reruns/theory/
    python revision_review/reruns/theory/audit_theory.py

That command writes revision_review/reruns/theory/theory_checks.json. Running
the original script in audit_checks directly would replace its adjacent JSON.

2. NEWLY AUTHORED LEARNED-HIERARCHY CALIBRATION CHECKS

Script: independent_calibration_checks.py
Recorded output: independent_calibration_checks.json

This script independently reconstructs 1,520 lower endpoints from saved means,
counts, and stratum summaries, and checks confidence allocation arithmetic.
It includes separate small mathematical diagnostics. It does not reconstruct
raw scores or all 143,440 historical optimization programs. The 240 fitted upper
endpoints are not reconstructed: the available summary CSVs do not contain
the required per-endpoint loss variances.

From the archive root:

    python revision_review/audit_checks/independent_calibration_checks.py \
      --evidence-dir revision_review/remote_evidence \
      --output revision_review/reruns/independent_calibration_checks.json

The script creates the output directory if needed. Choose a fresh --output
filename because this script can overwrite an existing output file.

3. RERUN OF THE AUTHORS' FINITE-SUPPORT VERIFIER

Author-supplied script, read and executed without modification:
    revision_review/remote_evidence/experiments/block_hierarchy/verify.py

Recorded current output: block_hierarchy_author_verifier_rerun.json
Execution receipt: block_hierarchy_rerun_receipt.json
Historical output for comparison:
    revision_review/remote_evidence/results/block_hierarchy_v1/independent_verification.json

This is a rerun of the authors' existing independent reconstruction program,
not a newly authored independent verifier. Before execution it was inspected
for file/process behavior. It reads tar members without extracting or executing
them, checks stored hashes, and writes only the requested new report.

From the archive root:

    python revision_review/remote_evidence/experiments/block_hierarchy/verify.py \
      --results revision_review/remote_evidence/results/block_hierarchy_v1 \
      --output revision_review/reruns/block_hierarchy_author_verifier_rerun.json

The script refuses to overwrite an existing output. The selected evidence
includes protocol.md and source_snapshot.tar.gz with their archived hashes.
This command reads the pinned verifier directly; it does not run an experiment
runner, regenerate fitted models, or require the full repository installation.

The recorded rerun checked 45,579 cached dual certificates and reconstructed
14,400 endpoints from 800 streams containing 3,276,800 categorical draws. It
also reconstructed 4,166,400 individual block scores, checked 3,066 analytic
table rows, and completed 33 small exact-enumeration comparisons. All 22 audit
fields other than the timestamp matched the original verification report.

4. NEWLY AUTHORED TABLE AGGREGATION CHECK

Script: block_hierarchy_table_check.py
Recorded output: block_hierarchy_table_recalculation.json

This standard-library script independently checks completeness of endpoints.csv,
recomputes 576 means/standard deviations across 144 groups, and checks all
56 numeric cells of tables/block_hierarchy.tex after four-decimal rounding.
The risk column is compared with the midpoint of the archived population
primal/dual bracket; this script does not solve those population optimizations.

From the archive root:

    python revision_review/audit_checks/block_hierarchy_table_check.py \
      --results revision_review/remote_evidence/results/block_hierarchy_v1 \
      --table tables/block_hierarchy.tex \
      --output revision_review/reruns/block_hierarchy_table_recalculation.json

The script creates its output directory and refuses to overwrite an existing
report. The recorded table entries all matched the source data after rounding.

5. MANUSCRIPT BUILD, ASSET, AND VISUAL CHECKS

manuscript_build_checks.json records the 50-page main manuscript, 23-page
supplement, 179-word abstract, five keywords, 32-character running title,
build diagnostics, and the identity of 34 retained table/figure assets against
the supplied draft. The assets were preserved, not regenerated by new model
fitting. Visual inspection covered all 73 PDF pages during revision; an orphan
heading was corrected with needspace. README_BUILD.txt gives build commands.
The supplied build_manuscript.py helper is unchanged.

HISTORICAL RESULTS AND LIMITS

The authors' historical release reports 65 standard tests, 7 witness tests,
4 solver tests, and a learned-KAHM audit of 143,440 optimization programs,
1,760 endpoints, and 880 decisions. Those full historical checks were not
rerun for this revision. Do not substitute those counts for the scoped
current checks described above.

Some recorded reports contain absolute paths from the original revision
workspace. They document the original execution; the relative commands above
are the portable rerun instructions. Timestamps, execution paths, and runtimes
will differ on rerun. The scripts describe their numerical tolerances.

Zero observed coverage failures in archived repetitions do not prove a
confidence theorem. Numerical dual checks are not interval arithmetic, and
reusing frozen archived data is not fresh statistical evidence. The revision
does not establish universal KAHM superiority, complete empirical replication
of all studies, or an exhaustive literature-novelty certification.
