#!/usr/bin/env python3
"""Publication figures from the retained Step 5 summary (matplotlib required)."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

from certify_series import unpack

COLORS={"accepted":"#247A62","excluded":"#C36C3B","unresolved":"#D2D9DE","unavailable":"#7C618C"}
MODEL_COLORS={"raw":"#3A647D","memberships":"#AD683A","local_position":"#247A62"}
LABELS={"raw":"Raw history (6 coordinates)","memberships":"Memberships (2 coordinates)","local_position":"Local position (4 coordinates)"}


def apply_style():
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"axes.titlesize":11,
                         "axes.labelsize":9,"axes.spines.top":False,"axes.spines.right":False,
                         "axes.edgecolor":"#8D969C","text.color":"#182832","axes.labelcolor":"#182832",
                         "xtick.color":"#3C4B55","ytick.color":"#3C4B55","savefig.facecolor":"white",
                         "pdf.fonttype":42,"ps.fonttype":42})


def decision_figure(summary,out):
    cells=[c for c in summary["cells"] if c["kind"]=="primary"]
    fig,axes=plt.subplots(1,3,figsize=(12.2,5.6),sharey=True)
    labels=[f"p = {float(c['p']):.2f}, K = {c['K']}" for c in cells]
    for ax,kind in zip(axes,("raw","memberships","local_position")):
        for y,c in enumerate(cells):
            r=next(x for x in c["candidates"] if x["candidate_id"]==kind)
            left=0
            for status in ("accepted","unresolved","excluded","unavailable"):
                value=100*(r[status]["count"] if status!="unavailable" else r["unavailable_count"])/summary["repetitions_per_cell"]
                ax.barh(y,value,left=left,height=.64,color=COLORS[status],edgecolor="white",linewidth=.6)
                if value>=13:
                    color="white" if status in ("accepted","excluded","unavailable") else "#263640"
                    ax.text(left+value/2,y,f"{value:g}%",ha="center",va="center",fontsize=8,color=color)
                left+=value
        ax.set_xlim(0,100)
        ax.set_xticks([0,25,50,75,100])
        ax.xaxis.set_major_formatter(PercentFormatter(100))
        ax.set_title(LABELS[kind],pad=12,fontweight="bold")
        ax.set_xlabel("Share of registered trajectories")
        ax.grid(axis="x",alpha=.16,zorder=0)
        ax.set_axisbelow(True)
        ax.set_yticks(range(len(cells)),labels)
        for y in (1.5,3.5,5.5):ax.axhline(y,color="#E4E8EB",linewidth=.8)
    axes[0].invert_yaxis()
    handles=[plt.Rectangle((0,0),1,1,color=COLORS[s]) for s in ("accepted","excluded","unresolved","unavailable")]
    fig.legend(handles,["Accepted fitted predictor","Excluded class","Unresolved","Unavailable"],
               loc="lower center",ncol=4,frameon=False,bbox_to_anchor=(.53,.015))
    fig.suptitle("Candidate decisions from a single trajectory",x=.52,y=.99,fontweight="bold",fontsize=15)
    fig.text(.52,.935,"200 trajectories per setting  |  normalized MSE tolerance 0.10  |  q = 4",ha="center",fontsize=10,color="#566670")
    fig.subplots_adjust(left=.145,right=.99,top=.84,bottom=.17,wspace=.12)
    for ext in ("png","pdf"):fig.savefig(out/f"primary_decisions.{ext}",dpi=220,bbox_inches="tight")
    plt.close(fig)


def _rate_series(ax,cells,field,label,color,marker,offset=0):
    xs=[i+offset for i in range(len(cells))]
    ys=[100*float(c[field]["fraction"]) for c in cells]
    lows=[y-100*float(c[field]["pointwise_95_interval"][0]) for y,c in zip(ys,cells)]
    highs=[100*float(c[field]["pointwise_95_interval"][1])-y for y,c in zip(ys,cells)]
    ax.errorbar(xs,ys,yerr=[lows,highs],fmt=marker+"-",color=color,capsize=3,linewidth=1.5,markersize=5,label=label)


def ablation_figure(summary,out):
    lookup={c["cell_id"]:c for c in summary["cells"]}
    qc=[lookup[x] for x in ("p005_K320_q1","p005_K320","p005_K320_q16")]
    sc=[lookup[x] for x in ("p005_K320_s0","p005_K320","p005_K320_s32")]
    fig,axes=plt.subplots(2,2,figsize=(11.3,7.4))
    ax=axes[0,0]
    _rate_series(ax,qc,"any_accepted","Any accepted predictor","#3A647D","o",-.025)
    _rate_series(ax,qc,"minimum_cost_certified","Minimum feasible cost certified","#247A62","s",.025)
    ax.set_ylim(-3,103);ax.yaxis.set_major_formatter(PercentFormatter(100));ax.set_ylabel("Rate across 200 trajectories")
    ax.set_title("A  Block size: certification outcomes",fontweight="bold",loc="left")
    ax.set_xticks(range(3),[f"q={c['q']}\nN={c['K']*c['q']:,}" for c in qc])
    ax.legend(frameon=False,fontsize=8,loc="best")
    ax=axes[0,1]
    for kind in ("raw","memberships","local_position"):
        ys=[next(x for x in c["candidates"] if x["candidate_id"]==kind)["mean_L"] for c in sc]
        ax.plot(range(3),ys,"o-",label=kind.replace("_"," ").title(),color=MODEL_COLORS[kind],linewidth=1.5,markersize=5)
    ax.axhline(.1,color="#59656D",linestyle="--",linewidth=1,label="Tolerance 0.10")
    ax.set_ylabel("Mean certified lower endpoint L")
    ax.set_title("B  Optimization: lower-bound strength",fontweight="bold",loc="left")
    ax.set_xticks(range(3),[f"{c['sweeps']} sweeps" for c in sc])
    ax.legend(frameon=False,fontsize=8,loc="best")
    for ax,cells,title in ((axes[1,0],qc,"C  Block size: calculation cost"),(axes[1,1],sc,"D  Optimization: calculation cost")):
        for field,label,color,marker in (("producer_cpu_seconds","Producer","#3A647D","o"),("checker_cpu_seconds","Separate checker","#247A62","s")):
            ax.plot(range(3),[c["timing"][field]["median"] for c in cells],marker+"-",color=color,label=label,linewidth=1.5,markersize=5)
        ax.set_ylabel("Median CPU seconds per trajectory")
        ax.set_title(title,fontweight="bold",loc="left")
        ax.set_ylim(bottom=0)
        ax.legend(frameon=False,fontsize=8)
    axes[1,0].set_xticks(range(3),[f"q={c['q']}\nT={c['T']:,}" for c in qc])
    axes[1,1].set_xticks(range(3),[f"{c['sweeps']} sweeps" for c in sc])
    for ax in axes.ravel():
        ax.grid(axis="y",alpha=.2);ax.set_axisbelow(True);ax.set_xlim(-.25,2.25)
    fig.suptitle("Matched comparisons: persistent process, p = 0.05, K = 320",fontsize=14,fontweight="bold",y=.99)
    fig.text(.5,.018,"Rate bars: pointwise 95% exact binomial intervals. Block-size comparisons change N and raw T.\nCPU times describe this implementation and environment; they are not deployment latency.",ha="center",fontsize=9,color="#566670")
    fig.subplots_adjust(left=.08,right=.985,top=.9,bottom=.13,hspace=.4,wspace=.28)
    for ext in ("png","pdf"):fig.savefig(out/f"matched_ablations.{ext}",dpi=220,bbox_inches="tight")
    plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--summary",default=str(Path(__file__).resolve().parent/"results/summary.json"))
    parser.add_argument("--out",default=str(Path(__file__).resolve().parent/"figures"))
    args=parser.parse_args()
    summary=unpack(json.loads(Path(args.summary).read_text()))
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    apply_style();decision_figure(summary,out);ablation_figure(summary,out)
    print("Saved primary decision and matched comparison figures.")


if __name__ == "__main__":main()
