"""Verified finite-support population risks for a symmetric binary Markov law.

The process starts in its stationary (1/2,1/2) law and flips with rational
probability p. All histories are enumerated, with exact probabilities. Fitted
predictor risk is exact. The full Euclidean Lipschitz-class optimum is either
identified exactly or enclosed using rational, verified primal/dual values.
Floating-point coordinate ascent proposes multipliers only. It never supplies
an unverified oracle value, convergence claim, or feasibility decision.

This oracle describes the declared synthetic law. It neither estimates mixing
from a trajectory nor verifies stationarity of an application dataset.
"""

from __future__ import annotations

from copy import deepcopy
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, product
import math
from typing import Any

from certified_models import encode, verify_model

ZERO, ONE = Fraction(0), Fraction(1)
HALF = Fraction(1, 2)


def _q(value: Any, name: str) -> Fraction:
    if isinstance(value, bool) or not isinstance(value, (Fraction, int, str)):
        raise ValueError(f"{name} must be an exact integer, fraction, or decimal string")
    try:
        return Fraction(value)
    except (ValueError, ZeroDivisionError) as exc:
        raise ValueError(f"{name} is not a finite rational") from exc


def _count(value: Any, name: str, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def _clip(value: Fraction) -> Fraction:
    return min(ONE, max(ZERO, value))


def _floor(value: Fraction, bits: int) -> Fraction:
    scale = 1 << bits
    return Fraction((value.numerator * scale) // value.denominator, scale)


def _ceil(value: Fraction, bits: int) -> Fraction:
    return -_floor(-value, bits)


def _sqrt_floor(value: Fraction, bits: int) -> Fraction:
    if value < 0:
        raise ValueError("square root of negative value")
    scale = 1 << bits
    root = math.isqrt((value.numerator * scale * scale) // value.denominator)
    return Fraction(root, scale)


def _sqrt_ceil(value: Fraction, bits: int) -> Fraction:
    lower = _sqrt_floor(value, bits)
    return lower if lower * lower == value else lower + Fraction(1, 1 << bits)


def _distance_squared(u: tuple, v: tuple) -> Fraction:
    return sum(((a - b) ** 2 for a, b in zip(u, v)), ZERO)


def _encoder_key(model: dict) -> tuple:
    kind = model["encoder_kind"]
    d = model["history"]
    scale = _q(model.get("feature_scale", ONE), "feature_scale")
    if kind == "raw":
        return kind, d, scale, (), (), ONE, ONE, 1
    return (
        kind, d, scale,
        tuple(tuple(_q(x, "center") for x in row) for row in model["centers"]),
        tuple(model["axes"]), _q(model["score_scale"], "score_scale"),
        _q(model["eta"], "eta"), model["omega"],
    )


def _encoder_from_key(key: tuple) -> dict:
    kind, d, scale, centers, axes, score_scale, eta, omega = key
    return {
        "model_version": 1, "encoder_kind": kind, "history": d,
        "feature_scale": scale, "centers": centers, "axes": axes,
        "score_scale": score_scale, "eta": eta, "omega": omega,
    }


@lru_cache(maxsize=512)
def _history_features(key: tuple) -> tuple:
    encoder = _encoder_from_key(key)
    return tuple(
        (tuple(Fraction(x) for x in history), tuple(encode(encoder, history)))
        for history in product((0, 1), repeat=key[1])
    )


@lru_cache(maxsize=64)
def stationary_history_law(history: int, p: Fraction) -> tuple:
    """Tuples (binary history, stationary mass, probability next value is 1)."""
    d = _count(history, "history", 1)
    p = _q(p, "p")
    if not ZERO <= p <= ONE:
        raise ValueError("p must lie in [0,1]")
    rows = []
    for raw in product((0, 1), repeat=d):
        h = tuple(Fraction(x) for x in raw)
        mass = HALF
        for earlier, later in zip(h, h[1:]):
            mass *= p if earlier != later else 1 - p
        mean = p + (1 - 2 * p) * h[-1]
        rows.append((h, mass, mean))
    if sum((row[1] for row in rows), ZERO) != ONE:
        raise ArithmeticError("stationary history probabilities do not sum to one")
    if sum((row[1] * row[2] for row in rows), ZERO) != HALF:
        raise ArithmeticError("stationary target mean is not one half")
    return tuple(rows)


@lru_cache(maxsize=512)
def _atoms(key: tuple, p: Fraction) -> tuple:
    table: dict[tuple, list[Fraction]] = {}
    for (history, features), (h, mass, mean) in zip(
            _history_features(key), stationary_history_law(key[1], p)):
        if history != h:
            raise ArithmeticError("history enumeration mismatch")
        if mass == 0:
            continue
        values = table.setdefault(features, [ZERO, ZERO])
        values[0] += mass
        values[1] += mass * mean
    return tuple((u, mass, one_mass / mass)
                 for u, (mass, one_mass) in sorted(table.items()))


def _information_risk(atoms: tuple) -> Fraction:
    return sum((mass * mean * (1 - mean) for _, mass, mean in atoms), ZERO)


def _fit_risk(model: dict, key: tuple, p: Fraction) -> Fraction:
    weights = tuple(_q(w, "affine weight") for w in model["affine_weights"])
    intercept = _q(model["intercept"], "intercept")
    total = ZERO
    for (history, features), (h, mass, mean) in zip(
            _history_features(key), stationary_history_law(key[1], p)):
        if history != h:
            raise ArithmeticError("history enumeration mismatch")
        prediction = _clip(intercept + sum((w * u for w, u in zip(weights, features)), ZERO))
        total += mass * (mean * (1 - prediction) ** 2 + (1 - mean) * prediction ** 2)
    return total


def _feasible(atoms: tuple, values: tuple, kappa: Fraction) -> bool:
    if len(values) != len(atoms) or any(v < 0 or v > 1 for v in values):
        return False
    for i, j in combinations(range(len(atoms)), 2):
        if (values[i] - values[j]) ** 2 > kappa * kappa * _distance_squared(atoms[i][0], atoms[j][0]):
            return False
    return True


def _risk_values(atoms: tuple, values: tuple) -> Fraction:
    return _information_risk(atoms) + sum(
        (mass * (value - mean) ** 2 for (_, mass, mean), value in zip(atoms, values)), ZERO
    )


def _bayes_affine_witness(key: tuple, p: Fraction, kappa: Fraction) -> tuple | None:
    """Exact sufficient norm test for the raw/latest-local default instances."""
    kind, d, scale, centers, axes, _, _, _ = key
    rho = 1 - 2 * p
    if kind == "raw":
        weights = (ZERO,) * (d - 1) + (rho / scale,)
    elif kind == "local_position" and all(axis == d - 1 for axis in axes):
        weights = tuple(rho * center[-1] / scale for center in centers) + (rho / scale,) * len(centers)
    else:
        return None
    if sum((w * w for w in weights), ZERO) > kappa * kappa:
        return None
    # This finite check also protects the algebraic shortcut against a future
    # change to the feature ordering or semantics in certified_models.py.
    for (history, features), (_, mass, mean) in zip(
            _history_features(key), stationary_history_law(d, p)):
        if mass and _clip(p + sum((w * u for w, u in zip(weights, features)), ZERO)) != mean:
            raise ArithmeticError("affine Bayes witness does not match the conditional mean")
    return p, weights


def _edges(atoms: tuple, kappa: Fraction, bits: int) -> tuple:
    result = []
    for i, j in combinations(range(len(atoms)), 2):
        squared = _distance_squared(atoms[i][0], atoms[j][0])
        bound = min(ONE, _ceil(kappa * _sqrt_ceil(squared, bits), bits))
        if bound < 1 and bound * bound < kappa * kappa * squared:
            raise ArithmeticError("outward edge bound failed")
        result.append((i, j, bound))
    return tuple(result)


def _dual(atoms: tuple, edges: tuple, multipliers: tuple) -> tuple:
    if len(edges) != len(multipliers):
        raise ValueError("dual dimension mismatch")
    s = [ZERO] * len(atoms)
    penalty = ZERO
    for (i, j, bound), multiplier in zip(edges, multipliers):
        s[i] += multiplier
        s[j] -= multiplier
        penalty += bound * abs(multiplier)
    values = tuple(_clip(mean - si / (2 * mass))
                   for (_, mass, mean), si in zip(atoms, s))
    excess = sum((mass * (value - mean) ** 2 + si * value
                  for (_, mass, mean), si, value in zip(atoms, s, values)), ZERO) - penalty
    return excess, values


def _propose_dual(atoms: tuple, edges: tuple, sweeps: int, bits: int) -> tuple:
    """Weighted unboxed dual coordinate ascent; final arithmetic is exact."""
    masses = [float(atom[1]) for atom in atoms]
    if not all(math.isfinite(w) and w > 0 for w in masses):
        return (ZERO,) * len(edges), 0, "float_mass_unavailable"
    values = [float(atom[2]) for atom in atoms]
    multipliers = [0.0] * len(edges)
    bounds = [float(edge[2]) for edge in edges]
    used = 0
    try:
        for used in range(1, sweeps + 1):
            max_change = 0.0
            for e, (i, j, _) in enumerate(edges):
                curvature = 0.5 / masses[i] + 0.5 / masses[j]
                if not math.isfinite(curvature):
                    raise ArithmeticError("float curvature unavailable")
                old = multipliers[e]
                proposal = old + (values[i] - values[j]) / curvature
                threshold = bounds[e] / curvature
                new = max(0.0, proposal - threshold) if proposal >= 0 else min(0.0, proposal + threshold)
                change = new - old
                multipliers[e] = new
                values[i] -= change / (2 * masses[i])
                values[j] += change / (2 * masses[j])
                max_change = max(max_change, abs(change))
            if max_change <= 1e-14:
                break
        scale = 1 << bits
        result = tuple(Fraction(round(Fraction.from_float(v) * scale), scale) for v in multipliers)
        return result, used, "finite_coordinate_proposal"
    except (ArithmeticError, ValueError, OverflowError):
        return (ZERO,) * len(edges), used, "float_proposal_unavailable"


def _repair_primal(atoms: tuple, proposal: tuple, kappa: Fraction, bits: int) -> tuple:
    # Dyadic values limit certificate size. This rounding has no claimed bound
    # direction: the subsequently repaired values are checked for feasibility.
    scale = 1 << bits
    values = tuple(_clip(Fraction(round(value * scale), scale)) for value in proposal)
    shrink = ONE
    for i, j in combinations(range(len(atoms)), 2):
        difference = values[i] - values[j]
        if not difference:
            continue
        ratio_squared = kappa * kappa * _distance_squared(atoms[i][0], atoms[j][0]) / (difference * difference)
        if ratio_squared < 1:
            shrink = min(shrink, _sqrt_floor(ratio_squared, bits))
    repaired = tuple(HALF + shrink * (value - HALF) for value in values)
    if not _feasible(atoms, repaired, kappa):
        raise ArithmeticError("exact primal feasibility repair failed")
    return repaired


@lru_cache(maxsize=512)
def _class_bounds(key: tuple, p: Fraction, kappa: Fraction, sweeps: int,
                  distance_bits: int, multiplier_bits: int, primal_bits: int) -> dict:
    atoms = _atoms(key, p)
    information = _information_risk(atoms)
    means = tuple(atom[2] for atom in atoms)
    witness = _bayes_affine_witness(key, p, kappa)
    if witness is not None:
        bayes = p * (1 - p)
        if information != bayes:
            raise ArithmeticError("Bayes witness contradicts aggregated information risk")
        return {"lower": information, "upper": information, "information": information,
                "method": "exact_affine_bayes_witness", "sweeps_used": 0,
                "proof": {"kind": "affine_bayes", "intercept": witness[0], "weights": witness[1]}}
    if _feasible(atoms, means, kappa):
        return {"lower": information, "upper": information, "information": information,
                "method": "exact_feasible_atom_means", "sweeps_used": 0,
                "proof": {"kind": "atom_means", "values": means}}
    if kappa == 0:
        return {"lower": Fraction(1, 4), "upper": Fraction(1, 4), "information": information,
                "method": "exact_constant_class", "sweeps_used": 0,
                "proof": {"kind": "constant_class", "value": HALF}}
    edges = _edges(atoms, kappa, distance_bits)
    multipliers, used, proposal_status = _propose_dual(atoms, edges, sweeps, multiplier_bits)
    excess, dual_values = _dual(atoms, edges, multipliers)
    lower = information + max(ZERO, excess)
    primal_candidates = [_repair_primal(atoms, means, kappa, primal_bits),
                         _repair_primal(atoms, dual_values, kappa, primal_bits),
                         (HALF,) * len(atoms)]
    primal = min(primal_candidates, key=lambda values: _risk_values(atoms, values))
    upper = _risk_values(atoms, primal)
    if not information <= lower <= upper <= Fraction(1, 4):
        raise ArithmeticError("verified population oracle bounds are inconsistent")
    return {"lower": lower, "upper": upper, "information": information,
            "method": "verified_weighted_primal_dual", "sweeps_used": used,
            "proposal_status": proposal_status,
            "proof": {"kind": "weighted_primal_dual", "edges": edges,
                      "multipliers": multipliers, "primal_values": primal,
                      "dual_excess": excess}}


def population_oracle(
    model: dict, p: Any, *, sweeps: int = 2000, distance_bits: int = 48,
    multiplier_bits: int = 48, primal_bits: int = 40, include_proof: bool = False,
) -> dict:
    """Exact fitted risk and rigorous class-optimum bounds for the supplied law.

    ``exact`` refers to equality of the class lower/upper bounds. An interval is
    never treated as an exact oracle. Risk/feasibility decisions whose threshold
    lies inside a nonzero oracle interval must remain unresolved.
    """
    verify_model(model)
    p = _q(p, "p")
    if not ZERO <= p <= ONE:
        raise ValueError("p must lie in [0,1]")
    sweeps = _count(sweeps, "sweeps")
    distance_bits = _count(distance_bits, "distance_bits", 1)
    multiplier_bits = _count(multiplier_bits, "multiplier_bits", 1)
    primal_bits = _count(primal_bits, "primal_bits", 1)
    key, kappa = _encoder_key(model), _q(model["kappa"], "kappa")
    fitted = _fit_risk(model, key, p)
    bounds = _class_bounds(key, p, kappa, sweeps, distance_bits, multiplier_bits, primal_bits)
    upper = min(bounds["upper"], fitted)
    lower = bounds["lower"]
    if not ZERO <= bounds["information"] <= lower <= upper <= fitted <= ONE:
        raise ArithmeticError("fitted risk and class bounds are inconsistent")
    atoms = _atoms(key, p)
    result = {
        "schema": "binary_markov_population_oracle_v1", "p": p,
        "risk_fitted": fitted, "risk_opt_lower": lower, "risk_opt_upper": upper,
        "oracle_gap": upper - lower, "exact": lower == upper,
        "information_risk": bounds["information"], "irreducible_risk": p * (1 - p),
        "history_count": 1 << key[1],
        "positive_history_count": sum(mass > 0 for _, mass, _ in stationary_history_law(key[1], p)),
        "atom_count": len(atoms), "method": bounds["method"],
        "sweeps_used": bounds["sweeps_used"],
        "upper_witness": "fitted_predictor" if fitted < bounds["upper"] else "class_oracle",
        "settings": {"sweeps": sweeps, "distance_bits": distance_bits,
                     "multiplier_bits": multiplier_bits, "primal_bits": primal_bits},
    }
    if include_proof:
        result["proof"] = deepcopy(bounds["proof"])
    return result


def cache_info() -> dict:
    """Small deterministic diagnostics; cache identity excludes fitted coefficients."""
    return {"features": _history_features.cache_info()._asdict(),
            "atoms": _atoms.cache_info()._asdict(),
            "classes": _class_bounds.cache_info()._asdict()}


__all__ = ["population_oracle", "stationary_history_law", "cache_info"]
