"""Independent analytic checks of population-oracle weighting and geometry."""

from fractions import Fraction as F
import unittest

from population_oracle import _dual, _repair_primal, population_oracle


class PopulationOracleIndependentAudit(unittest.TestCase):
    def test_asymmetric_two_atom_dual_has_exact_known_optimum_both_signs(self):
        # Min (1/4)*(v0-mu0)^2+(3/4)*(v1-mu1)^2, |v0-v1|<=1/4.
        # For means(0,1): v=(9/16,13/16), objective27/256, lambda=-9/32.
        # Reversing the means flips lambda and complements the predictions.
        for means, multiplier, optimum_values in [
            ((F(0),F(1)),F(-9,32),(F(9,16),F(13,16))),
            ((F(1),F(0)),F(9,32),(F(7,16),F(3,16))),
        ]:
            atoms = (((F(0),),F(1,4),means[0]), ((F(1),),F(3,4),means[1]))
            excess, values = _dual(atoms, ((0,1,F(1,4)),), (multiplier,))
            self.assertEqual(values,optimum_values)
            self.assertEqual(excess,F(27,256))
            exact_primal = F(1,4)*(values[0]-means[0])**2+F(3,4)*(values[1]-means[1])**2
            self.assertEqual(exact_primal,excess)

    def test_global_primal_shrink_has_known_feasible_result(self):
        atoms = (((F(0),F(0)),F(1,8),F(0)),
                 ((F(1),F(0)),F(3,8),F(1)),
                 ((F(0),F(1)),F(1,2),F(1,2)))
        repaired = _repair_primal(atoms,(F(0),F(1),F(1,2)),F(1,4),32)
        self.assertEqual(repaired,(F(3,8),F(5,8),F(1,2)))
        self.assertLessEqual((repaired[0]-repaired[1])**2,F(1,16))
        self.assertLessEqual((repaired[0]-repaired[2])**2,F(1,16))
        self.assertLessEqual((repaired[1]-repaired[2])**2,F(1,8))

    def test_raw_feature_scaling_changes_class_optimum_as_required(self):
        m = {"model_version":1,"candidate_id":"scaled_raw","encoder_kind":"raw",
             "history":1,"feature_scale":F(1,10),"kappa":F(1,4),
             "coordinate_cost":1,"affine_weights":[F(0)],"intercept":F(1,2)}
        for p in [F(1,20),F(19,20)]:
            # Two features are separated by 1/10; allowed prediction gap=1/40.
            optimum = p*(1-p)+(abs(1-2*p)-F(1,40))**2/4
            result = population_oracle(m,p)
            self.assertLessEqual(result["risk_opt_lower"],optimum)
            self.assertGreaterEqual(result["risk_opt_upper"],optimum)
            self.assertLess(result["oracle_gap"],F(1,10**9))
            self.assertGreater(result["risk_opt_lower"],p*(1-p))

    def test_local_bayes_identity_holds_for_nonsymmetric_rational_centers(self):
        m = {"model_version":1,"candidate_id":"local_audit","encoder_kind":"local_position",
             "history":3,"feature_scale":F(1),"kappa":F(2),
             "centers":[[F(1,3),F(4,5),F(2,3)],[F(7,8),F(1,9),F(1,4)]],
             "axes":[2,2],"score_scale":F(2,3),"eta":F(1,16),"omega":2,
             "coordinate_cost":4,"affine_weights":[F(0)]*4,"intercept":F(1,2)}
        result = population_oracle(m,F(19,20))
        self.assertTrue(result["exact"])
        self.assertEqual(result["risk_opt_lower"],F(19,400))
        self.assertEqual(result["risk_opt_upper"],F(19,400))


if __name__ == "__main__":
    unittest.main()
