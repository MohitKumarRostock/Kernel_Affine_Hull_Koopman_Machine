"""Non-protocol fixtures for runner logic; no scientific records are generated."""

from copy import deepcopy
from fractions import Fraction as F
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import run_experiment as r


def fixture():
    # p=1/4, rho=1/2, K=4: eta=2*(1/2)^8=1/128 <= .01.
    config = {
        "schema_version": 1,
        "support": {"lower": "0", "upper": "1", "justification": "Binary unit-test law."},
        "stationarity": {"asserted": True, "justification": "Unit-test symmetric Markov law with fair initial state."},
        "dependence": {"kind": "geometric", "C": "1/2", "rho": "1/2", "justification": "Exact binary Markov beta formula; unit-test fixture."},
        "design": {"prespecified": True, "provenance": "Non-protocol fixed unit-test design.",
                   "history": 3, "development_count": 16, "blocks": 4,
                   "block_windows": 2, "gap_lag": 8},
        "risk_tolerance": "1/5", "failure_probability": "1/20",
        "statistical_budget": "1/25", "dependence_budget": "1/100",
        "candidates": {"kappa": "2"},
        "numerics": {"sweeps": 2, "endpoint_bits": 16, "log_terms": 64},
    }
    return {"cell_id": "unit_test_only", "p": "1/4", "T": 64, "config": config}


ORACLE_SETTINGS = {"sweeps": 16, "distance_bits": 24, "multiplier_bits": 24, "primal_bits": 20}


class ExperimentRunnerTests(unittest.TestCase):
    def test_shared_seed_matches_prefix_but_replications_differ(self):
        seed = r.seed_for("unit-test-step5", F(1, 4), 17)
        self.assertEqual(seed, r.seed_for("unit-test-step5", "0.25", 17))
        self.assertNotEqual(seed, r.seed_for("unit-test-step5", F(1, 4), 18))
        self.assertNotEqual(seed, r.seed_for("unit-test-step5", F(3, 4), 17))
        self.assertEqual(r.generate_series(F(1, 4), 90, seed)[:64], r.generate_series(F(1, 4), 64, seed))

    def test_risk_event_distinguishes_interval_ambiguity(self):
        oracle = {"risk_fitted": F(3, 10), "risk_opt_lower": F(1, 10), "risk_opt_upper": F(1, 5)}
        self.assertEqual(r.risk_event(F(1, 10), F(3, 10), oracle), "covered")
        self.assertEqual(r.risk_event(F(3, 20), F(3, 10), oracle), "oracle_unresolved")
        self.assertEqual(r.risk_event(F(1, 4), F(3, 10), oracle), "violation")
        self.assertEqual(r.risk_event(F(0), F(1, 4), oracle), "violation")

    def test_feasibility_threshold_equality_and_ambiguity(self):
        oracle = {"risk_opt_lower": F(1, 10), "risk_opt_upper": F(1, 5)}
        self.assertEqual(r.class_feasibility(oracle, F(1, 5)), "feasible")
        self.assertEqual(r.class_feasibility(oracle, F(1, 10)), "oracle_unresolved")
        self.assertEqual(r.class_feasibility(oracle, F(1, 20)), "infeasible")

    def test_cost_brackets_with_infinite_and_uncertain_truth(self):
        def check(cl, cu, tl, tu):
            return r.check_cost_claim({"cost_lower": cl, "cost_upper": cu}, {"lower": tl, "upper": tu})
        self.assertEqual(check(None, None, None, None), "covered")
        self.assertEqual(check(2, None, None, None), "covered")
        self.assertEqual(check(2, 4, None, None), "violation")
        self.assertEqual(check(None, None, 2, 4), "violation")
        self.assertEqual(check(None, None, 2, None), "oracle_unresolved")
        self.assertEqual(check(2, 4, 2, 4), "covered")
        self.assertEqual(check(2, 2, 2, 4), "oracle_unresolved")
        self.assertEqual(check(2, 2, 4, None), "violation")

    def test_nonprotocol_run_is_checked_and_first_certificate_saved(self):
        with tempfile.TemporaryDirectory() as directory:
            row = r.run_one(fixture(), 0, "unit-test-step5", "unit-test-protocol-hash", ORACLE_SETTINGS, directory)
            self.assertEqual(row["status"], "completed")
            self.assertEqual(row["verification"]["numerical_verification"], "passed")
            self.assertEqual(row["joint_risk_event"], "covered")
            self.assertEqual(len(row["candidates"]), 3)
            path = Path(directory, "unit_test_only_r000.json")
            self.assertTrue(path.exists())
            payload = r.unpack(json.loads(path.read_text()))
            self.assertEqual(len(payload["oracle_proofs"]), 3)
            self.assertEqual(payload["protocol_sha256"], "unit-test-protocol-hash")

    def test_checker_failure_is_retained_without_replacement(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(r, "verify_report", side_effect=ValueError("injected checker failure")):
            row = r.run_one(fixture(), 7, "unit-test-step5", "unit-test-protocol-hash", ORACLE_SETTINGS, directory)
            self.assertEqual(row["status"], "operational_unavailable")
            self.assertEqual(row["replicate"], 7)
            self.assertIn("injected checker failure", row["error"])
            payload = json.loads(Path(directory, "unit_test_only_r007_unavailable.json").read_text())
            self.assertIsNotNone(payload["report"])
            self.assertEqual(payload["row"]["seed_hex"], row["seed_hex"])

    def test_correct_cost_does_not_excuse_selected_false_acceptance(self):
        cell = fixture()
        seed = r.seed_for("unit-test-step5", F(1, 4), 1)
        report = r.certify(r.generate_series(F(1, 4), cell["T"], seed), cell["config"])
        report = deepcopy(report)
        report["selection"].update({"selected_candidate_id": "memberships", "cost_lower": 2,
                                    "cost_upper": 2, "minimum_feasible_cost_certified": True})
        for row in report["selection"]["candidates"]:
            if row["candidate_id"] == "memberships":
                row["status"] = "accepted"
        for row in report["candidates"]:
            if row["candidate_id"] == "memberships":
                row["U"] = F(1, 5)
        # This mocked truth isolates the decision-regression case: class feasible,
        # minimum cost correct, but the accepted fitted witness violates tau.
        truth = {"risk_fitted": F(3, 10), "risk_opt_lower": F(1, 10), "risk_opt_upper": F(1, 10)}
        with tempfile.TemporaryDirectory() as directory, \
             patch.object(r, "certify", return_value=report), \
             patch.object(r, "verify_report", return_value={"numerical_verification": "mocked"}), \
             patch.object(r, "population_oracle", return_value=truth):
            row = r.run_one(cell, 1, "unit-test-step5", "unit-test-protocol-hash", ORACLE_SETTINGS, directory)
            self.assertEqual(row["status"], "completed")
            self.assertEqual(row["oracle_cost"]["lower"], 2)
            self.assertEqual(row["oracle_cost"]["upper"], 2)
            self.assertEqual(row["optimal_claim_event"], "violation")
            self.assertEqual(row["joint_risk_event"], "violation")
            self.assertTrue(Path(directory, "unit_test_only_r001.json").exists())


if __name__ == "__main__":
    unittest.main()
