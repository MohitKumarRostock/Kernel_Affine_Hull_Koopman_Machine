"""Outward KL endpoints using only exact Python integer/rational arithmetic.

This module never uses a floating-point logarithm, exponential, square root,
or a convergence test based on floating-point values.  Inputs are integers or
``fractions.Fraction`` objects; floating-point inputs are deliberately rejected.

For v in [0,1], K >= 1 and 0 < alpha < 1, the mathematical roots delimit

    {p in [0,1] : K * kl(v || p) <= log(1 / alpha)}.

``kl_lower`` returns a dyadic number no larger than the lower root;
``kl_upper`` returns a dyadic number no smaller than the upper root.  They use
a fixed number of binary-search decisions and a fixed maximum number of terms
per logarithm.  If a comparison cannot be resolved, the current valid outer
bracket is retained.  The result stays conservative but can be wider than the
requested grid size.  ``kl_enclosure`` exposes that diagnostic.

Logarithm proof: write x = 2**k * u, 1 <= u < 2, and z = (u-1)/(u+1).
For n >= 1 and 0 <= z <= 1/3,

  S_n = 2 sum_{j=0}^{n-1} z**(2*j+1)/(2*j+1),
  S_n <= log(u) <= S_n + 2*z**(2*n+1)/((2*n+1)*(1-z*z)).

The upper remainder bound follows by replacing every remaining denominator
with 2*n+1 and summing a geometric series.  The same construction bounds log 2.
The sign of k is respected when multiplying its interval.  All operations in
these enclosures are exact rational operations.

For practical use, empirical lower inputs may first be rounded downward with
``dyadic_floor`` and empirical upper inputs upward with ``dyadic_ceil``.  The
monotonicity of both KL endpoints in v preserves their respective guarantees.
This controls input bit length; it is not required for correctness.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from typing import Optional

ZERO = Fraction(0)
ONE = Fraction(1)


def _rational(value: Fraction | int, name: str) -> Fraction:
    if isinstance(value, bool) or not isinstance(value, (Fraction, int)):
        raise TypeError(f"{name} must be an int or Fraction, not a float")
    return Fraction(value)


def _bits(bits: int) -> int:
    if isinstance(bits, bool) or not isinstance(bits, int) or not 0 <= bits <= 128:
        raise ValueError("bits must be an integer in [0, 128]")
    return bits


def dyadic_floor(value: Fraction | int, bits: int = 20) -> Fraction:
    """Return the greatest multiple of 2**(-bits) no larger than value."""
    value = _rational(value, "value")
    scale = 1 << _bits(bits)
    return Fraction(value.numerator * scale // value.denominator, scale)


def dyadic_ceil(value: Fraction | int, bits: int = 20) -> Fraction:
    """Return the least multiple of 2**(-bits) no smaller than value."""
    value = _rational(value, "value")
    scale = 1 << _bits(bits)
    return Fraction(-((-value.numerator * scale) // value.denominator), scale)


def _atanh_log_bounds(u: Fraction, terms: int) -> tuple[Fraction, Fraction]:
    """Bounds log(u) for 1 <= u <= 2 by a positive rational series."""
    z = (u - 1) / (u + 1)
    if z == 0:
        return ZERO, ZERO
    z2 = z * z
    power = z
    total = ZERO
    for j in range(terms):
        total += power / (2 * j + 1)
        power *= z2
    lower = 2 * total
    remainder = 2 * power / ((2 * terms + 1) * (1 - z2))
    return lower, lower + remainder


@lru_cache(maxsize=32)
def _log2_bounds(terms: int) -> tuple[Fraction, Fraction]:
    return _atanh_log_bounds(Fraction(2), terms)


def log_bounds(x: Fraction | int, terms: int = 32) -> tuple[Fraction, Fraction]:
    """Return rigorous rational lower/upper bounds on natural log(x).

    ``terms`` is an explicit finite work parameter, not a numerical tolerance.
    Larger values improve the enclosure.  There is no rounding-error allowance
    because all series terms and remainder bounds are evaluated exactly.
    """
    x = _rational(x, "x")
    if x <= 0:
        raise ValueError("logarithm input must be positive")
    if isinstance(terms, bool) or not isinstance(terms, int) or terms < 1:
        raise ValueError("terms must be a positive integer")
    n, d = x.numerator, x.denominator
    k = n.bit_length() - d.bit_length()
    if k >= 0:
        if n < (d << k):
            k -= 1
    elif (n << (-k)) < d:
        k -= 1
    u = Fraction(n, d << k) if k >= 0 else Fraction(n << (-k), d)
    lower, upper = _atanh_log_bounds(u, terms)
    if k == 0:
        return lower, upper
    log2_lower, log2_upper = _log2_bounds(terms)
    if k > 0:
        return lower + k * log2_lower, upper + k * log2_upper
    return lower + k * log2_upper, upper + k * log2_lower


def _kl_bounds(v: Fraction, p: Fraction, terms: int) -> tuple[Fraction, Fraction]:
    # Callers only use 0 < p < 1; v may equal an endpoint.
    lower = upper = ZERO
    if v:
        lo, hi = log_bounds(v / p, terms)
        lower += v * lo
        upper += v * hi
    if v != 1:
        lo, hi = log_bounds((1 - v) / (1 - p), terms)
        lower += (1 - v) * lo
        upper += (1 - v) * hi
    # Nonnegativity is exact and can strengthen a coarse series enclosure.
    return max(ZERO, lower), max(ZERO, upper)


def _small_power_sign(v: Fraction, p: Fraction, K: int, alpha: Fraction) -> Optional[int]:
    """Resolve comparisons algebraically when the exact-power work is small.

    This also recognizes several rational roots exactly, avoiding a stalled
    interval comparison at an equality.  A bit-size guard limits this optional
    route.  Returning None changes performance only, not validity.
    """
    if p == v:
        return -1  # alpha < 1 gives a strictly positive confidence radius.
    if p in (0, 1):
        return 1
    kv = K * v
    denominator = kv.denominator
    left_exp = kv.numerator
    right_exp = K * denominator - left_exp
    bases: list[tuple[Fraction, int]] = [(alpha, denominator)]
    if left_exp:
        bases.append((p / v, left_exp))
    if right_exp:
        bases.append(((1 - p) / (1 - v), right_exp))
    work = sum(
        exponent * (base.numerator.bit_length() + base.denominator.bit_length())
        for base, exponent in bases
    )
    if work > 100_000:
        return None
    likelihood = ONE
    if left_exp:
        likelihood *= (p / v) ** left_exp
    if right_exp:
        likelihood *= ((1 - p) / (1 - v)) ** right_exp
    target = alpha ** denominator
    # likelihood = exp(-K * denominator * kl(v||p)).
    return 1 if likelihood < target else (-1 if likelihood > target else 0)


@dataclass(frozen=True)
class EndpointEnclosure:
    """A verified dyadic interval containing one mathematical KL endpoint."""

    side: str
    lower: Fraction
    upper: Fraction
    bits: int
    comparisons: int
    max_log_terms_used: int
    grid_resolved: bool

    @property
    def value(self) -> Fraction:
        """The outward endpoint: lower for side='lower', upper otherwise."""
        return self.lower if self.side == "lower" else self.upper

    @property
    def width(self) -> Fraction:
        return self.upper - self.lower


def kl_enclosure(
    v: Fraction | int,
    K: int,
    alpha: Fraction | int,
    *,
    side: str,
    bits: int = 24,
    max_terms: int = 128,
) -> EndpointEnclosure:
    """Enclose a KL endpoint with deterministic finite work.

    ``side`` is 'lower' or 'upper'.  The result always contains the exact root.
    Usually its width is <= 2**(-bits).  If a comparison remains undecided at
    ``max_terms``, the function retains a conservative bracket; the diagnostic
    ``grid_resolved`` records whether the requested grid width was achieved.

    Bounds on work: at most bits+1 ordinary binary-search comparisons, at most
    two neighboring-grid comparisons after an ambiguity, and at most
    16,32,64,...,max_terms series terms per comparison (capped at max_terms).
    Exact integer sizes also depend on the input rational sizes.
    """
    v = _rational(v, "v")
    alpha = _rational(alpha, "alpha")
    if not 0 <= v <= 1:
        raise ValueError("v must lie in [0, 1]")
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie strictly between 0 and 1")
    if isinstance(K, bool) or not isinstance(K, int) or K < 1:
        raise ValueError("K must be a positive integer")
    if side not in ("lower", "upper"):
        raise ValueError("side must be 'lower' or 'upper'")
    bits = _bits(bits)
    if isinstance(max_terms, bool) or not isinstance(max_terms, int) or not 1 <= max_terms <= 512:
        raise ValueError("max_terms must be an integer in [1, 512]")
    if (side == "lower" and v == 0) or (side == "upper" and v == 1):
        return EndpointEnclosure(side, v, v, bits, 0, 0, True)

    scale = 1 << bits
    lo = 0 if side == "lower" else v.numerator * scale // v.denominator
    hi = -((-v.numerator * scale) // v.denominator) if side == "lower" else scale
    comparisons = 0
    max_log_terms_used = 0
    threshold_cache: dict[int, tuple[Fraction, Fraction]] = {}

    def compare(p: Fraction) -> Optional[int]:
        nonlocal comparisons, max_log_terms_used
        comparisons += 1
        exact = _small_power_sign(v, p, K, alpha)
        if exact is not None:
            return exact
        terms = min(16, max_terms)
        while True:
            max_log_terms_used = max(max_log_terms_used, terms)
            kl_lo, kl_hi = _kl_bounds(v, p, terms)
            if terms not in threshold_cache:
                threshold_cache[terms] = log_bounds(1 / alpha, terms)
            threshold_lo, threshold_hi = threshold_cache[terms]
            if K * kl_lo > threshold_hi:
                return 1
            if K * kl_hi < threshold_lo:
                return -1
            if terms == max_terms:
                return None
            terms = min(2 * terms, max_terms)

    def decision(j: int) -> Optional[int]:
        """Return -1 if point is left of root; +1 if right; 0 if equal."""
        p = Fraction(j, scale)
        if side == "lower" and p >= v:
            return 1
        if side == "upper" and p <= v:
            return -1
        sign = compare(p)
        if sign is None:
            return None
        return -sign if side == "lower" else sign

    while hi - lo > 1:
        mid = (lo + hi) // 2
        which = decision(mid)
        if which == 0:
            lo = hi = mid
            break
        if which == -1:
            lo = mid
        elif which == 1:
            hi = mid
        else:
            # An exact root may sit at mid even if the optional power route
            # was too expensive.  Neighbor checks often reduce this case to
            # a two-grid-cell enclosure, without ever asserting equality.
            for neighbor in (mid - 1, mid + 1):
                if not lo < neighbor < hi:
                    continue
                direction = decision(neighbor)
                if direction == 0:
                    lo = hi = neighbor
                    break
                if direction == -1:
                    lo = neighbor
                elif direction == 1:
                    hi = neighbor
            break
    return EndpointEnclosure(
        side, Fraction(lo, scale), Fraction(hi, scale), bits, comparisons,
        max_log_terms_used, hi - lo <= 1,
    )


def kl_lower(v: Fraction | int, K: int, alpha: Fraction | int, bits: int = 24) -> Fraction:
    """Return a verified lower (outward) approximation to the lower KL root."""
    return kl_enclosure(v, K, alpha, side="lower", bits=bits).lower


def kl_upper(v: Fraction | int, K: int, alpha: Fraction | int, bits: int = 24) -> Fraction:
    """Return a verified upper (outward) approximation to the upper KL root."""
    return kl_enclosure(v, K, alpha, side="upper", bits=bits).upper


def verify_endpoint(
    v: Fraction | int,
    K: int,
    alpha: Fraction | int,
    endpoint: Fraction | int,
    *,
    side: str = "lower",
    max_terms: int = 128,
) -> bool:
    """Check an emitted endpoint directly, without re-running binary search.

    A lower endpoint e is accepted when e=0, or when e<v and
    K*kl(v||e) >= log(1/alpha) is proved.  An upper endpoint is accepted
    symmetrically (e=1, or e>v and the same proved inequality).  Exact rational
    equality is accepted when the bounded-cost power calculation resolves it.

    True certifies the desired outward relation.  False means that this check
    did not certify it: the endpoint can be invalid, or the finite logarithm
    budget can be insufficient.  Malformed/out-of-domain inputs raise errors.
    """
    v = _rational(v, "v")
    alpha = _rational(alpha, "alpha")
    endpoint = _rational(endpoint, "endpoint")
    if not 0 <= v <= 1 or not 0 <= endpoint <= 1:
        raise ValueError("v and endpoint must lie in [0, 1]")
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie strictly between 0 and 1")
    if isinstance(K, bool) or not isinstance(K, int) or K < 1:
        raise ValueError("K must be a positive integer")
    if side not in ("lower", "upper"):
        raise ValueError("side must be 'lower' or 'upper'")
    if isinstance(max_terms, bool) or not isinstance(max_terms, int) or not 1 <= max_terms <= 512:
        raise ValueError("max_terms must be an integer in [1, 512]")
    if side == "lower":
        if endpoint == 0:
            return True
        if endpoint >= v:
            return False
    else:
        if endpoint == 1:
            return True
        if endpoint <= v:
            return False
    exact = _small_power_sign(v, endpoint, K, alpha)
    if exact is not None:
        return exact >= 0
    terms = min(16, max_terms)
    while True:
        kl_lo, kl_hi = _kl_bounds(v, endpoint, terms)
        threshold_lo, threshold_hi = log_bounds(1 / alpha, terms)
        if K * kl_lo >= threshold_hi:
            return True
        if K * kl_hi < threshold_lo or terms == max_terms:
            return False
        terms = min(2 * terms, max_terms)


__all__ = [
    "EndpointEnclosure", "dyadic_floor", "dyadic_ceil", "log_bounds",
    "kl_enclosure", "kl_lower", "kl_upper", "verify_endpoint",
]
