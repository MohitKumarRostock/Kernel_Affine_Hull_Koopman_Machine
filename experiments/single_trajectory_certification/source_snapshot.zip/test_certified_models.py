"""Meaningful exact-arithmetic and semantic checks for certified_models."""

from copy import deepcopy
from fractions import Fraction as F
import json
import unittest

from certified_models import (
    encode, fit_candidates, model_sha256, model_to_jsonable, predict_exact, verify_model,
)


def prescribed(kind="memberships"):
    p = 2 if kind == "memberships" else (4 if kind == "local_position" else 2)
    return {
        "model_version": 1, "candidate_id": kind, "encoder_kind": kind,
        "history": 2, "kappa": F(1), "coordinate_cost": p,
        "centers": [[F(0), F(0)], [F(1), F(1)]], "axes": [1, 1],
        "score_scale": F(1), "eta": F(1), "omega": 1, "feature_scale": F(1),
        "affine_weights": [F(0)] * p, "intercept": F(1, 2),
    }


class CertifiedModelsTests(unittest.TestCase):
    def test_exact_membership_formula_and_simplex(self):
        # At x=(0,1/2), residuals^2=0,1, hence affinities=2,3/2.
        self.assertEqual(encode(prescribed(), [F(0), F(1, 2)]), [F(4, 7), F(3, 7)])
        points = [[F(a, 8), F(b, 8)] for a in range(9) for b in range(9)]
        for x in points:
            phi = encode(prescribed(), x)
            self.assertEqual(sum(phi), F(1))
            self.assertTrue(all(v > 0 for v in phi))

    def test_local_coordinates_use_matching_memberships(self):
        self.assertEqual(
            encode(prescribed("local_position"), [F(0), F(1, 2)]),
            [F(4, 7), F(3, 7), F(2, 7), F(-3, 14)],
        )

    def test_full_rank_local_recovery_with_coordinate_axes(self):
        m = prescribed("local_position")
        m["axes"] = [0, 1]
        for x in ([F(1, 3), F(2, 7)], [F(0), F(1)], [F(1), F(0)]):
            phi0, phi1, v0, v1 = encode(m, x)
            recovered = [v0 / phi0 + m["centers"][0][0], v1 / phi1 + m["centers"][1][1]]
            self.assertEqual(recovered, x)

    def test_exact_prediction_clipping_and_membership_boundary(self):
        m = prescribed("raw")
        m["affine_weights"] = [F(3, 5), F(4, 5)]  # norm exactly one
        m["intercept"] = F(-1, 10)
        self.assertTrue(verify_model(m))
        self.assertEqual(predict_exact(m, [0, 0]), F(0))
        self.assertEqual(predict_exact(m, [1, 1]), F(1))
        self.assertEqual(predict_exact(m, [F(1, 2), F(1, 2)]), F(3, 5))
        m["affine_weights"][0] += F(1, 10**20)
        with self.assertRaisesRegex(ValueError, "norm"):
            verify_model(m)

    def test_shapes_support_and_nonexact_inputs_rejected(self):
        m = prescribed()
        for x in ([0], [F(-1, 100), 0], [0, F(101, 100)], [0.0, 0]):
            with self.assertRaises((TypeError, ValueError)):
                encode(m, x)
        for key, value in (("eta", F(0)), ("score_scale", F(0)), ("axes", [0, 2]), ("coordinate_cost", 3)):
            bad = deepcopy(m)
            bad[key] = value
            with self.assertRaises(ValueError):
                verify_model(bad)

    def test_fit_dimensions_freezing_and_determinism(self):
        development = [F((i * 7) % 23, 22) for i in range(80)]
        original = development.copy()
        family = fit_candidates(development, 5, F(3, 2))
        self.assertEqual([m["coordinate_cost"] for m in family], [5, 2, 4])
        self.assertEqual([m["training_count"] for m in family], [75, 75, 75])
        self.assertEqual(development, original)
        self.assertEqual([model_sha256(m) for m in family], [model_sha256(m) for m in fit_candidates(development, 5, F(3, 2))])
        for m in family:
            self.assertTrue(verify_model(m))
            self.assertTrue(all(isinstance(w, F) for w in m["affine_weights"]))
            self.assertLessEqual(sum(w*w for w in m["affine_weights"]), m["kappa"]**2)
        # Modifying the supplied development array after fitting cannot change models.
        hashes = [model_sha256(m) for m in family]
        development[:] = [F(0)] * 80
        self.assertEqual(hashes, [model_sha256(m) for m in family])
        # Mutating one candidate's shared-looking geometry cannot alter another.
        before = model_sha256(family[2])
        family[1]["centers"][0][0] = F(17, 19)
        self.assertEqual(before, model_sha256(family[2]))

    def test_training_learns_predictive_relation(self):
        # Repeated long constant runs make latest value genuinely informative.
        development = [F((i // 25) % 2) for i in range(250)]
        raw = fit_candidates(development, 3, F(2), ridge=F(1, 10**6))[0]
        losses = [(development[t] - predict_exact(raw, development[t-3:t]))**2 for t in range(3, len(development))]
        self.assertLess(sum(losses) / len(losses), F(1, 10))
        self.assertTrue(any(w != 0 for w in raw["affine_weights"]))

    def test_tiny_and_zero_norm_budgets(self):
        development = [F(i % 2) for i in range(80)]
        for budget in (F(0), F(1, 10**40), F(1, 10000), F(1, 3)):
            for m in fit_candidates(development, 3, budget, coefficient_bits=12):
                self.assertTrue(verify_model(m))
                self.assertLessEqual(sum(w*w for w in m["affine_weights"]), budget*budget)

    def test_constant_history_repeated_centers_and_variance_axis(self):
        family = fit_candidates([F(1, 3)] * 10, 4, F(1), groups=12, axis_rule="development_variance")
        for m in family:
            self.assertTrue(verify_model(m))
            self.assertTrue(F(0) <= predict_exact(m, [F(1, 3)] * 4) <= F(1))
        phi = encode(family[1], [F(1, 3)] * 4)
        self.assertEqual(phi, [F(1, 12)] * 12)
        self.assertEqual(family[1]["axes"], [3] * 12)

    def test_json_roundtrip_preserves_exact_predictor_and_hash(self):
        m = fit_candidates([F((i * 3) % 17, 16) for i in range(30)], 3, F(1))[2]
        restored = json.loads(json.dumps(model_to_jsonable(m)))
        self.assertTrue(verify_model(restored))
        self.assertEqual(predict_exact(m, [F(1, 3)] * 3), predict_exact(restored, [F(1, 3)] * 3))
        self.assertEqual(model_sha256(m), model_sha256(restored))

    def test_feature_scale_is_part_of_encoder(self):
        m = prescribed("local_position")
        unscaled = encode(m, [F(1, 5), F(2, 5)])
        m["feature_scale"] = F(7, 3)
        self.assertEqual(encode(m, [F(1, 5), F(2, 5)]), [F(7, 3)*v for v in unscaled])

    def test_unrepresentable_ridge_uses_valid_constant_fallback(self):
        family = fit_candidates([F(i % 3, 2) for i in range(20)], 3, F(1), ridge=F(1, 10**1000))
        for m in family:
            self.assertTrue(m["fitting"]["constant_fallback"])
            self.assertEqual(m["affine_weights"], [F(0)] * m["coordinate_cost"])
            self.assertTrue(verify_model(m))


if __name__ == "__main__":
    unittest.main()
