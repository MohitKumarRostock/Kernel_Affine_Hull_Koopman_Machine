"""Independent checks for exact log bounds and outward KL endpoints."""

from decimal import Decimal, localcontext
from fractions import Fraction as F
import unittest

from certified_kl import dyadic_floor, dyadic_ceil, log_bounds, kl_enclosure, kl_lower, kl_upper, verify_endpoint


def dec(x):
    return Decimal(x.numerator) / Decimal(x.denominator)


class CertifiedKLTests(unittest.TestCase):
    def test_log_bounds_cover_high_precision_reference(self):
        # Decimal is an independent cross-check only, never used by certifier.
        with localcontext() as ctx:
            ctx.prec = 110
            for x in [F(1), F(2), F(1, 2), F(3, 7), F(10**30), F(1, 10**30), F(123456789, 134567891)]:
                lo, hi = log_bounds(x, 32)
                ref = dec(x).ln()
                self.assertLessEqual(dec(lo), ref)
                self.assertGreaterEqual(dec(hi), ref)

    def test_log_bounds_nested_and_exact_at_one(self):
        self.assertEqual(log_bounds(1), (F(0), F(0)))
        for x in [F(7, 9), F(19), F(1, 11), F(2)]:
            lo1, hi1 = log_bounds(x, 8)
            lo2, hi2 = log_bounds(x, 16)
            self.assertLessEqual(lo1, lo2)
            self.assertLessEqual(hi2, hi1)

    def test_dyadic_rounding_is_outward(self):
        for x in [F(0), F(1), F(1, 3), F(999999, 1000000), F(-1, 3)]:
            lo, hi = dyadic_floor(x, 20), dyadic_ceil(x, 20)
            self.assertLessEqual(lo, x)
            self.assertGreaterEqual(hi, x)
            self.assertLessEqual(hi - lo, F(1, 2**20))

    def test_endpoint_extremes(self):
        self.assertEqual(kl_lower(0, 207, F(1, 150)), 0)
        self.assertEqual(kl_upper(1, 207, F(1, 150)), 1)

    def test_exact_rational_roots(self):
        # v=0, K=1: upper=1-alpha. v=1, K=1: lower=alpha.
        self.assertEqual(kl_upper(0, 1, F(1, 4)), F(3, 4))
        self.assertEqual(kl_lower(1, 1, F(1, 4)), F(1, 4))
        # v=1/2, K=2: exp(-K kl)=4p(1-p), alpha=3/4.
        self.assertEqual(kl_lower(F(1, 2), 2, F(3, 4)), F(1, 4))
        self.assertEqual(kl_upper(F(1, 2), 2, F(3, 4)), F(3, 4))

    def test_zero_loss_floor_and_complement(self):
        K, alpha = 207, F(1, 150)
        upper = kl_enclosure(0, K, alpha, side="upper")
        lower = kl_enclosure(1, K, alpha, side="lower")
        self.assertLessEqual(1 - upper.upper, lower.upper)
        self.assertEqual(upper.lower, 1 - lower.upper)
        self.assertEqual(upper.upper, 1 - lower.lower)
        # Exact algebraic checks of the bracket, no log reference.
        self.assertGreaterEqual((1 - upper.lower) ** K, alpha)
        self.assertLessEqual((1 - upper.upper) ** K, alpha)

    def test_general_roots_by_independent_decimal_inequalities(self):
        with localcontext() as ctx:
            ctx.prec = 100
            for v, K, alpha in [(F(1, 100), 207, F(1, 150)), (F(1, 3), 23, F(1, 40)), (F(98765, 2**20), 400, F(1, 150))]:
                dv = dec(v)
                threshold = (1 / dec(alpha)).ln()
                for side in ["lower", "upper"]:
                    bracket = kl_enclosure(v, K, alpha, side=side)
                    self.assertTrue(bracket.grid_resolved)
                    self.assertLessEqual(bracket.width, F(1, 2**24))
                    def gap(p):
                        dp = dec(p)
                        return K * (dv * (dv / dp).ln() + (1 - dv) * ((1 - dv) / (1 - dp)).ln()) - threshold
                    if side == "lower":
                        self.assertGreaterEqual(gap(bracket.lower), 0)
                        self.assertLessEqual(gap(bracket.upper), 0)
                    else:
                        self.assertLessEqual(gap(bracket.lower), 0)
                        self.assertGreaterEqual(gap(bracket.upper), 0)

    def test_fixed_work_ambiguity_retains_safe_outer_bounds(self):
        v, K, alpha = F(12345, 2**20), 207, F(1, 150)
        for side in ["lower", "upper"]:
            coarse = kl_enclosure(v, K, alpha, side=side, max_terms=1)
            fine = kl_enclosure(v, K, alpha, side=side)
            self.assertLessEqual(coarse.lower, fine.lower)
            self.assertGreaterEqual(coarse.upper, fine.upper)
            self.assertLessEqual(coarse.max_log_terms_used, 1)

    def test_direct_endpoint_checker_accepts_valid_rejects_corrupted(self):
        v, K, alpha = F(1, 2), 2, F(3, 4)
        self.assertTrue(verify_endpoint(v, K, alpha, F(1, 4), side="lower"))
        self.assertFalse(verify_endpoint(v, K, alpha, F(3, 10), side="lower"))
        self.assertTrue(verify_endpoint(v, K, alpha, F(3, 4), side="upper"))
        self.assertFalse(verify_endpoint(v, K, alpha, F(7, 10), side="upper"))
        self.assertFalse(verify_endpoint(v, K, alpha, F(3, 4), side="lower"))
        self.assertFalse(verify_endpoint(v, K, alpha, F(1, 4), side="upper"))
        self.assertTrue(verify_endpoint(v, K, alpha, 0, side="lower"))
        self.assertTrue(verify_endpoint(v, K, alpha, 1, side="upper"))
        for side in ["lower", "upper"]:
            self.assertFalse(verify_endpoint(v, K, alpha, v, side=side))

    def test_direct_checker_accepts_general_emitted_bounds(self):
        v, K, alpha = F(12345, 2**20), 207, F(1, 150)
        for side in ["lower", "upper"]:
            endpoint = kl_enclosure(v, K, alpha, side=side).value
            self.assertTrue(verify_endpoint(v, K, alpha, endpoint, side=side))

    def test_invalid_inputs_rejected(self):
        for bad in [0.1, float("nan"), True]:
            with self.assertRaises((TypeError, ValueError)):
                kl_lower(bad, 10, F(1, 20))
        for bad in [F(-1), F(2)]:
            with self.assertRaises(ValueError):
                kl_lower(bad, 10, F(1, 20))
        for bad in [0, 1, -1]:
            with self.assertRaises(ValueError):
                kl_upper(F(1, 2), 10, bad)
        for bad in [0, -1, True, 2.0]:
            with self.assertRaises(ValueError):
                kl_upper(F(1, 2), bad, F(1, 20))


if __name__ == "__main__":
    unittest.main()
